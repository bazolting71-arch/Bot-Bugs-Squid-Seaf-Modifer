Pick Your Bots + SEAF (F5 + Mod Options Menu)  -  personal combination build, v2

PARTS
1. Pick your bots/bugs/squids 1.8.1 (No Preview Hotfix): enemy spawn multipliers and unit mixes,
   settings panel on F5 (fallback key; Mod Bindings Menu can assign another). Only change vs the
   original: F9 -> F5.
2. SEAF | Heavy Presence: Gameplay Systems 1.4.2, untouched. On/off in your mod manager only.
3. SEAF | Pelican Cooldown Slider and SEAF | Active Wave Slider: Gameplay Systems' -20% cooldown
   patches with one change each: the 0.8 multiplier is read from a Mod Options Menu slider
   (MODS tab > SEAF TUNING, 0-50% reduction, step 5, default 20, 0 = vanilla).

HOW THE SLIDERS WORK / LIMITS
- The game's SEAF data is only written once, at the first title screen of a launch (the original
  author's safety rule, kept as is). So a slider change is saved immediately but takes effect the
  NEXT time you launch the game. The sliders appear in the MODS tab after the title screen.
- Heavy Presence cannot be a menu toggle: the shared runtime treats an installed-but-undeclared
  option as an error and freezes the choice at startup. Use your mod manager for it.
- Requires Bingus Shared Loader v18+ and Mod Options Menu v1.2+ (api version 3). Without
  Mod Options Menu the cooldowns use the default 20%.
- Use these instead of Gameplay Systems' own cooldown options (same resource names). Do not run
  the original Pick your bots mod alongside.
- Not tested in game. Slider range is capped at 50%, the highest value the original author shipped.
- Logs: SEAFReinforcementCooldown.log and SEAFActiveWaveCooldownMinus20.log show the
  'requested' float bytes actually written (look for final=SUCCESS).

CREDITS
Pick your bots/bugs/squids: feroz. Gameplay Systems: its author. Mod Options Menu: CowboyBingus.
Ask the authors before redistributing.
