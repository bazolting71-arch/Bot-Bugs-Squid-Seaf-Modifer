Pick Your Bots + SEAF (Heavy SEAF ON)  -  personal combination build, v2

INCLUDED
1. Pick your bots/bugs/squids 1.8.1 (No Preview Hotfix): enemy spawn multipliers and unit mixes.
   Settings panel on F5 (fallback key; Mod Bindings Menu can assign another). Only change: F9 -> F5.
2. Heavy SEAF presence (Gameplay Systems 1.4.2 shared runtime + Heavy Presence declaration, untouched).
3. SEAF Pelican Cooldown and Active Wave Cooldown: Gameplay Systems' -20% patches with the multiplier read
   from Mod Options Menu sliders (MODS tab > SEAF TUNING, 0-50%, step 5, default 20, 0 = vanilla).

SWITCHING HEAVY SEAF
To switch Heavy SEAF OFF: disable this mod, enable 'Pick Your Bots + SEAF (Heavy SEAF OFF)', Purge/Deploy, restart the game.
Heavy SEAF is chosen at game start and cannot be changed in game. Do not enable both zips at once
(they share resource names).

LIMITS
- Slider changes are saved at once but apply the next time you launch the game (the SEAF data is
  written once, at the first title screen of a launch).
- Needs Bingus Shared Loader v18+ and Mod Options Menu v1.2+. Without Mod Options Menu the cooldowns use 20%.
- Do not run the original Pick your bots mod or Gameplay Systems' own SEAF cooldown options alongside.
- Not tested in game. After one launch check BingusSharedLoader.log for 'load failed' and the SEAF
  cooldown logs for final=SUCCESS.

CREDITS
Pick your bots/bugs/squids: feroz. Gameplay Systems: its author. Mod Options Menu: CowboyBingus.
Ask the authors before redistributing.
