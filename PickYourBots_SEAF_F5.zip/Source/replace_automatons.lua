-- HD2-Addon: mods/feroz/pick_your_bots
-- Combined build: panel fallback hotkey changed F9 -> F5 (VK 0x74).
-- Pick your bots/bugs/squids 1.8.1-no-preview (ship forecast and interop probe removed).
-- Guard/outpost preservation is original trooper rows (MG and non-MG); NOT MG-only.
-- Host required; no player-count or lobby-type restriction. Gunships deferred.

local reader = (function()
-- 只读当前进程内存。不碰其它进程。
return function()
    local ffi = require('ffi')
    assert(ffi.abi('64bit'), '64-bit LuaJIT required')
    ffi.cdef [[
        void *GetModuleHandleA(const char *);
        void *GetCurrentProcess(void);
        int ReadProcessMemory(void *, const void *, void *, size_t, size_t *);
    ]]
    local win = ffi.load('kernel32')
    local process = win.GetCurrentProcess()
    local reader = {}
    function reader.module(name)
        local handle = win.GetModuleHandleA(name)
        if handle == nil then return nil end
        return tonumber(ffi.cast('uintptr_t', handle))
    end
    -- One buffer for every read (Lua runs one read at a time): no allocation and no zero fill per call.
    local buffer = ffi.new('uint8_t[?]', 262144)
    local received = ffi.new('size_t[1]')
    reader.calls = 0
    function reader.read(address, size)
        if type(address) ~= 'number' or address < 65536 or address >= 140737488355328
            or type(size) ~= 'number' or size < 1 or size > 262144
            or size % 1 ~= 0 or address % 1 ~= 0 then return nil end
        reader.calls = reader.calls + 1
        local ok = win.ReadProcessMemory(process, ffi.cast('void *', address), buffer, size, received)
        if ok == 0 or tonumber(received[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end
    -- Batched reads of `count` items of `size` bytes at addrs[1..count] (nil entries give nil).
    -- Items within GAP bytes of each other are read together, one call per span of at most SPAN bytes,
    -- and sliced. A span that cannot be read falls back to one read per item, so every result is exactly
    -- what reading that item on its own returns. stable=true reads each span twice and keeps an item only
    -- when both reads agree (an item that differs is read on its own twice, like the per item check).
    local SPAN, GAP = 65536, 4096
    local function single(a, size, stable)
        local v = reader.read(a, size)
        if stable and v and reader.read(a, size) ~= v then return nil end
        return v
    end
    function reader.gather(addrs, count, size, stable)
        local out, order = {}, {}
        for i = 1, count do
            local a = addrs[i]
            if type(a) == 'number' then order[#order + 1] = i end
        end
        table.sort(order, function(x, y) return addrs[x] < addrs[y] end)
        local k, total = 1, #order
        local bound = reader.bound
        while k <= total do
            local first = addrs[order[k]]
            local last_end, j = first + size, k
            -- With a region map (memory module), a span never leaves the readable region it starts in.
            -- The region is only looked up when the next item is close enough to be merged at all.
            local nxt = order[k + 1] and addrs[order[k + 1]]
            local mergeable = nxt and nxt - last_end <= GAP and nxt + size - first <= SPAN
            local limit = mergeable and bound and bound(first)
            if mergeable and (limit or not bound) then
                while j < total do
                    local a = addrs[order[j + 1]]
                    if a - last_end > GAP or a + size - first > SPAN or (limit and a + size > limit) then break end
                    j = j + 1
                    if a + size > last_end then last_end = a + size end
                end
            end
            if j == k then
                out[order[k]] = single(first, size, stable)
            else
                local len = last_end - first
                local A = reader.read(first, len)
                local B = A and stable and reader.read(first, len)
                if not A or (stable and not B) then
                    if reader.forget then reader.forget(first) end
                    for x = k, j do out[order[x]] = single(addrs[order[x]], size, stable) end
                else
                    for x = k, j do
                        local i = order[x]
                        local o = addrs[i] - first
                        local v = A:sub(o + 1, o + size)
                        if stable and B:sub(o + 1, o + size) ~= v then v = single(addrs[i], size, true) end
                        out[i] = v
                    end
                end
            end
            k = j + 1
        end
        return out
    end
    return reader
end

end)()

local memory = (function()
-- Process memory access. The guarded 996 caller below invokes the native ability start.
return function(make_reader)
    local ffi = require('ffi')
    local mem = make_reader()
    ffi.cdef [[
        typedef struct {
            void *base; void *allocation; uint32_t allocation_protect;
            uint16_t partition; uint16_t padding; size_t size;
            uint32_t state; uint32_t protect; uint32_t kind;
        } AllAutomatonReplaceRegion;
        size_t VirtualQuery(const void *, void *, size_t);
        int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);
    ]]
    local win = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', win.VirtualQuery)
    local function pointer(n) return ffi.cast('void *', n) end

    function mem.region(address)
        if type(address) ~= 'number' or address < 65536 then return nil end
        local region = ffi.new('AllAutomatonReplaceRegion[1]')
        if query(pointer(address), region, ffi.sizeof(region[0])) ~= ffi.sizeof(region[0]) then return nil end
        local r = region[0]
        return {
            base = tonumber(ffi.cast('uintptr_t', r.base)),
            allocation = tonumber(ffi.cast('uintptr_t', r.allocation)),
            size = tonumber(r.size),
            state = tonumber(r.state),
            protect = tonumber(r.protect),
            kind = tonumber(r.kind),
        }
    end

    -- 允许写镜像内存的窄口:必须是"先登记过"的 8 字节实体字段
    local image_whitelist = {}
    function mem.allow_image_field(address, module)
        if type(address) ~= 'number' or address % 8 ~= 0 then return false end
        image_whitelist[address] = module
        return true
    end
    function mem.is_allowed_image_field(address)
        return image_whitelist[address] ~= nil
    end

    -- Readable committed regions learned with VirtualQuery and kept for a few seconds, so that a batched
    -- read never spans into memory that cannot be read (gather asks mem.bound for the end of the region).
    local ranges, RANGE_TTL, RANGE_MAX = {}, 5, 2048
    local function readable(p)
        local b = p % 256
        return (b == 0x02 or b == 0x04 or b == 0x08 or b == 0x20 or b == 0x40 or b == 0x80) and p % 512 < 256
    end
    local function locate(a)
        local lo, hi = 1, #ranges
        while lo <= hi do
            local mid = math.floor((lo + hi) / 2)
            local r = ranges[mid]
            if a < r[1] then hi = mid - 1 elseif a >= r[2] then lo = mid + 1 else return mid end
        end
    end
    function mem.forget(a)
        local i = locate(a)
        if i then table.remove(ranges, i) end
    end
    function mem.bound(a)
        local now = os.clock()
        local i = locate(a)
        if i then
            if now - ranges[i][3] <= RANGE_TTL then return ranges[i][2] end
            table.remove(ranges, i)
        end
        local r = mem.region(a)
        if not r or r.state ~= 0x1000 or not readable(r.protect) then return nil end
        local lo, hi = r.base, r.base + r.size
        for k = #ranges, 1, -1 do
            local x = ranges[k]
            if x[1] < hi and lo < x[2] then table.remove(ranges, k) end
        end
        if #ranges >= RANGE_MAX then
            local oldest = 1
            for k = 2, #ranges do if ranges[k][3] < ranges[oldest][3] then oldest = k end end
            table.remove(ranges, oldest)
        end
        local pos = #ranges + 1
        for k = 1, #ranges do if ranges[k][1] > lo then pos = k; break end end
        table.insert(ranges, pos, {lo, hi, now})
        return hi
    end

    function mem.writable(address, size)
        if type(address) ~= 'number' or address < 65536 or address % 1 ~= 0
            or size < 1 or size > 4096 then return false end
        local r = mem.region(address)
        if not r or r.state ~= 0x1000 or r.protect ~= 4 then return false end
        if address + size > r.base + r.size then return false end
        if r.kind == 0x20000 then return true end             -- 私有可写(堆)
        if r.kind == 0x1000000 then                           -- 模块镜像:仅限登记过的 8 字节字段
            return size == 8 and image_whitelist[address] == r.allocation
        end
        return false
    end

    -- 不做策略检查的裸写(调用方自己校验区域属性);特殊区域用
    function mem.write_raw(address, bytes)
        local count = ffi.new('size_t[1]')
        local ok = win.WriteProcessMemory(win.GetCurrentProcess(), pointer(address),
                                          bytes, #bytes, count)
        return ok ~= 0 and tonumber(count[0]) == #bytes
    end

    function mem.write(address, bytes)
        if not mem.writable(address, #bytes) then return false, 'not_writable' end
        local count = ffi.new('size_t[1]')
        local ok = win.WriteProcessMemory(win.GetCurrentProcess(), pointer(address),
                                          bytes, #bytes, count)
        if ok == 0 or tonumber(count[0]) ~= #bytes then return false, 'write_failed' end
        if mem.read(address, #bytes) ~= bytes then return false, 'readback_mismatch' end
        return true
    end

    -- 枚举已提交、可读、非执行的区块（镜像优先，其余按大小降序）
    -- Retain aligned read/write data buffers for the whole Lua VM lifetime. Native
    -- candidate references can outlive a detached descriptor. No executable allocation.
    mem.mix_buffers = {}
    pcall(ffi.cdef,'void *VirtualAlloc(void *, size_t, uint32_t, uint32_t);')
    function mem.publish_blob(bytes)
        if type(bytes)~='string' or #bytes==0 or #bytes>1048576 then return nil end
        local p=win.VirtualAlloc(nil,#bytes,0x3000,0x04)
        if p==nil then return nil end
        local address=tonumber(ffi.cast('uintptr_t',p))
        for off=0,#bytes-1,4096 do
            if not mem.write(address+off,bytes:sub(off+1,off+4096))then return nil end
        end
        mem.mix_buffers[#mem.mix_buffers+1]=address
        return address -- process lifetime; native queues may retain these rows
    end

    function mem.regions(module_base, limit)
        local out, seen = {}, {}
        local address, guard = 65536, 0
        while address < 140737488355328 and guard < 400000 do
            guard = guard + 1
            local r = mem.region(address)
            if not r then
                address = address + 65536
            else
                local readable = r.protect == 0x02 or r.protect == 0x04
                    or r.protect == 0x20 or r.protect == 0x40
                local executable = r.protect == 0x10 or r.protect == 0x20
                    or r.protect == 0x40 or r.protect == 0x80
                if r.state == 0x1000 and readable and not executable and r.size >= 4096 then
                    if not seen[r.base] then
                        seen[r.base] = true
                        out[#out+1] = {
                            base = r.base, size = r.size, kind = r.kind,
                            is_image = (r.kind == 0x1000000 and r.allocation == module_base),
                        }
                    end
                end
                local next_address = r.base + r.size
                if next_address <= address then next_address = address + 65536 end
                address = next_address
            end
        end
        table.sort(out, function(a, b)
            if a.is_image ~= b.is_image then return a.is_image end
            return a.size > b.size
        end)
        if limit and #out > limit then
            local trimmed = {}
            for i = 1, limit do trimmed[i] = out[i] end
            return trimmed, #out
        end
        return out, #out
    end
    return mem
end

end)()

-- Per-source weighted mixes. Data only; all native instructions remain unchanged.
local make_unit_mix = function(spec)
    spec=spec or {}
    local M = {is_bug=spec.is_bug==true,is_illuminate=spec.is_illuminate==true}
    M.sources = spec.sources or {
        {key='patrols', label='Patrols', groups={32,112}},
        {key='drops', label='Bot drops', groups={80}},
        {key='guards', label='Guard templates', groups={64}},
        {key='outposts', label='General outposts and POIs', groups={}},
    }
    M.units = spec.units or {
        {'scorcher','Hulk Scorcher','cha_lieutenant_assault'},
        {'bruiser','Hulk Bruiser','cha_lieutenant_suppressor'},
        {'trooper_t3','Trooper tier 3','cha_conscript_tier_3'},
        {'brawler','Brawler','cha_conscript_melee'},
        {'commissar','Commissar','cha_conscript_commander'},
        {'berserker','Berserker','cha_berserker'},
        {'heavy_devastator','Heavy Devastator','cha_soldier_mg'},
        {'rocket_devastator','Rocket Devastator','cha_soldier_rpg'},
        {'annihilator','Annihilator Tank','cyborg_tank_heavycannon'},
        {'shredder','Shredder Tank','cyborg_tank_autocannons'},
        {'barrager','Barrager Tank','cyborg_tank_rocketlauncher'},
        {'assault_walker','War Strider','cyborg_assault_walker'},
        -- Test38: subfaction units no selectable pick converts into. Used only where their subfaction is active.
        {'jet_devastator','Jet Pack Devastator (Jet Brigade Planet)','cha_soldier_jumppack'},
        {'legion_cyborg','Cyborg (Cyborg Legion Planet)','cha_cyborg_elite'},
        {'legion_rusher','Cyborg Rusher (Cyborg Legion Planet)','cha_cyborg_elite_rusher'},
        {'factory_strider','Factory Strider','cyborg_spawner'},
    }
    M.strain_only=spec.strain_only or (not spec.is_bug and {jet_devastator=true,legion_cyborg=true,legion_rusher=true}) or nil
    M.removed_units=spec.removed_units or {'trooper','trooper_t2','mg_elite','rocket_elite','devastator','scout_strider','rocket_strider','scout'}
    local restricted_tanks={annihilator=true,shredder=true,barrager=true}
    function M.allowed(source,unit)
        if spec.source_exclusions and spec.source_exclusions[source] and spec.source_exclusions[source][unit] then return false end
        -- GuardForce can place a selected unit into fixed infantry positions.
        -- Keep tanks available to patrols and native drops, but exclude them
        -- from Automaton Guards and the retired POI route.
        return M.is_bug or (source~='guards' and source~='outposts') or not restricted_tanks[unit]
    end
    local source_rows={}
    for _,source in ipairs(M.sources)do
        local rows={}
        for _,unit in ipairs(M.units)do if M.allowed(source.key,unit[1])then rows[#rows+1]=unit end end
        source_rows[source.key]=rows
    end
    function M.rows_for_source(source)return source_rows[source] or M.units end
    function M.key(source,unit) return (spec.prefix or 'mix_')..source..'_'..unit end
    function M.default(source,unit)
        if M.is_bug then return unit==M.units[1][1] and 100 or 0 end
        if M.is_illuminate then return unit==M.units[1][1] and 100 or 0 end
        if source=='guards' then return unit=='trooper_t3' and 100 or 0 end
        return (unit=='scorcher' or unit=='bruiser') and 50 or 0
    end
    function M.vanilla_key(source) return (spec.prefix or 'mix_')..source..'_vanilla' end
    function M.decode(key)
        for _,src in ipairs(M.sources)do
            for _,unit in ipairs(M.units)do
                if key==M.key(src.key,unit[1])then return src.key,unit[1]end
            end
        end
    end
    local function allocate(values,total,exclude)
        local out,order,sum,assigned={},{},0,0
        for _,u in ipairs(M.units)do
            local v=u[1]~=exclude and (values[u[1]] or 0) or 0
            out[u[1]]=0
            if v>0 then sum=sum+v;order[#order+1]={key=u[1],weight=v,index=#order+1}end
        end
        if sum==0 then return out,0 end
        for _,u in ipairs(order)do
            local exact=total*u.weight/sum;local n=math.floor(exact)
            out[u.key]=n;assigned=assigned+n;u.remainder=exact-n
        end
        table.sort(order,function(a,b)
            if math.abs(a.remainder-b.remainder)<1e-10 then return a.index<b.index end
            return a.remainder>b.remainder
        end)
        for i=1,total-assigned do out[order[i].key]=out[order[i].key]+1 end
        return out,sum
    end
    -- A user edit keeps the chosen value and divides the remaining percentage
    -- between the OTHER currently selected units. Never add an unselected unit.
    function M.rebalance(values,selected,value)
        if type(value)~='number' or value~=value or value<0 or value>100 then return nil,'invalid_percentage' end
        value=math.floor(value+0.5)
        local found=false;for _,u in ipairs(M.units)do if u[1]==selected then found=true end end
        if not found then return nil,'unknown_unit'end
        local result,other=allocate(values,100-value,selected)
        if other==0 then value=100 end -- raise another slider before lowering the sole unit
        result[selected]=value
        return result
    end
    -- Startup migration is visible: write repaired values back to every slider.
    -- A unique 100% choice wins over leftover Test1 values (the reported bug).
    function M.repair_saved(values,source)
        local clean,sum,hundreds,chosen={},0,0,nil
        for _,u in ipairs(M.units)do
            local v=values[u[1]]
            if type(v)~='number' or v~=v or v<0 or v>100 then v=0 end
            clean[u[1]]=v;sum=sum+v
            if v==100 then hundreds=hundreds+1;chosen=u[1]end
        end
        if math.abs(sum-100)<1e-7 then return clean,false,false end
        if sum==0 then
            for _,u in ipairs(M.units)do clean[u[1]]=M.default(source,u[1])end
            return clean,true,true -- legacy all-zero becomes explicit vanilla mode
        end
        if hundreds==1 then return M.rebalance(clean,chosen,100),true,false end
        local repaired=allocate(clean,100)
        return repaired,true,false
    end

    function M.configure(profile,config,menu,emit)
        profile.mix_enabled = true -- legacy preset path is no longer user-selectable
        profile.mixes={};profile.mix_vanilla={};profile.mix_initialized={};profile.mix_errors={}
        for _,source in ipairs(M.sources) do
            local mix={}; profile.mixes[source.key]=mix
            local removed_weight=0
            for _,key in ipairs(M.removed_units)do
                local k=M.key(source.key,key)
                local v=menu[k];if v==nil then v=tonumber(config['raw_'..k])end
                if type(v)=='number'and v==v and v>0 then removed_weight=removed_weight+v end
            end
            -- Retired choices remain readable from old saved settings, but their
            -- weight is moved to the choices still available on this tab.
            for _,unit in ipairs(M.units)do
                if not M.allowed(source.key,unit[1])then
                    local k=M.key(source.key,unit[1])
                    local v=menu[k];if v==nil then v=tonumber(config['raw_'..k])end
                    if type(v)=='number'and v==v and v>0 then removed_weight=removed_weight+v end
                end
            end
            local vk=M.vanilla_key(source.key)
            local ik=(spec.prefix or 'mix_')..source.key..'_initialized'
            local initialized=menu[ik];if initialized==nil then initialized=config[ik]end
            if initialized==nil then
                initialized=removed_weight>0 or menu[vk]==false or config[vk]==false
                for _,unit in ipairs(M.units)do
                    local key=M.key(source.key,unit[1])
                    if config['raw_'..key]~=nil or menu[key]~=nil then initialized=true end
                end
            end
            profile.mix_initialized[source.key]=initialized==true
            local vanilla=menu[vk];if vanilla==nil then vanilla=config[vk]end
            if vanilla==nil then vanilla=not profile.mix_initialized[source.key]end
            profile.mix_vanilla[source.key]=vanilla==true
            for _,unit in ipairs(M.units) do
                local key=M.key(source.key,unit[1])
                local value=profile.mix_initialized[source.key]and M.default(source.key,unit[1])or(unit==M.units[1]and 100 or 0)
                if removed_weight>0 then value=0 end
                local token=config['raw_'..key]
                if token~=nil then
                    local n=tonumber(token)
                    if n and n==n and n>=0 and n<=100 then value=n
                    elseif menu[key]==nil then
                        profile.mix_errors[#profile.mix_errors+1]=key..' invalid_percentage='..tostring(token)
                        emit('mix_invalid_setting '..key..'='..tostring(token)..' (not applied)')
                    end
                end
                if menu[key]~=nil then value=menu[key] end
                if not M.allowed(source.key,unit[1])then value=0 end
                mix[unit[1]]=value
            end
            if removed_weight>0 then
                local repaired,sum=allocate(mix,100)
                if sum>0 then profile.mixes[source.key]=repaired;mix=repaired
                elseif M.is_illuminate and source.key=='drops' then
                    -- A retired Watcher-only ship mix becomes Voteless instead
                    -- of reverting to native ship contents.
                    profile.mix_vanilla[source.key]=false
                    for _,u in ipairs(M.units)do mix[u[1]]=u[1]=='voteless_light' and 100 or 0 end
                else
                    profile.mix_vanilla[source.key]=true
                    for i,u in ipairs(M.units)do mix[u[1]]=i==1 and 100 or 0 end
                end
                emit('mix_removed_units '..source.key..' removed_weight='..removed_weight
                    ..(sum>0 and ' remaining_ratios_normalized' or
                        (M.is_illuminate and source.key=='drops' and ' empty_selection_voteless_fallback' or ' empty_selection_native_until_saved')))
            end
            local rider_key=M.key(source.key,'walker_rider')
            if not M.is_bug and (tonumber(config['raw_'..rider_key])or 0)>0 then
                profile.mix_vanilla[source.key]=true
                emit('mix_removed_rider '..source.key..' native_until_saved; remaining percentages retained for editing')
            end
            -- Migrate only explicitly removed choices, not arbitrary invalid totals.
            local removed_positive=false
            for _,key in ipairs({'obliterator','jump_trooper','flamer','jump_devastator','shotgun_devastator','cyborg_elite','cyborg_elite_female','cyborg_rusher','cyborg_rusher_female'})do
                local k=M.key(source.key,key)
                if (tonumber(config['raw_'..k]) or 0)>0 then removed_positive=true end
            end
            if removed_positive and not M.is_bug then
                local repaired=M.repair_saved(mix,source.key)
                profile.mixes[source.key]=repaired
                emit('mix_removed_units_migrated '..source.key..' total=100')
            end
            if source.key=='outposts' then profile.mix_vanilla[source.key]=true end
            if not M.is_bug and source.key=='outposts' then
                local removed=0
                for key in pairs(restricted_tanks)do removed=removed+(tonumber(mix[key])or 0);mix[key]=0 end
                if removed>0 then
                    local repaired,sum=allocate(mix,100)
                    if sum>0 then profile.mixes[source.key]=repaired
                    else
                        profile.mix_vanilla[source.key]=true
                        for _,u in ipairs(M.units)do mix[u[1]]=M.default(source.key,u[1])end
                    end
                    emit('poi_tanks_removed weight='..removed..(sum>0 and ' remaining_ratios_normalized' or ' tank_only_selection_changed_to_vanilla'))
                end
                -- The Automaton POI selector has no verified native consumer.
                -- Retire saved weights without changing the Terminid nest route.
                profile.mix_vanilla[source.key]=true
            end
        end
    end
    function M.normalize(values)
        local out,total={},0
        for _,u in ipairs(M.units) do
            local value=values[u[1]] or 0
            if type(value)~='number' or value~=value or value<0 or value>100 then return nil,'invalid_weight' end
            if value>0 then out[#out+1]={key=u[1],name=u[3],weight=value};total=total+value end
        end
        if math.abs(total-100)>1e-7 then return nil,'percentage_total='..tostring(total)..'_expected_100' end
        for _,u in ipairs(out) do u.share=u.weight/100 end
        return out,total
    end
    local function raw(h) return (h:gsub('%x%x',function(x)return string.char(tonumber(x,16))end)) end
    local function hex(s)return (s:gsub('.',function(x)return string.format('%02x',x:byte())end))end
    local function u32(s,o)
        if not s or o<0 or o+4>#s then return nil end
        local a,b,c,d=s:byte(o+1,o+4);return a+b*256+c*65536+d*16777216
    end
    local function pack(n,sz)
        local t={};for i=1,sz or 8 do t[i]=string.char(n%256);n=math.floor(n/256)end;return table.concat(t)
    end
    local function ptr(s,o)
        local l,h=u32(s,o),u32(s,o+4)
        if not l or not h or h>=32768 then return nil end
        local n=l+h*4294967296;return n>=65536 and n or nil
    end
    local function put(s,o,b)return s:sub(1,o)..b..s:sub(o+#b+1)end
    local function f32(s,o)
        local n=u32(s,o);if not n then return nil end
        local sign=n>=2147483648 and -1 or 1
        local e=math.floor(n/8388608)%256;local m=n%8388608
        if e==255 then return nil end
        if e==0 then return sign*m*2^-149 end
        return sign*(1+m/8388608)*2^(e-127)
    end
    -- Positive finite floats suffice for costs and weights. Avoid ffi in the pure compiler.
    local function float(n)
        if n==0 then return '\0\0\0\0' end
        assert(n>0 and n<1e30,'invalid positive float')
        local e=math.floor(math.log(n)/math.log(2));if e < -126 then return pack(math.floor(n / 2^-149 + 0.5),4) end;local m=math.floor((n/2^e-1)*8388608+0.5)
        if m==8388608 then e=e+1;m=0 end
        return pack((e+127)*8388608+m,4)
    end
    -- Matches the native mission-tag predicate at captured RVA 0x177e3c0.
    local function eligible(row,tags)
        for o=0x68,0x74,4 do local k=u32(row,o);if k==0 then break end;if tags[k] then return false end end
        if u32(row,0x58)==0 then return true end
        for o=0x58,0x64,4 do if tags[u32(row,o)] then return true end end
        return false
    end
    local function entries(record)
        local out={}
        -- The native cache builder reads eight entries, NOT the old Lua parser's 21.
        for i=0,7 do
            local tag=u32(record,i*12);if not tag or tag==0 then break end
            local n=u32(record,i*12+4)
            if not n or n<1 or n>1000 then return nil end
            out[#out+1]={tag=tag,n=n,o=i*12}
        end
        return out
    end
    M.binary={hex=hex,u32=u32,ptr=ptr,pack=pack,put=put,f32=f32,float=float,raw=raw,eligible=eligible,entries=entries}

    function M.candidate_entry_cost(group,unit_cost,quantity,scale)
        -- Native builder +94cdb2 passes per-unit costing for descriptor group +64.
        -- Its 999 quantity is a member limit, not a mandatory 999-unit squad.
        -- Candidate +d0 instead identifies group +128; it is NOT the cost mode.
        return unit_cost*(group==64 and 1 or math.max(quantity,1))*scale
    end

    -- Test8: read the actual group-32 selection set before compiling Terminid patrols.
    -- This reader has no writes. Duplicate candidate pointers contribute their weights.
    function M.read_patrol_selection(read,context,profile,group)
        local counts_at=context+profile.candidate_counts
        local counts=read(counts_at,32);local count=u32(counts,0)
        local pool=profile.pools[1]
        if not count or not pool or count>pool[2] or profile.candidate_stride~=0xd8 then
            return nil,'waiting_for_patrol_candidate_bounds'
        end
        if count>0 and not group then return nil,'waiting_for_patrol_group' end
        local at=context+pool[1]
        local bytes=count>0 and read(at,count*0xd8) or ''
        if not bytes or read(counts_at,32)~=counts or (count>0 and read(at,#bytes)~=bytes) then
            return nil,'waiting_for_stable_patrol_candidates'
        end
        local weights={};local unique=0
        for i=0,count-1 do
            local pointer=ptr(bytes,i*0xd8+0xa8)
            local offset=pointer and pointer-group.address
            local weight=f32(bytes,i*0xd8+0xc0)
            if not offset or offset<0 or offset%0x118~=0 or offset>=#group.bytes then
                return nil,'waiting_for_mapped_patrol_candidates'
            end
            if not weight or weight~=weight or weight<0 or weight>1e7 then
                return nil,'waiting_for_patrol_candidate_weights'
            end
            if weights[pointer]==nil then weights[pointer]=0;unique=unique+1 end
            weights[pointer]=weights[pointer]+weight
        end
        return {weights=weights,count=count,unique=unique,counts_at=counts_at,counts=counts,address=at,bytes=bytes}
    end

    -- Reassign tags only: preserve entry quantities, metadata, native selection weights,
    -- roster costs, protected entries, uncached templates and every other template group.
    function M.balance_active_patrols(result,group,choices,weights)
        if not group or not choices or #choices==0 then return true end
        local index,shares,initial={}, {}, {}
        local share_total=0
        for i,c in ipairs(choices)do
            if index[c.tag] or not c.share or c.share<=0 then return nil,'invalid_patrol_balance_choices' end
            index[c.tag]=i;shares[i]=c.share;initial[i]=0;share_total=share_total+c.share
        end
        for i=1,#shares do shares[i]=shares[i]/share_total end
        local slots,total,template_count={},0,0
        local records={}
        local limits=result.patrol_balance_limits
        local usage,reserved={},{}
        local bytes=result.groups[32]
        if not bytes or #bytes~=#group.bytes then return nil,'patrol_balance_group_mismatch' end
        for n=0,#bytes/0x118-1 do
            local at=group.address+n*0x118
            local record=bytes:sub(n*0x118+1,(n+1)*0x118);records[n+1]=record
            local w=weights[at]
            if w and w>0 then
                local template=result.templates[at]
                if not template or template.source~='patrols' or template.group~=32 then return nil,'patrol_balance_template_mismatch' end
                template_count=template_count+1
                local en=entries(record);if not en then return nil,'patrol_balance_entries_invalid' end
                usage[n+1]={};reserved[n+1]=template.balance_reserved_factory or 0
                for _,e in ipairs(en)do
                    if limits and limits[e.tag] then usage[n+1][e.tag]=(usage[n+1][e.tag] or 0)+e.n end
                    local ci=index[e.tag]
                    if ci and (not template.balance_offsets or template.balance_offsets[e.o]) then
                        local mass=w*e.n
                        slots[#slots+1]={row=n+1,at=at,offset=e.o,mass=mass,quantity=e.n,initial=ci}
                        total=total+mass;initial[ci]=initial[ci]+mass
                    end
                end
            end
        end
        if total==0 then
            result.summary[#result.summary+1]='patrol_balance=empty_active_set group=32'
            return true
        end
        -- Largest entries first reduces the unavoidable rounding from indivisible squads.
        table.sort(slots,function(a,b)
            if a.mass~=b.mass then return a.mass>b.mass end
            if a.row~=b.row then return a.row<b.row end
            return a.offset<b.offset
        end)
        local targets,got={},{}
        for i=1,#choices do targets[i]=shares[i]*total;got[i]=0 end
        local function error_of(values)
            local error=0
            for i=1,#choices do error=error+(values[i]-targets[i])^2 end
            return error
        end
        for _,slot in ipairs(slots)do
            local best,delta
            for i=1,#choices do
                local d=(got[i]+slot.mass-targets[i])^2-(got[i]-targets[i])^2
                if not delta or d<delta-1e-9 then best,delta=i,d end
            end
            slot.choice=best;got[best]=got[best]+slot.mass
        end
        if limits or error_of(initial)<=error_of(got) then
            for i=1,#choices do got[i]=initial[i] end
            for _,slot in ipairs(slots)do slot.choice=slot.initial end
        end
        -- Bounded refinement; never accept a move that worsens the calculated mix.
        for pass=1,8 do
            local changed=false
            for _,slot in ipairs(slots)do
                local from=slot.choice;local best,delta=from,0
                for to=1,#choices do
                    if to~=from and (not limits or not limits[choices[to].tag]
                        or (usage[slot.row][choices[to].tag] or 0)+reserved[slot.row]+slot.quantity<=limits[choices[to].tag]) then
                        local d=(got[from]-slot.mass-targets[from])^2+(got[to]+slot.mass-targets[to])^2
                            -(got[from]-targets[from])^2-(got[to]-targets[to])^2
                        if d<delta-1e-9 then best,delta=to,d end
                    end
                end
                if best~=from then
                    if limits then
                        local a,b=choices[from].tag,choices[best].tag
                        if limits[a] then usage[slot.row][a]=(usage[slot.row][a] or 0)-slot.quantity end
                        if limits[b] then usage[slot.row][b]=(usage[slot.row][b] or 0)+slot.quantity end
                    end
                    got[from]=got[from]-slot.mass;got[best]=got[best]+slot.mass
                    slot.choice=best;changed=true
                end
            end
            if not changed then break end
        end
        local changed=0
        for _,slot in ipairs(slots)do
            if slot.choice~=slot.initial then
                records[slot.row]=put(records[slot.row],slot.offset,pack(choices[slot.choice].tag,4))
                changed=changed+1
            end
        end
        local report={templates=template_count,entries=#slots,changed_entries=changed,total=total,before={},after={},requested={}}
        for i,c in ipairs(choices)do
            report.before[c.tag]=initial[i]/total*100;report.after[c.tag]=got[i]/total*100;report.requested[c.tag]=shares[i]*100
            result.summary[#result.summary+1]=string.format('patrol_balance_tag=%08x requested=%.4f%% before=%.4f%% after=%.4f%%',c.tag,shares[i]*100,report.before[c.tag],report.after[c.tag])
        end
        if limits then
            report.per_template_limits=limits
            result.summary[#result.summary+1]='patrol_balance_factory_limit=2 preserved=true overflow_pool_unchanged=true'
        end
        result.stats.patrol_balance=report
        result.summary[#result.summary+1]=string.format('patrol_balance=active_selection_weight_x_quantity group=32 templates=%d entries=%d changed=%d excludes_protected=true budget_conditioned=false',template_count,#slots,changed)
        result.groups[32]=table.concat(records)
        for i,record in ipairs(records)do
            local t=result.templates[group.address+(i-1)*0x118]
            if t and t.record~=record then t.record=record;t.changed=true end
        end
        return true
    end

    -- Test9: read the actual group-80 selection set before compiling Terminid breachs.
    -- This reader has no writes. Duplicate candidate pointers contribute their weights.
    function M.read_breach_selection(read,context,profile,group)
        local counts_at=context+profile.candidate_counts
        local counts=read(counts_at,32);local count=u32(counts,16)
        local pool=profile.pools[5]
        if not count or not pool or count>pool[2] or profile.candidate_stride~=0xd8 then
            return nil,'waiting_for_breach_candidate_bounds'
        end
        if count>0 and not group then return nil,'waiting_for_breach_group' end
        local at=context+pool[1]
        local bytes=count>0 and read(at,count*0xd8) or ''
        if not bytes or read(counts_at,32)~=counts or (count>0 and read(at,#bytes)~=bytes) then
            return nil,'waiting_for_stable_breach_candidates'
        end
        local weights={};local unique=0
        for i=0,count-1 do
            local pointer=ptr(bytes,i*0xd8+0xa8)
            local offset=pointer and pointer-group.address
            local weight=f32(bytes,i*0xd8+0xc0)
            if not offset or offset<0 or offset%0x118~=0 or offset>=#group.bytes then
                return nil,'waiting_for_mapped_breach_candidates'
            end
            if not weight or weight~=weight or weight<0 or weight>1e7 then
                return nil,'waiting_for_breach_candidate_weights'
            end
            if weights[pointer]==nil then weights[pointer]=0;unique=unique+1 end
            weights[pointer]=weights[pointer]+weight
        end
        return {weights=weights,count=count,unique=unique,counts_at=counts_at,counts=counts,address=at,bytes=bytes}
    end

    -- Reassign tags only: preserve entry quantities, metadata, native selection weights,
    -- roster costs, protected entries, uncached templates and every other template group.
    function M.balance_active_breaches(result,group,choices,weights)
        if not group or not choices or #choices==0 then return true end
        local index,shares,initial={}, {}, {}
        local share_total=0
        for i,c in ipairs(choices)do
            if index[c.tag] or not c.share or c.share<=0 then return nil,'invalid_breach_balance_choices' end
            index[c.tag]=i;shares[i]=c.share;initial[i]=0;share_total=share_total+c.share
        end
        for i=1,#shares do shares[i]=shares[i]/share_total end
        local slots,total,template_count={},0,0
        local records={}
        local bytes=result.groups[80]
        if not bytes or #bytes~=#group.bytes then return nil,'breach_balance_group_mismatch' end
        for n=0,#bytes/0x118-1 do
            local at=group.address+n*0x118
            local record=bytes:sub(n*0x118+1,(n+1)*0x118);records[n+1]=record
            local w=weights[at]
            if w and w>0 then
                local template=result.templates[at]
                if not template or template.source~='drops' or template.group~=80 then return nil,'breach_balance_template_mismatch' end
                template_count=template_count+1
                local en=entries(record);if not en then return nil,'breach_balance_entries_invalid' end
                for _,e in ipairs(en)do
                    local ci=index[e.tag]
                    if ci and (not template.balance_offsets or template.balance_offsets[e.o]) then
                        local mass=w*e.n
                        slots[#slots+1]={row=n+1,at=at,offset=e.o,mass=mass,initial=ci}
                        total=total+mass;initial[ci]=initial[ci]+mass
                    end
                end
            end
        end
        if total==0 then
            result.summary[#result.summary+1]='breach_balance=empty_active_set group=80'
            return true
        end
        -- Largest entries first reduces the unavoidable rounding from indivisible squads.
        table.sort(slots,function(a,b)
            if a.mass~=b.mass then return a.mass>b.mass end
            if a.row~=b.row then return a.row<b.row end
            return a.offset<b.offset
        end)
        local targets,got={},{}
        for i=1,#choices do targets[i]=shares[i]*total;got[i]=0 end
        local function error_of(values)
            local error=0
            for i=1,#choices do error=error+(values[i]-targets[i])^2 end
            return error
        end
        for _,slot in ipairs(slots)do
            local best,delta
            for i=1,#choices do
                local d=(got[i]+slot.mass-targets[i])^2-(got[i]-targets[i])^2
                if not delta or d<delta-1e-9 then best,delta=i,d end
            end
            slot.choice=best;got[best]=got[best]+slot.mass
        end
        if error_of(initial)<=error_of(got) then
            for i=1,#choices do got[i]=initial[i] end
            for _,slot in ipairs(slots)do slot.choice=slot.initial end
        end
        -- Bounded refinement; never accept a move that worsens the calculated mix.
        for pass=1,8 do
            local changed=false
            for _,slot in ipairs(slots)do
                local from=slot.choice;local best,delta=from,0
                for to=1,#choices do
                    if to~=from then
                        local d=(got[from]-slot.mass-targets[from])^2+(got[to]+slot.mass-targets[to])^2
                            -(got[from]-targets[from])^2-(got[to]-targets[to])^2
                        if d<delta-1e-9 then best,delta=to,d end
                    end
                end
                if best~=from then
                    got[from]=got[from]-slot.mass;got[best]=got[best]+slot.mass
                    slot.choice=best;changed=true
                end
            end
            if not changed then break end
        end
        local changed=0
        for _,slot in ipairs(slots)do
            if slot.choice~=slot.initial then
                records[slot.row]=put(records[slot.row],slot.offset,pack(choices[slot.choice].tag,4))
                changed=changed+1
            end
        end
        local report={templates=template_count,entries=#slots,changed_entries=changed,total=total,before={},after={},requested={}}
        for i,c in ipairs(choices)do
            report.before[c.tag]=initial[i]/total*100;report.after[c.tag]=got[i]/total*100;report.requested[c.tag]=shares[i]*100
            result.summary[#result.summary+1]=string.format('breach_balance_tag=%08x requested=%.4f%% before=%.4f%% after=%.4f%%',c.tag,shares[i]*100,report.before[c.tag],report.after[c.tag])
        end
        result.stats.breach_balance=report
        result.summary[#result.summary+1]=string.format('breach_balance=active_selection_weight_x_quantity group=80 templates=%d entries=%d changed=%d excludes_protected=true budget_conditioned=false',template_count,#slots,changed)
        if not M.is_bug then
            result.stats.reinforcement_balance=report;result.stats.breach_balance=nil
            for i,line in ipairs(result.summary)do result.summary[i]=line:gsub('^breach_balance','reinforcement_balance') end
        end
        result.groups[80]=table.concat(records)
        for i,record in ipairs(records)do
            local t=result.templates[group.address+(i-1)*0x118]
            if t and t.record~=record then t.record=record;t.changed=true end
        end
        return true
    end

    -- Test11: read the actual group-64 selection set before compiling Terminid guards.
    -- This reader has no writes. Duplicate candidate pointers contribute their weights.
    function M.read_guard_selection(read,context,profile,group)
        local counts_at=context+profile.candidate_counts
        local counts=read(counts_at,32);local count=u32(counts,8)
        local pool=profile.pools[3]
        if not count or not pool or count>pool[2] or profile.candidate_stride~=0xd8 then
            return nil,'waiting_for_guard_candidate_bounds'
        end
        if count>0 and not group then return nil,'waiting_for_guard_group' end
        local at=context+pool[1]
        local bytes=count>0 and read(at,count*0xd8) or ''
        if not bytes or read(counts_at,32)~=counts or (count>0 and read(at,#bytes)~=bytes) then
            return nil,'waiting_for_stable_guard_candidates'
        end
        local weights={};local unique=0
        for i=0,count-1 do
            local pointer=ptr(bytes,i*0xd8+0xa8)
            local offset=pointer and pointer-group.address
            local weight=f32(bytes,i*0xd8+0xc0)
            if not offset or offset<0 or offset%0x118~=0 or offset>=#group.bytes then
                return nil,'waiting_for_mapped_guard_candidates'
            end
            if not weight or weight~=weight or weight<0 or weight>1e7 then
                return nil,'waiting_for_guard_candidate_weights'
            end
            if weights[pointer]==nil then weights[pointer]=0;unique=unique+1 end
            weights[pointer]=weights[pointer]+weight
        end
        return {weights=weights,count=count,unique=unique,counts_at=counts_at,counts=counts,address=at,bytes=bytes}
    end

    -- Reassign tags only: preserve entry quantities, metadata, native selection weights,
    -- roster costs, protected entries, uncached templates and every other template group.
    -- Test13: the GuardForce selector rechecks templates after cache construction.
    -- These reads mirror its stable difficulty, context-range and mission-tag inputs.
    function M.read_guard_context(read,base,director)
        if read(base+0x90e238,7)~=raw('488b052982a102')
            or read(base+0x94bca7,7)~=raw('488b05f2a99d02') then
            return nil,'guard_eligibility_signature_changed'
        end
        local checks={}
        local function take(at,n)
            local b=read(at,n);if not b or #b~=n then return nil end
            checks[#checks+1]={at=at,bytes=b};return b
        end
        local ctx=ptr(take(base+0x3326468,8),0)
        local mode=ptr(take(base+0x33266a0,8),0)
        if not ctx or not mode then return nil,'waiting_for_guard_eligibility_context' end
        local range=u32(take(ctx+0x84,4),0)
        local count=u32(take(mode+8,4),0)
        local kind=u32(take(mode+0x40,4),0)
        local diff=u32(take(director+0x518c4,4),0)
        local tags=take(director+0x518d4,68)
        if not range or range>64 or not count or not kind or not diff or diff<1 or diff>10
            or not tags or not u32(tags,64) or u32(tags,64)>16 then
            return nil,'waiting_for_guard_eligibility_context'
        end
        for _,c in ipairs(checks)do
            if read(c.at,#c.bytes)~=c.bytes then return nil,'waiting_for_stable_guard_eligibility_context' end
        end
        local tagset={};for i=0,u32(tags,64)-1 do tagset[u32(tags,i*4)]=true end
        return {range=range,special_tags=count>0 and kind>=1 and kind<=7,difficulty=diff,tags=tagset,checks=checks}
    end

    function M.guard_template_eligible(record,profile,tags)
        local ctx=profile.guard_native_context
        local diff=profile.difficulty
        if not record or #record~=0x118 or not ctx or not diff then
            return nil,'guard_eligibility_context_unavailable'
        end
        if diff<u32(record,0xec) or diff>u32(record,0xf0) then return false,'difficulty' end
        if ctx.range<u32(record,0xf4) or ctx.range>u32(record,0xf8) then return false,'context_range' end
        if u32(record,0x60)==0 then return true end
        for o=0x60,0x7c,4 do
            local tag=u32(record,o)
            if tag~=0 and ((tags or {})[tag] or (ctx.special_tags and tag==0x356ca943)) then return true end
        end
        return false,'mission_tags'
    end

    function M.filter_guard_selection(result,group,weights,profile,tags)
        local filtered={}
        local report={cached=0,eligible=0,difficulty=0,context_range=0,mission_tags=0,zero_weight=0,excluded={}}
        for at,w in pairs(weights)do
            local offset=group and at-group.address
            if not offset or offset<0 or offset%0x118~=0 or offset>=#group.bytes then
                return nil,'guard_eligibility_template_mismatch'
            end
            local record=group.bytes:sub(offset+1,offset+0x118)
            report.cached=report.cached+1
            local ok,why=M.guard_template_eligible(record,profile,tags)
            if ok==nil then return nil,why end
            if w<=0 then ok=false;why='zero_weight' end
            if ok then filtered[at]=w;report.eligible=report.eligible+1
            else
                report[why]=report[why]+1
                report.excluded[#report.excluded+1]={index=offset/0x118,reason=why}
            end
        end
        table.sort(report.excluded,function(a,b)return a.index<b.index end)
        result.stats.guard_eligibility=report
        result.summary[#result.summary+1]=string.format(
            'guard_eligibility group=64 cached=%d eligible=%d excluded_difficulty=%d excluded_context=%d excluded_tags=%d excluded_zero=%d difficulty=%d context=%d scope=ordinary_native_template_gates',
            report.cached,report.eligible,report.difficulty,report.context_range,report.mission_tags,report.zero_weight,
            profile.difficulty,profile.guard_native_context.range)
        for _,e in ipairs(report.excluded)do
            result.summary[#result.summary+1]='guard_eligibility_excluded template='..e.index..' reason='..e.reason
        end
        return filtered
    end

    function M.balance_active_guards(result,group,choices,weights)
        if not group or not choices or #choices==0 then return true end
        local index,shares,initial={}, {}, {}
        local share_total=0
        for i,c in ipairs(choices)do
            if index[c.tag] or not c.share or c.share<=0 then return nil,'invalid_guard_balance_choices' end
            index[c.tag]=i;shares[i]=c.share;initial[i]=0;share_total=share_total+c.share
        end
        for i=1,#shares do shares[i]=shares[i]/share_total end
        local slots,total,template_count={},0,0
        local skipped_multi=0
        local records={}
        local bytes=result.groups[64]
        if not bytes or #bytes~=#group.bytes then return nil,'guard_balance_group_mismatch' end
        for n=0,#bytes/0x118-1 do
            local at=group.address+n*0x118
            local record=bytes:sub(n*0x118+1,(n+1)*0x118);records[n+1]=record
            local w=weights[at]
            if w and w>0 then
                local template=result.templates[at]
                if not template or template.source~='guards' or template.group~=64 then return nil,'guard_balance_template_mismatch' end
                template_count=template_count+1
                local en=entries(record);if not en then return nil,'guard_balance_entries_invalid' end
                if #en>1 then skipped_multi=skipped_multi+1 end
                for _,e in ipairs(en)do
                    local ci=index[e.tag]
                    -- Guard member limits (often 999) are not squad spawn quantities.
                    -- Only the traced single-entry candidate route is balanced here.
                    if ci and #en==1 then
                        local mass=w
                        slots[#slots+1]={row=n+1,at=at,offset=e.o,mass=mass,initial=ci}
                        total=total+mass;initial[ci]=initial[ci]+mass
                    end
                end
            end
        end
        if total==0 then
            result.summary[#result.summary+1]='guard_balance=empty_active_set group=64'
            return true
        end
        -- Largest entries first reduces the unavoidable rounding from indivisible squads.
        table.sort(slots,function(a,b)
            if a.mass~=b.mass then return a.mass>b.mass end
            if a.row~=b.row then return a.row<b.row end
            return a.offset<b.offset
        end)
        local targets,got={},{}
        for i=1,#choices do targets[i]=shares[i]*total;got[i]=0 end
        local function error_of(values)
            local error=0
            for i=1,#choices do error=error+(values[i]-targets[i])^2 end
            return error
        end
        for _,slot in ipairs(slots)do
            local best,delta
            for i=1,#choices do
                local d=(got[i]+slot.mass-targets[i])^2-(got[i]-targets[i])^2
                if not delta or d<delta-1e-9 then best,delta=i,d end
            end
            slot.choice=best;got[best]=got[best]+slot.mass
        end
        if error_of(initial)<=error_of(got) then
            for i=1,#choices do got[i]=initial[i] end
            for _,slot in ipairs(slots)do slot.choice=slot.initial end
        end
        -- Bounded refinement; never accept a move that worsens the calculated mix.
        for pass=1,8 do
            local changed=false
            for _,slot in ipairs(slots)do
                local from=slot.choice;local best,delta=from,0
                for to=1,#choices do
                    if to~=from then
                        local d=(got[from]-slot.mass-targets[from])^2+(got[to]+slot.mass-targets[to])^2
                            -(got[from]-targets[from])^2-(got[to]-targets[to])^2
                        if d<delta-1e-9 then best,delta=to,d end
                    end
                end
                if best~=from then
                    got[from]=got[from]-slot.mass;got[best]=got[best]+slot.mass
                    slot.choice=best;changed=true
                end
            end
            if not changed then break end
        end
        -- Bounded two-way and one-for-two exchanges escape single-move minima.
        -- Runs once during mix compilation; no per-frame balancing work.
        local refinement_moves=0
        if #slots<=32 then
            for pass=1,8 do
                local best,best_delta=nil,-1e-9
                local function consider(i,j,k)
                    local a,b=slots[i],slots[j]
                    if a.choice==b.choice or (k and slots[k].choice~=b.choice) then return end
                    local delta_mass=b.mass+(k and slots[k].mass or 0)-a.mass
                    local ca,cb=a.choice,b.choice
                    local delta=(got[ca]+delta_mass-targets[ca])^2+(got[cb]-delta_mass-targets[cb])^2
                        -(got[ca]-targets[ca])^2-(got[cb]-targets[cb])^2
                    if delta<best_delta then best={i,j,k};best_delta=delta end
                end
                for i=1,#slots do
                    for j=1,#slots do if j~=i then
                        consider(i,j)
                        for k=j+1,#slots do if k~=i then consider(i,j,k) end end
                    end end
                end
                if not best then break end
                local a,b=slots[best[1]],slots[best[2]]
                local c=best[3] and slots[best[3]]
                local ca,cb=a.choice,b.choice
                local delta_mass=b.mass+(c and c.mass or 0)-a.mass
                got[ca]=got[ca]+delta_mass;got[cb]=got[cb]-delta_mass
                a.choice=cb;b.choice=ca;if c then c.choice=ca end
                refinement_moves=refinement_moves+1
            end
        end
        result.summary[#result.summary+1]='guard_balance_refinement bounded_exchange moves='..refinement_moves
            ..' entries='..#slots..' max_passes=8'

        local changed=0
        for _,slot in ipairs(slots)do
            if slot.choice~=slot.initial then
                records[slot.row]=put(records[slot.row],slot.offset,pack(choices[slot.choice].tag,4))
                changed=changed+1
            end
        end
        local report={templates=template_count,entries=#slots,changed_entries=changed,total=total,before={},after={},requested={}}
        for i,c in ipairs(choices)do
            report.before[c.tag]=initial[i]/total*100;report.after[c.tag]=got[i]/total*100;report.requested[c.tag]=shares[i]*100
            result.summary[#result.summary+1]=string.format('guard_balance_tag=%08x requested=%.4f%% before=%.4f%% after=%.4f%%',c.tag,shares[i]*100,report.before[c.tag],report.after[c.tag])
        end
        report.skipped_multi_entry_templates=skipped_multi
        result.summary[#result.summary+1]='guard_balance_member_limits_unchanged=true skipped_multi_entry_templates='..tostring(skipped_multi)
        result.stats.guard_balance=report
        result.summary[#result.summary+1]=string.format('guard_balance=active_selection_weight_single_entry group=64 templates=%d entries=%d changed=%d excludes_protected=true budget_conditioned=false',template_count,#slots,changed)
        result.groups[64]=table.concat(records)
        for i,record in ipairs(records)do
            local t=result.templates[group.address+(i-1)*0x118]
            if t and t.record~=record then t.record=record;t.changed=true end
        end
        return true
    end

    -- Test11: read the actual group-112 selection set before compiling Terminid guard112s.
    -- This reader has no writes. Duplicate candidate pointers contribute their weights.
    function M.read_guard112_selection(read,context,profile,group)
        local counts_at=context+profile.candidate_counts
        local counts=read(counts_at,32);local count=u32(counts,20)
        local pool=profile.pools[6]
        if not count or not pool or count>pool[2] or profile.candidate_stride~=0xd8 then
            return nil,'waiting_for_guard112_candidate_bounds'
        end
        if count>0 and not group then return nil,'waiting_for_guard112_group' end
        local at=context+pool[1]
        local bytes=count>0 and read(at,count*0xd8) or ''
        if not bytes or read(counts_at,32)~=counts or (count>0 and read(at,#bytes)~=bytes) then
            return nil,'waiting_for_stable_guard112_candidates'
        end
        local weights={};local unique=0
        for i=0,count-1 do
            local pointer=ptr(bytes,i*0xd8+0xa8)
            local offset=pointer and pointer-group.address
            local weight=f32(bytes,i*0xd8+0xc0)
            if not offset or offset<0 or offset%0x118~=0 or offset>=#group.bytes then
                return nil,'waiting_for_mapped_guard112_candidates'
            end
            if not weight or weight~=weight or weight<0 or weight>1e7 then
                return nil,'waiting_for_guard112_candidate_weights'
            end
            if weights[pointer]==nil then weights[pointer]=0;unique=unique+1 end
            weights[pointer]=weights[pointer]+weight
        end
        return {weights=weights,count=count,unique=unique,counts_at=counts_at,counts=counts,address=at,bytes=bytes}
    end

    -- Reassign tags only: preserve entry quantities, metadata, native selection weights,
    -- roster costs, protected entries, uncached templates and every other template group.
    function M.balance_active_guard112(result,group,choices,weights)
        if not group or not choices or #choices==0 then return true end
        local index,shares,initial={}, {}, {}
        local share_total=0
        for i,c in ipairs(choices)do
            if index[c.tag] or not c.share or c.share<=0 then return nil,'invalid_guard112_balance_choices' end
            index[c.tag]=i;shares[i]=c.share;initial[i]=0;share_total=share_total+c.share
        end
        for i=1,#shares do shares[i]=shares[i]/share_total end
        local slots,total,template_count={},0,0
        local records={}
        local bytes=result.groups[112]
        if not bytes or #bytes~=#group.bytes then return nil,'guard112_balance_group_mismatch' end
        for n=0,#bytes/0x118-1 do
            local at=group.address+n*0x118
            local record=bytes:sub(n*0x118+1,(n+1)*0x118);records[n+1]=record
            local w=weights[at]
            if w and w>0 then
                local template=result.templates[at]
                if not template or template.source~='guards' or template.group~=112 then return nil,'guard112_balance_template_mismatch' end
                template_count=template_count+1
                local en=entries(record);if not en then return nil,'guard112_balance_entries_invalid' end
                for _,e in ipairs(en)do
                    local ci=index[e.tag]
                    if ci then
                        local mass=w*e.n
                        slots[#slots+1]={row=n+1,at=at,offset=e.o,mass=mass,initial=ci}
                        total=total+mass;initial[ci]=initial[ci]+mass
                    end
                end
            end
        end
        if total==0 then
            result.summary[#result.summary+1]='guard112_balance=empty_active_set group=112'
            return true
        end
        -- Largest entries first reduces the unavoidable rounding from indivisible squads.
        table.sort(slots,function(a,b)
            if a.mass~=b.mass then return a.mass>b.mass end
            if a.row~=b.row then return a.row<b.row end
            return a.offset<b.offset
        end)
        local targets,got={},{}
        for i=1,#choices do targets[i]=shares[i]*total;got[i]=0 end
        local function error_of(values)
            local error=0
            for i=1,#choices do error=error+(values[i]-targets[i])^2 end
            return error
        end
        for _,slot in ipairs(slots)do
            local best,delta
            for i=1,#choices do
                local d=(got[i]+slot.mass-targets[i])^2-(got[i]-targets[i])^2
                if not delta or d<delta-1e-9 then best,delta=i,d end
            end
            slot.choice=best;got[best]=got[best]+slot.mass
        end
        if error_of(initial)<=error_of(got) then
            for i=1,#choices do got[i]=initial[i] end
            for _,slot in ipairs(slots)do slot.choice=slot.initial end
        end
        -- Bounded refinement; never accept a move that worsens the calculated mix.
        for pass=1,8 do
            local changed=false
            for _,slot in ipairs(slots)do
                local from=slot.choice;local best,delta=from,0
                for to=1,#choices do
                    if to~=from then
                        local d=(got[from]-slot.mass-targets[from])^2+(got[to]+slot.mass-targets[to])^2
                            -(got[from]-targets[from])^2-(got[to]-targets[to])^2
                        if d<delta-1e-9 then best,delta=to,d end
                    end
                end
                if best~=from then
                    got[from]=got[from]-slot.mass;got[best]=got[best]+slot.mass
                    slot.choice=best;changed=true
                end
            end
            if not changed then break end
        end
        local changed=0
        for _,slot in ipairs(slots)do
            if slot.choice~=slot.initial then
                records[slot.row]=put(records[slot.row],slot.offset,pack(choices[slot.choice].tag,4))
                changed=changed+1
            end
        end
        local report={templates=template_count,entries=#slots,changed_entries=changed,total=total,before={},after={},requested={}}
        for i,c in ipairs(choices)do
            report.before[c.tag]=initial[i]/total*100;report.after[c.tag]=got[i]/total*100;report.requested[c.tag]=shares[i]*100
            result.summary[#result.summary+1]=string.format('guard112_balance_tag=%08x requested=%.4f%% before=%.4f%% after=%.4f%%',c.tag,shares[i]*100,report.before[c.tag],report.after[c.tag])
        end
        result.stats.guard112_balance=report
        result.summary[#result.summary+1]=string.format('guard112_balance=active_selection_weight_x_quantity group=112 templates=%d entries=%d changed=%d excludes_protected=true budget_conditioned=false',template_count,#slots,changed)
        result.groups[112]=table.concat(records)
        for i,record in ipairs(records)do
            local t=result.templates[group.address+(i-1)*0x118]
            if t and t.record~=record then t.record=record;t.changed=true end
        end
        return true
    end

    -- Compatibility policy for actual hole entities; never zero shared roster tags.
    local small={scavenger_mk3=true,bile_spitter=true,pouncer=true,spore_burst_scavenger=true}
    local medium={hunter_mk3=true,predator_hunter=true,warrior_mk3=true,bile_warrior=true,
                  hive_guard=true,rupture_warrior=true,spore_burst_hunter=true,spore_burst_warrior=true}
    local heavy={bile_titan=true,charger=true,charger_behemoth_mk2=true,impaler=true,
                 rupture_charger=true,spore_burst_bile_titan=true,spore_charger=true}
    local warrior_exit={warrior_mk3=true,bile_warrior=true,hive_guard=true,alpha_commander=true,rupture_warrior=true,spore_burst_warrior=true}
    local hunter_exit={hunter_mk3=true,predator_hunter=true,spore_burst_hunter=true}
    function M.hole_accepts(kind,key,label)
        if label and kind~='heavy' then
            if label=='MK3' then return hunter_exit[key]==true end
            if label=='MK2' or label=='MK6' or label=='MK9' or label=='MK10' then
                if not warrior_exit[key] then return false end
            end
        end
        if kind=='stalker' then return key=='stalker' end
        if kind=='predator_stalker' then return key=='predator_stalker' end
        if kind=='heavy' then return heavy[key]==true end
        if kind=='small' then return small[key]==true end
        if kind=='medium' then return small[key]==true or medium[key]==true end
        if kind=='large' then return not heavy[key] end
        return false
    end

    -- The game's shared variant table: 0x30-byte rows, input hash +8,
    -- replacement hash +0x10. Keep every other byte and every other rule.
    local tank_hashes={
        [raw('67bd8a7b9d91d853')]=true,
        [raw('9c77a39efd9f44c6')]=true,
        [raw('884542b7073ddf63')]=true,
    }
    function M.tanks_requested(profile,compiled)
        if M.is_bug then return false end
        if profile.tanks_stay_tanks then return true end
        for _,mix in pairs(compiled.mixes)do for _,unit in ipairs(mix)do
            if unit.key=='annihilator' or unit.key=='shredder' or unit.key=='barrager' then return true end
        end end
        return false
    end
    function M.requested_tank_hashes(profile,compiled)
        if profile.tanks_stay_tanks then return tank_hashes end
        local selected={}
        for _,mix in pairs(compiled.mixes)do for _,unit in ipairs(mix)do
            local entity=unit.donor and unit.donor:sub(9,16)
            if tank_hashes[entity] then selected[entity]=true end
        end end
        return selected
    end
    function M.neutralize_tank_variants(bytes,tags,difficulty,selected)
        if type(bytes)~='string' or #bytes%0x30~=0 or #bytes>4096*0x30 then return nil,'invalid_variant_table'end
        if tags and (type(difficulty)~='number' or difficulty<1 or difficulty>10)then return nil,'tank_variant_difficulty_unavailable'end
        local walker=raw('c2175a24930257ef');local rows,changed={},{ }
        for o=0,#bytes-1,0x30 do
            local row=bytes:sub(o+1,o+0x30);local from=row:sub(9,16)
            -- Native 949ac3..949b06 filters difficulty and the optional mission tag.
            -- Omitted filters preserve the existing non-native variant path.
            local active=not tags or ((u32(row,0)==0 or tags[u32(row,0)])
                and difficulty>=u32(row,0x20) and difficulty<=u32(row,0x24))
            if active and tank_hashes[from] and (not selected or selected[from]) and row:sub(17,24)==walker then
                changed[#changed+1]=string.format('entry=%d set=%s from=%s previous_to=%s to=%s',o/0x30,hex(row:sub(1,4)),hex(from),hex(walker),hex(from))
                row=put(row,0x10,from)
            end
            rows[#rows+1]=row
        end
        return table.concat(rows),changed
    end

    -- Baseline from the user's original 61-row mission roster, 2026-10-04.
    -- Live eligible donors refresh these values; this is a base-row cost preview.
    M.unit_costs={
        scorcher=130,
        bruiser=120,
        trooper=15,
        trooper_t2=15,
        trooper_t3=15,
        brawler=15,
        commissar=16,
        scout=15,
        berserker=40,
        devastator=45,
        heavy_devastator=60,
        rocket_devastator=60,
        mg_elite=0,
        rocket_elite=0,
        scout_strider=50,
        rocket_strider=60,
        factory_strider=275,
        annihilator=100,
        shredder=100,
        barrager=120,
        assault_walker=135,
        jet_devastator=45,
        legion_cyborg=50,
        legion_rusher=50,
    }
    if M.is_bug then M.unit_costs={} end
    M.captured_unit_costs=M.unit_costs
    M.cost_origin='captured roster'
    -- Transport-sensitive units retain native donor cost, independent of the slider.
    -- Legacy Rocket Strider cost guard retained defensively; walker choices are removed.
    M.fixed_drop_cost=M.is_bug and {} or {annihilator=true,shredder=true,barrager=true,factory_strider=true,rocket_strider=true}
    function M.reduced_cost(cost,divisor,key)
        if type(cost)~='number' or cost~=cost or cost<0 or cost>1e6 or type(divisor)~='number' or divisor~=divisor or divisor<1 or divisor>1000 then return nil end
        if M.fixed_drop_cost[key]then return cost end
        return math.max(1,math.floor(cost/divisor+.5))
    end
    function M.weighted_cost(values,divisor)
        local base,reduced,total=0,0,0
        for _,unit in ipairs(M.units)do
            local weight=values[unit[1]]or 0
            if weight>0 then
                local cost=M.unit_costs[unit[1]];if cost==nil then return nil end
                local adjusted=divisor and M.reduced_cost(cost,divisor,unit[1])or cost
                if not adjusted then return nil end
                base=base+weight*cost/100;reduced=reduced+weight*adjusted/100;total=total+weight
            end
        end
        if math.abs(total-100)>1e-7 then return nil end
        return base,reduced
    end

    -- Test12: use the final retained mix, after eligibility and row-budget fallbacks.
    -- Cache-only pricing: shared roster costs and native template quantities stay intact.
    function M.breach_mix_cost(list)
        local total,cost=0,0
        for _,u in ipairs(list or {})do
            local c=u.donor and f32(u.donor,0x20)
            if not c or c~=c or c<0 or c>1e6 or not u.share or u.share~=u.share or u.share<0 or u.share>1 then
                return nil,'invalid_breach_equalized_cost'
            end
            total=total+u.share;cost=cost+u.share*c
        end
        if total<=0 then return nil end
        return cost/total
    end
    function M.breach_candidate_unit_cost(compiled,profile,source,tag,native_cost,restore)
        if not restore and M.is_bug and source=='drops'
            and (tag==compiled.synthetic.drops or (compiled.source_tags.drops or {})[tag]) then
            return math.max(0.01,(compiled.breach_equalized_cost or native_cost)*(profile.bug_breach_cost or 1))
        end
        return native_cost
    end

    function M.compile(profile,rows,groups,tags)
        if #(profile.mix_errors or {})>0 then return nil,table.concat(profile.mix_errors,';')end
        local known,kept,donors,protected,tagset={},{},{},{},{}
        local tagged_donors,tag_overrides={},{}
        for _,h in ipairs(profile.entities_le) do known[raw(h)]=true end
        for _,h in ipairs(profile.keep_entities_le or {}) do kept[raw(h)]=true end
        local original={}
        local troopers={}
        for _,name in ipairs(profile.trooper_names or {})do
            local hash=profile.names[name]or profile.units[name];if hash then troopers[raw(hash)]=true end
        end
        for _,hash in ipairs(profile.trooper_le or {})do troopers[raw(hash)]=true end
        for o=0,#rows-1,128 do
            local r=rows:sub(o+1,o+128);local tag=u32(r,0);local id=r:sub(9,16)
            if #r~=128 or not tag or tag==0 or u32(r,4)~=0 or not known[id] then return nil,'roster_layout_unknown' end
            original[#original+1]=r;tagset[tag]=true
            if kept[id] then protected[tag]=true end -- preserve even mixed convoy/spawner tags
            if eligible(r,tags) then
                if not donors[id] then donors[id]=r end
            elseif not tagged_donors[id] then
                tagged_donors[id]=r
            end
            for d=0,9 do local w=f32(r,0x30+d*4);if not w or w<0 or w>1e7 then return nil,'invalid_native_weight' end end
            local cost=f32(r,0x20);if not cost or cost<0 or cost>1e6 then return nil,'invalid_native_cost' end
        end
        -- A roster-present unit may be used even when its donor row has another mission tag.
        -- Clear tag gates on the copied donor only; native rows stay intact until normal
        -- mix replacement. This applies to every faction and every mix source.
        for id,r in pairs(tagged_donors)do
            if not donors[id] then
                donors[id]=put(r,0x58,string.rep('\0',0x20))
                tag_overrides[id]=true
            end
        end
        local divisor=profile.drop_cost_divisor or 1
        local breach_cost=M.is_bug and (profile.bug_breach_cost or 1) or 1
        if type(breach_cost)~='number' or breach_cost<0.05 or breach_cost>5 then return nil,'invalid_breach_cost'end
        if not M.reduced_cost(1,divisor)then return nil,'invalid_drop_cost_divisor'end
        M.unit_costs={};for key,value in pairs(M.captured_unit_costs)do M.unit_costs[key]=value end
        for _,unit in ipairs(M.units)do
            local hash=profile.names[unit[3]]or profile.units[unit[3]]
            local donor=hash and donors[raw(hash)]
            if donor then M.unit_costs[unit[1]]=f32(donor,0x20)end
        end
        M.cost_origin='mission base rows (fallback: captured roster)'
        local drop_factory_tags={}
        local watcher_tags={}
        for _,row in ipairs(original)do
            local hash=hex(row:sub(9,16))
            if hash=='e336280d128d7ed3' or hash=='e7b746fb022724bc' then drop_factory_tags[u32(row,0)]=true end
            if M.is_illuminate and hash=='9d8c093584e760ac' and eligible(row,tags) then watcher_tags[u32(row,0)]=true end
        end
        for _,row in ipairs(original)do
            local tag=u32(row,0)
            if watcher_tags[tag] and hex(row:sub(9,16))~='9d8c093584e760ac' then watcher_tags[tag]=nil end
        end
        -- Identify the authored singleton route from a live native template,
        -- rather than assuming a fixed tag or using another Watcher pool row.
        local native_watcher_tag
        local patrol_group=groups[32]
        if M.is_illuminate and patrol_group then
            for o=0,#patrol_group.bytes/0x118-1 do
                local e=entries(patrol_group.bytes:sub(o*0x118+1,(o+1)*0x118))
                if e and #e==1 and e[1].n==1 and watcher_tags[e[1].tag] then
                    native_watcher_tag=e[1].tag;break
                end
            end
        end
        local result={rows={},groups={},templates={},summary={},mixes={},protected=protected,stats={tag_overrides={}},original_rows=original,warnings={},source_tags={}}
        for _,src in ipairs(M.sources) do
            local list,why
            -- Test38: the POI/Nests tab is retired for every faction; Terminid holes follow Guards.
            if src.key=='outposts' or (profile.mix_vanilla and profile.mix_vanilla[src.key]) then list={}
            else
                for key,value in pairs(profile.mixes[src.key]or {})do
                    if not M.allowed(src.key,key) and type(value)=='number' and value>0 then return nil,'unit_not_supported_on_'..src.key..':'..key end
                end
                list,why=M.normalize(profile.mixes[src.key] or {})
            end
            if not list then return nil,src.key..':'..why end
            if profile.disable_leviathans and #list>0 then
                local filtered,total,removed={},0,false
                for _,u in ipairs(list)do
                    if u.key=='leviathan' then removed=true
                    else filtered[#filtered+1]=u;total=total+u.share end
                end
                if removed then
                    if total>0 then for _,u in ipairs(filtered)do u.share=u.share/total;u.weight=u.share*100 end end
                    result.warnings[#result.warnings+1]=src.key..' leviathan_disabled '..(#filtered>0 and 'remaining_units_renormalized' or 'tab_left_native')
                    list=filtered
                end
            end
            local missing={}
            for _,u in ipairs(list) do
                local h=profile.names[u.name] or profile.units[u.name]
                u.donor=h and donors[raw(h)]
                -- Test38: a unit is used only where the mission switches at least one of its rows on. A row is never
                -- copied with its mission-tag gate cleared: the game does not load that unit's assets on this planet,
                -- and it spawns as a missing-resource "?" model (seen live: Pouncer on a Bile Bugs planet).
                if u.donor and tag_overrides[raw(h)] then u.donor=nil;u.off_planet=true end
                if h and tag_overrides[raw(h)] then result.stats.tag_overrides[#result.stats.tag_overrides+1]=u.key end
                if not u.donor then missing[#missing+1]=u.key end
            end
            -- Test38 partial fallback: skip a unit absent from this roster and split its share between the
            -- tab's remaining units. Never silent: a WARNING line reaches the log, mix file and load banner.
            if #missing>0 then
                local kept,total,off,absent={},0,{},{}
                for _,u in ipairs(list)do
                    if u.donor then kept[#kept+1]=u;total=total+u.share
                    elseif u.off_planet then off[#off+1]=u.key else absent[#absent+1]=u.key end
                end
                for _,u in ipairs(kept)do u.share=u.share/total;u.weight=u.share*100 end
                local why={}
                if #off>0 then why[#why+1]='skipped_not_loaded_on_this_planet='..table.concat(off,',') end
                if #absent>0 then why[#why+1]='skipped_not_in_roster='..table.concat(absent,',') end
                result.warnings[#result.warnings+1]=src.key..' '..table.concat(why,' ')..(#kept>0 and ' remaining_units_renormalized' or ' tab_left_native')
                list=kept
            end
            result.mixes[src.key]=list
            local desc={};for _,u in ipairs(list) do desc[#desc+1]=string.format('%s=%.2f%%',u.key,u.share*100)end
            result.summary[#result.summary+1]=src.key..' '..(#desc==0 and 'VANILLA' or table.concat(desc,' '))
        end
        -- Bot drops use the selected units' original roster rows and tags. Never
        -- publish a copied donor under a synthetic tag to an unmodded client.
        local native_drop_tag,native_drop_rows,native_drop_counts,native_drop_choices,native_drop_preserved
        if not M.is_bug and #result.mixes.drops>0 then
            native_drop_tag=true;native_drop_rows={};native_drop_counts={};native_drop_choices={};native_drop_preserved={}
            local native_drop_refs={}
            local drop_group=groups[80]
            if not drop_group then return nil,'native_drop_templates_missing' end
            for o=0,#drop_group.bytes/0x118-1 do
                local record=drop_group.bytes:sub(o*0x118+1,(o+1)*0x118)
                local en=entries(record);if not en then return nil,'native_drop_template_layout_changed' end
                for _,e in ipairs(en)do native_drop_refs[e.tag]=(native_drop_refs[e.tag] or 0)+1 end
            end
            local by_tag={}
            for _,u in ipairs(result.mixes.drops)do
                local id=u.donor:sub(9,16)
                local best,best_refs
                for _,r in ipairs(original)do
                    local tag=u32(r,0)
                    if r:sub(9,16)==id and eligible(r,tags) and (not protected[tag] or u.key=='factory_strider') then
                        local refs=native_drop_refs[tag] or 0
                        if not best or refs>best_refs then best=tag;best_refs=refs end
                    end
                end
                if not best then return nil,'native_drop_row_unavailable_or_protected:'..u.key end
                u.native_drop_tag=best
                if protected[best] then native_drop_preserved[best]=true end
                if not by_tag[best]then
                    by_tag[best]={tag=best,share=0}
                    native_drop_choices[#native_drop_choices+1]=by_tag[best]
                end
                by_tag[best].share=by_tag[best].share+u.share
                for i,r in ipairs(original)do
                    if u32(r,0)==best and r:sub(9,16)==id then
                        native_drop_rows[i]=u.key
                        if eligible(r,tags) then native_drop_counts[u.key]=(native_drop_counts[u.key] or 0)+1 end
                    end
                end
                if not native_drop_counts[u.key] then return nil,'native_drop_row_not_eligible:'..u.key end
            end
            for i,r in ipairs(original)do
                if by_tag[u32(r,0)] and not native_drop_rows[i] then native_drop_rows[i]='' end
            end
            result.native_bot_drops=true
            local desc={};for _,choice in ipairs(native_drop_choices)do desc[#desc+1]=string.format('%08x=%.2f%%',choice.tag,choice.share*100)end
            result.summary[#result.summary+1]='native_bot_drops=ON tags='..table.concat(desc,',')..' rows=original_indices descriptor=original special_entries=preserved'
            if M.is_illuminate then
                result.summary[#result.summary+1]='illuminate_drop_balance=cached_mission_templates count='..tostring(profile.active_drop_template_count or 0)
            end
        end
        -- Test38 Terminid native rows (hybrid). Each tab reweights the selected units' own native rows under
        -- one native tag per unit, and repoints its template entries at those tags. A tag belongs to one mix
        -- (identical mixes on several tabs share it). A unit gets a pool row only when no native row can be
        -- used: every row of it is gated off by mission tags, its tags are claimed by a different mix, or it
        -- sits only in protected or Alpha summon family tags. Breach costs keep their own candidate pricing.
        local bug_plans,bug_native_rows,bug_refs_by_group
        if M.is_bug then
            bug_plans={};bug_native_rows={}
            local claims,by_key={},{}
            local alpha_family=0x8f7704f8
            local function mix_key(src)
                local parts={}
                for _,u in ipairs(result.mixes[src.key])do parts[#parts+1]=u.key..'='..string.format('%.8f',u.share) end
                if src.key=='drops' and divisor~=1 then parts[#parts+1]='drop_cost='..tostring(divisor) end
                return table.concat(parts,'|')
            end
            local refs_by_group={}
            for g,grp in pairs(groups)do
                local refs={}
                for o=0,#grp.bytes/0x118-1 do
                    local en=entries(grp.bytes:sub(o*0x118+1,(o+1)*0x118))
                    if en then for _,e in ipairs(en)do refs[e.tag]=(refs[e.tag] or 0)+1 end end
                end
                refs_by_group[g]=refs
            end
            bug_refs_by_group=refs_by_group
            local entities_of={}
            for _,r in ipairs(original)do
                local t=u32(r,0);local set=entities_of[t] or {};entities_of[t]=set;set[r:sub(9,16)]=true
            end
            for _,src in ipairs(M.sources)do
                local list=result.mixes[src.key]
                if src.key~='outposts' and #list>0 then
                    local key=mix_key(src)
                    local plan=by_key[key]
                    if not plan then
                        plan={key=key,native={},pooled={},by_tag={},tags={},counts={},sources={}}
                        by_key[key]=plan
                        local own,other={},{}
                        for g,refs in pairs(refs_by_group)do
                            local mine=false;for _,sg in ipairs(src.groups)do if sg==g then mine=true end end
                            for t,n in pairs(refs)do if mine then own[t]=(own[t] or 0)+n else other[t]=(other[t] or 0)+n end end
                        end
                        local selected_ids={};for _,u in ipairs(list)do selected_ids[u.donor:sub(9,16)]=true end
                        for _,u in ipairs(list)do
                            local id=u.donor:sub(9,16)
                            local best,best_score
                            for _,r in ipairs(original)do
                                local t=u32(r,0)
                                local c=claims[t]
                                local ok_claim=not c or (c.n==1 and c.plans[plan]) or (c.single==id and not c.plans[plan])
                                if r:sub(9,16)==id and eligible(r,tags) and not protected[t] and t~=alpha_family
                                    and not troopers[id] and ok_claim then
                                    local foreign=0;for e in pairs(entities_of[t])do if not selected_ids[e] then foreign=foreign+1 end end
                                    local score=(own[t] or 0)*1000-(other[t] or 0)*10-foreign
                                    if not best or score>best_score then best,best_score=t,score end
                                end
                            end
                            if best then
                                local c=claims[best]
                                if not c then c={plans={},n=0,units={}};claims[best]=c end
                                if not c.plans[plan] then c.plans[plan]=true;c.n=c.n+1 end
                                c.units[id]=true
                                local k=0;for _ in pairs(c.units)do k=k+1 end
                                c.single=k==1 and id or false
                                u.native_tag=best;plan.native[#plan.native+1]=u
                                if not plan.by_tag[best] then plan.by_tag[best]={tag=best,share=0};plan.tags[#plan.tags+1]=best end
                            else
                                plan.pooled[#plan.pooled+1]=u
                            end
                        end
                    end
                    plan.sources[#plan.sources+1]=src.key
                    bug_plans[src.key]=plan
                end
            end
            -- Every row under a claimed tag is owned by its plan: the selected unit's eligible rows carry its
            -- share, every other row under that tag is weighted 0 at all difficulties.
            -- Rows under a claimed tag are reserved (never reused as pool slots); their weights are written from
            -- the final plans after any fallback, below.
            for i,r in ipairs(original)do
                local t=u32(r,0)
                if claims[t] then bug_native_rows[i]={tag=t} end
            end
        end
        local synth={};local used={};for t in pairs(tagset)do used[t]=true end
        -- COMPACT ROSTER: the compiled roster keeps exactly the original rows in the original order and never appends
        -- a row (a roster longer than the native one can hand clients a row index they do not have).
        -- Outposts and POIs: every replaceable native row (not a trooper, not under a protected tag) is given a unit in
        -- proportion to the mix. Pools for patrols, drops, guards: each needs one row per unit, taken from replaceable
        -- native rows that repeat an earlier tag (the first row of every tag stays, so the native name array rule holds).
        for i,r in ipairs(original) do result.rows[i]=r end
        local first_of_tag,replaceable,slots,pool_used={},{},{},{}
        local difficulty=profile.difficulty
        if type(difficulty)~='number' or difficulty<1 or difficulty>10 or difficulty%1~=0 then return nil,'mission_difficulty_unavailable' end
        local native_positive={}
        for i,r in ipairs(original) do
            local t=u32(r,0);if not first_of_tag[t] then first_of_tag[t]=i end
            replaceable[i]=(not protected[t]) and (not troopers[r:sub(9,16)]) and not (native_drop_rows and native_drop_rows[i]) and not (bug_native_rows and bug_native_rows[i]) and not (M.is_bug and profile.alpha_summon_rows and t==0x8f7704f8)
            local weight=f32(r,0x30+(difficulty-1)*4)
            if eligible(r,tags) and weight>0 then native_positive[t]=(native_positive[t] or 0)+1 end
        end
        for i,r in ipairs(original) do
            local t=u32(r,0)
            if replaceable[i] and first_of_tag[t]~=i then
                local positive=eligible(r,tags) and f32(r,0x30+(difficulty-1)*4)>0
                if not positive or (native_positive[t] or 0)>1 then
                    slots[#slots+1]=i
                    if positive then native_positive[t]=native_positive[t]-1 end
                end
            end
        end
        local outpost=result.mixes.outposts
        local slot_next=0
        local function weighted(row,tag,weight)
            row=put(row,0,pack(tag,4)..'\0\0\0\0')
            return put(row,0x30,string.rep(float(weight),10))
        end
        local function newtag()
            local n=0xf1000001;while used[n]do n=n+1 end;used[n]=true
            return n
        end
        local pool_wanted=0
        local function pool_row(row)
            pool_wanted=pool_wanted+1
            slot_next=slot_next+1;local s=slots[slot_next]
            if not s then return false end
            pool_used[s]=true;result.rows[s]=row;return true
        end
        local function pool_key(src)
            if not M.is_bug then return src.key end
            local parts={}
            for _,u in ipairs(result.mixes[src.key])do parts[#parts+1]=u.key..'='..string.format('%.8f',u.share) end
            -- Terminid breach prices are applied to breach candidates, so an
            -- identical mix can share roster rows with patrols and guards.
            if src.key=='drops' and divisor~=1 then parts[#parts+1]='drop_cost='..tostring(divisor) end
            return table.concat(parts,'|')
        end
        do
            -- Pool rows needed per tab. Terminid tabs need rows only for units without a usable native row.
            local function compute_need()
                local need,parts,counted=0,{},{}
                for _,src in ipairs(M.sources)do
                    if src.key~='outposts' and #result.mixes[src.key]>0 and not (native_drop_tag and src.key=='drops') then
                        if M.is_bug then
                            local plan=bug_plans[src.key]
                            if plan and not counted[plan] then need=need+#plan.pooled;counted[plan]=true end
                            parts[#parts+1]=src.key..'='..(plan and #plan.pooled or 0)
                        else
                            local key=pool_key(src)
                            if not counted[key] then need=need+#result.mixes[src.key];counted[key]=true end
                            parts[#parts+1]=src.key..'='..#result.mixes[src.key]
                            if src.key=='patrols' then
                                local has_factory,others=false,0
                                for _,u in ipairs(result.mixes.patrols)do if u.key=='factory_strider' then has_factory=true else others=others+1 end end
                                if has_factory then need=need+math.max(1,others);parts[#parts+1]='patrol_non_factory='..math.max(1,others) end
                            end
                        end
                    end
                end
                return need,parts
            end
            local need,parts=compute_need()
            -- Test38 partial fallback: when spare rows run out, first drop Terminid units that only have pool
            -- rows (their share moves to the tab's native units), then leave whole tabs native, Guards first,
            -- then Drops/Breaches, then Patrols. Every step is reported.
            if need>#slots then
                local first=string.format('rows_short need=%d (%s) free=%d',need,table.concat(parts,' '),#slots)
                -- Drop pool-only units one at a time (smallest share first, Guards, then Breaches, then Patrols) and
                -- only as many as needed; their share moves to the tab's remaining units.
                for _,k in ipairs({'guards','drops','patrols'})do
                    local plan=M.is_bug and bug_plans[k]
                    while need>#slots and plan and #plan.pooled>0 and (#plan.native+#plan.pooled)>1 do
                        table.sort(plan.pooled,function(a,b)if a.share~=b.share then return a.share>b.share end return a.key<b.key end)
                        local u=table.remove(plan.pooled)
                        plan.trimmed=plan.trimmed or {};plan.trimmed[#plan.trimmed+1]=u.key
                        local total=0
                        for _,n in ipairs(plan.native)do total=total+n.share end
                        for _,n in ipairs(plan.pooled)do total=total+n.share end
                        local kept={}
                        for _,n in ipairs(plan.native)do n.share=n.share/total;n.weight=n.share*100;kept[#kept+1]=n end
                        for _,n in ipairs(plan.pooled)do n.share=n.share/total;n.weight=n.share*100;kept[#kept+1]=n end
                        for _,sk in ipairs(plan.sources)do result.mixes[sk]=kept end
                        need,parts=compute_need()
                    end
                    if plan and plan.trimmed then
                        local desc={};for _,u in ipairs(result.mixes[k])do desc[#desc+1]=string.format('%s=%.2f%%',u.key,u.share*100)end
                        for _,sk in ipairs(plan.sources)do
                            result.warnings[#result.warnings+1]=sk..' skipped_no_free_row='..table.concat(plan.trimmed,',')..' remaining_units_renormalized'
                            for si,line in ipairs(result.summary)do if line:sub(1,#sk+1)==sk..' ' then result.summary[si]=sk..' '..table.concat(desc,' ') end end
                        end
                        plan.trimmed=nil;result.stats.trimmed=true
                    end
                end
                for _,k in ipairs({'guards','drops','patrols'})do
                    if need<=#slots then break end
                    if #result.mixes[k]>0 and not (native_drop_tag and k=='drops') and not (M.is_bug and (not bug_plans[k] or #bug_plans[k].pooled==0)) then
                        local plan=M.is_bug and bug_plans[k]
                        local victims=plan and plan.sources or {k}
                        for _,sk in ipairs(victims)do
                            result.mixes[sk]={};if plan then bug_plans[sk]=nil end
                            for si,line in ipairs(result.summary)do if line:sub(1,#sk+1)==sk..' ' then result.summary[si]=sk..' VANILLA (left native: not enough spare rows)' end end
                            result.warnings[#result.warnings+1]=sk..' tab_left_native '..first
                        end
                        if plan then for i,info in pairs(bug_native_rows)do if info.plan==plan then bug_native_rows[i]=nil end end end
                        need,parts=compute_need()
                    end
                end
                if need>#slots then
                    return nil,string.format('safe_row_budget_exceeded: patrols, drops and guards need %d pool rows (%s) but only %d rows can be reused without emptying native spawn tags. Use fewer distinct mixes or units per tab.',need,table.concat(parts,' '),#slots)
                end
            end
            -- Claiming a native tag also changes templates that stay native (nest/POI templates and tabs left on
            -- game weights) where they reference that tag. While spare rows remain, move such "leaky" units to
            -- pool rows so native templates keep their units; when rows are short, native rows win.
            if M.is_bug and need<#slots and not result.stats.trimmed then
                local free=#slots-need
                local active_group={}
                for _,src in ipairs(M.sources)do if bug_plans[src.key] then for _,g in ipairs(src.groups)do active_group[g]=true end end end
                local cand={}
                local seen={}
                for _,src in ipairs(M.sources)do
                    local plan=bug_plans[src.key]
                    if plan and not seen[plan] then
                        seen[plan]=true
                        for _,u in ipairs(plan.native)do
                            local leak=0
                            for g,refs in pairs(bug_refs_by_group)do if not active_group[g] then leak=leak+(refs[u.native_tag] or 0) end end
                            if leak>0 then cand[#cand+1]={plan=plan,u=u,leak=leak} end
                        end
                    end
                end
                table.sort(cand,function(a,b)if a.leak~=b.leak then return a.leak>b.leak end return a.u.key<b.u.key end)
                for _,c in ipairs(cand)do
                    if free<=0 then break end
                    local plan,u=c.plan,c.u
                    for i,n in ipairs(plan.native)do if n==u then table.remove(plan.native,i);break end end
                    plan.pooled[#plan.pooled+1]=u
                    local still=false;for _,n in ipairs(plan.native)do if n.native_tag==u.native_tag then still=true end end
                    if not still then
                        for i,info in pairs(bug_native_rows)do if info.plan==plan and info.tag==u.native_tag then bug_native_rows[i]=nil end end
                        plan.by_tag[u.native_tag]=nil
                        for i,t in ipairs(plan.tags)do if t==u.native_tag then table.remove(plan.tags,i);break end end
                    end
                    result.stats.leak_moves=(result.stats.leak_moves or 0)+1
                    free=free-1;u.native_tag=nil
                end
                need=#slots-free
            end
            result.stats.pool_rows_needed=need
        end
        local group_source={}
        local shared_pools={}
        local choices_for={}
        if native_drop_tag then choices_for.drops=native_drop_choices end
        for _,src in ipairs(M.sources)do
            for _,g in ipairs(src.groups)do group_source[g]=src.key end
            if native_drop_tag and src.key=='drops' then
                synth.drops=native_drop_choices[1].tag
                local selected={};for _,u in ipairs(result.mixes.drops)do selected[u.key]=u end
                for i,key in pairs(native_drop_rows)do
                    local r=original[i];local u=selected[key]
                    local tag=u32(r,0);local tag_share=0
                    for _,choice in ipairs(native_drop_choices)do if choice.tag==tag then tag_share=choice.share;break end end
                    if not native_drop_preserved[tag] then
                        local weight=u and eligible(r,tags) and (u.share/tag_share*100/native_drop_counts[key]) or 0
                        r=put(r,0x30,string.rep(float(weight),10))
                        if u then r=put(r,0x20,float(M.reduced_cost(f32(original[i],0x20),divisor,key))) end
                    end
                    result.rows[i]=r
                end
            elseif M.is_bug and bug_plans[src.key] then
                local plan=bug_plans[src.key]
                if not plan.choices then
                    plan.choices={}
                    for _,t in ipairs(plan.tags)do plan.by_tag[t].share=0 end
                    for _,u in ipairs(plan.native)do plan.by_tag[u.native_tag].share=plan.by_tag[u.native_tag].share+u.share end
                    for _,t in ipairs(plan.tags)do if plan.by_tag[t].share>0 then plan.choices[#plan.choices+1]=plan.by_tag[t] end end
                    if #plan.pooled>0 then
                        local ptotal=0;for _,u in ipairs(plan.pooled)do ptotal=ptotal+u.share end
                        local tag=newtag()
                        for _,u in ipairs(plan.pooled)do
                            if not pool_row(weighted(u.donor,tag,u.share/ptotal*100)) then return nil,'safe_row_budget_exceeded: '..src.key..' pool' end
                        end
                        plan.choices[#plan.choices+1]={tag=tag,share=ptotal,pool=true}
                    end
                end
                choices_for[src.key]=plan.choices
                synth[src.key]=plan.choices[1] and plan.choices[1].tag
            elseif not M.is_bug and src.key=='patrols' and #result.mixes.patrols>0 then
                choices_for.patrols={}
                for _,u in ipairs(result.mixes.patrols)do
                    local tag=newtag()
                    if not pool_row(weighted(u.donor,tag,100)) then return nil,'safe_row_budget_exceeded: patrol unit tags' end
                    choices_for.patrols[#choices_for.patrols+1]={tag=tag,share=u.share,key=u.key}
                    synth.patrols=synth.patrols or tag
                end
                result.summary[#result.summary+1]='patrol_unit_tags=separate_existing_pool_rows'
            elseif src.key~='outposts' and #result.mixes[src.key]>0 then
                local key=pool_key(src)
                synth[src.key]=shared_pools[key]
                if not synth[src.key] then
                    synth[src.key]=newtag();shared_pools[key]=synth[src.key]
                    for _,u in ipairs(result.mixes[src.key])do
                        local r=weighted(u.donor,synth[src.key],u.share*100)
                        if src.key=='drops' and not M.is_bug then
                            r=put(r,0x20,float(M.reduced_cost(f32(u.donor,0x20),divisor,u.key)))
                        end
                        if not pool_row(r) then return nil,string.format('safe_row_budget_exceeded: %s needs %d pool rows, %d free',src.key,#result.mixes[src.key],#slots-(slot_next-1)) end
                    end
                end
            end
        end
        -- A patrol uses at most two draws that can select Factory Striders.
        -- Remaining slots draw only non-Factory units, preserving their count.
        local patrol_factory=false
        local patrol_factory_tag
        local patrol_other_tag
        for _,u in ipairs(result.mixes.patrols)do if u.key=='factory_strider'then patrol_factory=true end end
        if patrol_factory then
            for _,choice in ipairs(choices_for.patrols or {})do
                if choice.key=='factory_strider' then patrol_factory_tag=choice.tag end
            end
            patrol_factory_tag=patrol_factory_tag or synth.patrols
            result.patrol_balance_limits={[patrol_factory_tag]=2}
            local other={};local total=0
            for _,u in ipairs(result.mixes.patrols)do
                if u.key~='factory_strider'then other[#other+1]=u;total=total+u.share end
            end
            if #other==0 then
                local fallback=donors[raw(profile.names.cha_conscript_tier_3)]
                if not fallback then return nil,'patrol_factory_trooper_fallback_unavailable'end
                other={{donor=fallback,share=1}}
                total=1
            end
            patrol_other_tag=newtag()
            for _,u in ipairs(other)do
                if not pool_row(weighted(u.donor,patrol_other_tag,u.share/total*100)) then return nil,'row_budget_exceeded: patrol factory pool' end
            end
        end
        -- Compact roster: a context that stays vanilla keeps its native tags. When an outposts mix is active those native
        -- rows carry the outposts mix, so a vanilla context follows it (reported in the log, never an extra row).
        local function vanilla_tag(t)
            result.stats.vanilla_follows_outposts=(result.stats.vanilla_follows_outposts or 0)+1
            return t
        end
        -- A separate native trooper entry leaves the percentage mixture unchanged. The native trooper rows are never
        -- touched, so the extra entry points at the native tag itself (no copy rows).
        local patrol_extra=(profile.mix_vanilla and profile.mix_vanilla.patrols)and 0 or(profile.patrol_extra_troopers or 0)
        if patrol_extra~=0 and patrol_extra~=2 and patrol_extra~=3 and patrol_extra~=4 then return nil,'invalid_patrol_extra_troopers'end
        local patrol_extra_tag
        if patrol_extra>0 then
            local native_tag=u32(raw(profile.patrol.tag),0)
            for _,r in ipairs(original)do if u32(r,0)==native_tag then
                if not troopers[r:sub(9,16)]then return nil,'patrol_extra_tag_not_troopers'end
                patrol_extra_tag=native_tag
            end end
            if not patrol_extra_tag then return nil,'patrol_extra_trooper_tag_missing'end
        end
        -- Guards: a tag without troopers draws from the guards pool. A tag that mixes troopers keeps its native tag: the
        -- trooper rows stay, its other rows follow the outposts mix (no per-tag copies in compact mode).
        local function guarded_tag(tag)
            local has_trooper
            for _,r in ipairs(original)do if u32(r,0)==tag and troopers[r:sub(9,16)]then has_trooper=true end end
            if not has_trooper then return synth.guards end
            result.stats.guard_tags_native=(result.stats.guard_tags_native or 0)+1
            return tag
        end
        local native_cursors={}
        -- Terminid native rows: the selected unit's eligible rows under its claimed tag carry its share of
        -- that tag; every other row under a claimed tag is weighted 0 at all ten difficulties. Costs are kept.
        if bug_native_rows then
            -- Final native weights per claimed tag. A tag still used by a plan keeps only that plan's selected units:
            -- each unit's eligible rows share its fraction of the tag (one unit -> 100%), all other rows get 0.
            -- A tag no plan uses any more keeps its native rows untouched.
            local tag_units={}
            local done={}
            for _,src in ipairs(M.sources)do
                local plan=bug_plans[src.key]
                if plan and not done[plan] then
                    done[plan]=true
                    local by={}
                    for _,u in ipairs(plan.native)do
                        local t=u.native_tag
                        if t then by[t]=by[t] or {total=0,units={}};by[t].total=by[t].total+u.share;by[t].units[#by[t].units+1]=u end
                    end
                    for t,v in pairs(by)do if not tag_units[t] then tag_units[t]=v end end
                end
            end
            for t,v in pairs(tag_units)do
                local counts={}
                for _,r in ipairs(original)do
                    if u32(r,0)==t and eligible(r,tags) then local id=r:sub(9,16);counts[id]=(counts[id] or 0)+1 end
                end
                for i,r in ipairs(original)do
                    if u32(r,0)==t then
                        local weight=0
                        for _,u in ipairs(v.units)do
                            local id=u.donor:sub(9,16)
                            if r:sub(9,16)==id and eligible(r,tags) and counts[id] then weight=u.share/v.total*100/counts[id] end
                        end
                        result.rows[i]=put(r,0x30,string.rep(float(weight),10))
                    end
                end
            end
        end
        for src,choices in pairs(choices_for)do
            result.source_tags[src]={};for _,c in ipairs(choices)do result.source_tags[src][c.tag]=true end
        end
        for _,g in ipairs(profile.groups)do
            local source=group_source[g[1]] or 'outposts'
            local input=groups[g[1]]
            if input then
                local records={}
                for i=0,#input.bytes/0x118-1 do
                    local record=input.bytes:sub(i*0x118+1,(i+1)*0x118)
                    local en=entries(record);if not en then return nil,'invalid_template_entries' end
                    local keep_native_watcher=source=='patrols' and M.is_illuminate
                        and profile.illuminate_keep_native_watcher_patrols and native_watcher_tag
                        and #en==1 and en[1].tag==native_watcher_tag and en[1].n==1
                    if keep_native_watcher then
                        result.stats.native_watcher_patrol_records=(result.stats.native_watcher_patrol_records or 0)+1
                    end
                    local balance_offsets={}
                    local changed=false;local total,first=0,nil
                    for _,e in ipairs(en)do
                        total=total+e.n
                        if source=='drops' and synth.drops and drop_factory_tags[e.tag] and protected[e.tag] then
                            result.stats.factory_drop_entries_preserved=(result.stats.factory_drop_entries_preserved or 0)+1
                        end
                        if tagset[e.tag] and not protected[e.tag] and not keep_native_watcher then
                            local tag=synth[source]
                            local choices=choices_for[source]
                            if choices and #choices>1 and M.is_illuminate and source=='drops' and profile.active_drop_templates then
                                -- The game filters group 80 before purchasing reinforcements. Balance the
                                -- cached mission templates separately from templates it did not select.
                                local active=profile.active_drop_templates[input.address+i*0x118] == true
                                local key=active and 'drops_cached' or 'drops_uncached'
                                local st=native_cursors[key] or {total=0,got={}};native_cursors[key]=st
                                local w=math.max(1,e.n);local best,gap
                                for ci,choice in ipairs(choices)do
                                    local g=choice.share*(st.total+w)-(st.got[ci] or 0)
                                    if not gap or g>gap+1e-12 then best,gap=ci,g end
                                end
                                st.got[best]=(st.got[best] or 0)+w;st.total=st.total+w
                                tag=choices[best].tag
                                if active then result.stats.illuminate_cached_drop_entries=(result.stats.illuminate_cached_drop_entries or 0)+1 end
                            elseif choices and #choices>1 and M.is_bug then
                                -- Terminid: give each entry to the tag furthest below its share so far, weighting an
                                -- entry by its unit count (999 guard member limits count as 16).
                                local st=native_cursors[source] or {total=0,got={}};native_cursors[source]=st
                                local w=math.min(math.max(1,e.n),16);local best,gap
                                for ci,choice in ipairs(choices)do
                                    local g=choice.share*(st.total+w)-(st.got[ci] or 0)
                                    if not gap or g>gap+1e-12 then best,gap=ci,g end
                                end
                                st.got[best]=(st.got[best] or 0)+w;st.total=st.total+w
                                tag=choices[best].tag
                            elseif choices and #choices>1 then
                                -- Spread entries over native tags by share (per-tab low-discrepancy cursor).
                                local cursor=native_cursors[source] or 0
                                local point=(cursor*0.61803398875)%1
                                native_cursors[source]=cursor+math.max(1,e.n)
                                local cumulative=0
                                for _,choice in ipairs(choices)do
                                    cumulative=cumulative+choice.share
                                    if point<cumulative then tag=choice.tag;break end
                                end
                                if point>=cumulative then tag=choices[#choices].tag end
                            elseif choices and #choices==1 then tag=choices[1].tag end
                            if source=='guards' and tag and not M.is_bug then
                                local why;tag,why=guarded_tag(e.tag);if not tag then return nil,why end
                            end
                            if source~='outposts' and not tag and #outpost>0 then
                                tag=vanilla_tag(e.tag);if not tag then return nil,'native_tag_anchor_capacity' end
                            end
                            if tag then record=put(record,e.o,pack(tag,4));changed=true;first=first or e;balance_offsets[e.o]=true end
                        end
                    end
                    if source=='patrols' and patrol_factory and synth.patrols then
                        local available=2
                        local remainder=0
                        local last_other
                        for _,e in ipairs(entries(record))do
                            if e.tag==patrol_factory_tag or drop_factory_tags[e.tag] then
                                if available>0 then
                                    local permitted=math.min(e.n,available)
                                    available=available-permitted
                                    if e.n>permitted then
                                        record=put(record,e.o+4,pack(permitted,4));remainder=remainder+e.n-permitted
                                    end
                                else
                                    record=put(record,e.o,pack(patrol_other_tag,4))
                                    last_other=e.o
                                end
                            elseif e.tag==patrol_other_tag then last_other=e.o end
                        end
                        if remainder>0 then
                            if last_other then
                                local old=u32(record,last_other+4)
                                if not old or old+remainder>1000 then return nil,'patrol_factory_remainder_overflow'end
                                record=put(record,last_other+4,pack(old+remainder,4))
                            else
                                if #en>=8 then return nil,'patrol_factory_template_full'end
                                record=put(record,#en*12,pack(patrol_other_tag,4)..pack(remainder,4)..pack(0,4))
                            end
                        end
                    end
                    if source=='drops' and synth.drops and first and total<(profile.drop_fill.fill or 0) then
                        record=put(record,first.o+4,pack(first.n+profile.drop_fill.fill-total,4));changed=true
                    end
                    if source=='patrols' and patrol_extra_tag and #en>0 then
                        if #en>=8 then return nil,'patrol_extra_template_full'end
                        record=put(record,#en*12,pack(patrol_extra_tag,4)..pack(patrol_extra,4)..pack(0,4))
                        changed=true;result.stats.patrol_extra_records=(result.stats.patrol_extra_records or 0)+1
                    end
                    -- Direct entity fields bypass weighted tags; keep these visibly accounted for.
                    local id=record:sub(0x101,0x108)
                    if known[id] and not kept[id] and #result.mixes[source]>0 then
                        result.stats.direct_bypass=(result.stats.direct_bypass or 0)+1
                    end
                    records[#records+1]=record
                    local at=input.address+i*0x118
                    local reserved_factory=0
                    if source=='patrols' and patrol_factory_tag then
                        for _,e in ipairs(entries(record))do
                            if e.tag~=patrol_factory_tag and drop_factory_tags[e.tag] then reserved_factory=reserved_factory+e.n end
                        end
                    end
                    local prior=result.templates[at]
                    if prior and prior.source~=source then return nil,'shared_template_source_ambiguous' end
                    result.templates[at]={record=record,source=source,group=g[1],changed=changed,original_record=input.bytes:sub(i*0x118+1,(i+1)*0x118),original_address=at,balance_reserved_factory=reserved_factory,balance_offsets=not M.is_bug and balance_offsets or nil}
                end
                result.groups[g[1]]=table.concat(records)
            end
        end
        if profile.active_patrol_templates and not profile.mix_vanilla.patrols then
            local ok,why=M.balance_active_patrols(result,groups[32],choices_for.patrols,profile.active_patrol_templates)
            if not ok then return nil,why end
        end
        if profile.active_breach_templates and not profile.mix_vanilla.drops then
            local ok,why=M.balance_active_breaches(result,groups[80],choices_for.drops,profile.active_breach_templates)
            if not ok then return nil,why end
        end
        if M.is_bug and profile.active_guard_templates and not profile.mix_vanilla.guards then
            local filtered,why=M.filter_guard_selection(result,groups[64],profile.active_guard_templates,profile,tags)
            if not filtered then return nil,why end
            local ok,why=M.balance_active_guards(result,groups[64],choices_for.guards,filtered)
            if not ok then return nil,why end
        end
        if M.is_bug and profile.active_guard112_templates and not profile.mix_vanilla.guards then
            local ok,why=M.balance_active_guard112(result,groups[112],choices_for.guards,profile.active_guard112_templates)
            if not ok then return nil,why end
        end
        if M.is_illuminate and profile.illuminate_keep_native_watcher_patrols then
            result.summary[#result.summary+1]='native_solo_watcher_patrols_preserved='..tostring(result.stats.native_watcher_patrol_records or 0)
        end
        -- Outposts and POIs, in place: spread the mix over the replaceable native rows that are not pool rows. Rows are taken
        -- tag group by tag group and each takes the unit that is furthest below its share, so every tag sees the mix.
        local outposts=result.mixes.outposts
        local assigned_rows=0
        if #outposts>0 then
            local order,seen,bytag={},{},{}
            for i=1,#original do
                if replaceable[i] and not pool_used[i] then
                    local t=u32(original[i],0)
                    if not seen[t] then seen[t]=true;order[#order+1]=t;bytag[t]={} end
                    bytag[t][#bytag[t]+1]=i
                end
            end
            -- Weight aware: a row's chance to be drawn is its weight at the mission difficulty, so the share each unit
            -- gets is measured in that weight (the mean of the ten difficulty weights if the difficulty is unknown).
            local diff=profile.difficulty
            local function weight_of(r)
                if type(diff)=='number' and diff>=1 and diff<=10 then return f32(r,0x30+(math.floor(diff)-1)*4) or 0 end
                local s=0;for d=0,9 do s=s+(f32(r,0x30+d*4) or 0) end;return s/10
            end
            local count,wsum,done,wtotal={},{},0,0
            local choice,rowweight={},{}
            for _,u in ipairs(outposts)do count[u.key]=0;wsum[u.key]=0 end
            result.stats.outposts_difficulty=type(diff)=='number' and diff or 0
            for _,t in ipairs(order)do
                for _,i in ipairs(bytag[t])do
                    done=done+1
                    local r=original[i]
                    local w=weight_of(r)
                    local best,gap
                    if w>0 then
                        for _,u in ipairs(outposts)do
                            local g=u.share*(wtotal+w)-wsum[u.key]
                            if not gap or g>gap+1e-12 then best,gap=u,g end
                        end
                        wtotal=wtotal+w;wsum[best.key]=wsum[best.key]+w
                    else
                        -- never drawn at this difficulty: keep the unit counts level, it changes no probability
                        for _,u in ipairs(outposts)do
                            local g=u.share*done-count[u.key]
                            if not gap or g>gap+1e-12 then best,gap=u,g end
                        end
                    end
                    count[best.key]=count[best.key]+1
                    choice[i]=best;rowweight[i]=w
                    assigned_rows=assigned_rows+1
                end
            end
            -- Refinement: move single rows between units while that brings the weight shares closer to the requested ones.
            local function mismatch()
                local e=0
                for _,u in ipairs(outposts)do e=e+math.abs(wsum[u.key]-u.share*wtotal) end
                return e
            end
            local moved=0
            for _=1,8 do
                local improved=false
                for i,u in pairs(choice)do
                    local w=rowweight[i]
                    if w>0 then
                        local base=mismatch()
                        for _,v in ipairs(outposts)do
                            if v~=u and count[u.key]>1 then
                                wsum[u.key]=wsum[u.key]-w;wsum[v.key]=wsum[v.key]+w
                                if mismatch()<base-1e-9 then
                                    choice[i]=v;count[u.key]=count[u.key]-1;count[v.key]=count[v.key]+1
                                    u=v;base=mismatch();improved=true;moved=moved+1
                                else
                                    wsum[u.key]=wsum[u.key]+w;wsum[v.key]=wsum[v.key]-w
                                end
                            end
                        end
                    end
                end
                if not improved then break end
            end
            for i,best in pairs(choice)do
                local r=original[i]
                result.rows[i]=r:sub(1,8)..best.donor:sub(9,0x30)..r:sub(0x31)
            end
            result.stats.outposts_refined=moved
            result.stats.outposts_weights=wsum
            result.stats.outposts_counts=count
        end
        if #result.rows~=#original then return nil,'compact_row_count_changed' end
        if #result.rows>64 then return nil,'compiled_roster_too_large' end
        result.stats.pool_rows_used=slot_next;result.stats.pool_rows_free=#slots
        result.stats.outposts_rows=assigned_rows
        for _,move in ipairs(result.stats.native_anchor_relocations or {})do
            result.summary[#result.summary+1]=string.format('native_anchor_relocated from_row=%d to_row=%d tag=%08x',move.from-1,move.to-1,move.tag)
        end
        if bug_plans then
            local done={}
            for _,src in ipairs(M.sources)do
                local plan=bug_plans[src.key]
                if plan and not done[plan] and plan.choices then
                    done[plan]=true
                    local d={}
                    for _,c in ipairs(plan.choices)do d[#d+1]=string.format('%s%08x=%.2f%%',c.pool and 'pool:' or '',c.tag,c.share*100) end
                    local pooled={};for _,u in ipairs(plan.pooled)do pooled[#pooled+1]=u.key end
                    result.summary[#result.summary+1]='native_rows tabs='..table.concat(plan.sources,',')..' tags='..table.concat(d,',')..' pooled_units='..(#pooled>0 and table.concat(pooled,',') or 'none')
                end
            end
        end
        for _,w in ipairs(result.warnings)do result.summary[#result.summary+1]='WARNING '..w end
        result.summary[#result.summary+1]=string.format('compact_roster rows=%d (native %d, limit 64) pool_rows=%d/%d outposts_rows=%d vanilla_entries_following_outposts=%d guard_tags_with_troopers=%d',#result.rows,#original,slot_next,#slots,assigned_rows,result.stats.vanilla_follows_outposts or 0,result.stats.guard_tags_native or 0)
        -- The native Commander summon family contains both spawned Warriors
        -- and Hive Guards. Replace all its identities so native emissions can
        -- never draw an unselected member. Keep its native timing and behavior.
        if M.is_bug and profile.alpha_summon_rows then
            local selection=profile.bug_alpha_unit or 9
            if selection==1 then selection=math.random(1,#profile.alpha_summon_rows)+1 end
            local choice=profile.alpha_summon_rows[selection-1]
            if not choice then return nil,'alpha_summon_choice_invalid' end
            profile.bug_alpha_resolved_unit=selection
            local target=raw(choice.row):sub(9,16)
            local n=0
            for i,r in ipairs(original)do
                if u32(r,0)==0x8f7704f8 then
                    if result.rows[i]~=r then return nil,'alpha_summon_family_conflict' end
                    if profile.bug_alpha_summon==false then
                        result.rows[i]=put(r,0x30,string.rep(float(0),10))
                    else
                        result.rows[i]=put(r,8,target)
                    end
                    n=n+1
                end
            end
            if n==0 then return nil,'alpha_summon_family_missing' end
            result.stats.alpha_summon_rows=n
            result.alpha_summon_choice=profile.bug_alpha_summon==false and 'OFF' or choice.name
            result.summary[#result.summary+1]='alpha_summon_roster unit='..result.alpha_summon_choice..' rows='..n..' method=entity_substitution'
        end
        if profile.disable_leviathans then
            local leviathan=raw('07f1be377b022df2')
            local n=0
            for i,r in ipairs(original)do
                if r:sub(9,16)==leviathan then
                    if result.rows[i]~=r then return nil,'leviathan_roster_row_conflict' end
                    result.rows[i]=put(r,0x30,string.rep(float(0),10))
                    n=n+1
                end
            end
            if n>0 then
                result.stats.leviathan_disabled_rows=n
                result.summary[#result.summary+1]='leviathan_roster_weights=0 rows='..n..' native_group96_retained'
            else
                result.summary[#result.summary+1]='leviathan_roster_row_absent'
            end
        end
        if M.is_bug then
            if profile.bug_breach_equalize_costs==true then
                local cost,why=M.breach_mix_cost(result.mixes.drops)
                if why then return nil,why end
                result.breach_equalized_cost=cost
            end
            local cost=result.breach_equalized_cost
            result.summary[#result.summary+1]='breach_equalized_costs requested='..tostring(profile.bug_breach_equalize_costs==true)
                ..' active='..tostring(cost~=nil)..' method=retained_mix_weighted_native_cost'
                ..(cost and string.format(' unit_cost=%.6f multiplier=%.4f effective_unit_cost=%.6f',cost,breach_cost,math.max(0.01,cost*breach_cost)) or '')
                ..' scope=selected_breach_candidate_entries roster_costs_unchanged=true'
        end
        result.row_bytes=table.concat(result.rows);result.synthetic=synth
        result.pass_through=not result.stats.patrol_extra_records and not result.stats.alpha_summon_rows and not result.stats.leviathan_disabled_rows
        for _,list in pairs(result.mixes)do if #list>0 then result.pass_through=false end end
        return result
    end
    return M
end

-- Roster-only Alpha summon selection. No executable patches or animation polling.
local bug_special_controls=(function()
 local M={roster={}}
 M.roster={
 {name='Hunter MK3',family=4128243721,spawn_ability=308,package='f3ea1d048dd07167',row='307ea3d100000000bac045744432a85c01000000000000000000000000000000000088410000803f00000000000000000000000000000000000000000000803f0000803f0000803f0000803f0000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Charger',family=4128243723,spawn_ability=231,package='fe4cc1b69b282bea',row='029e67a200000000b064c698ffcd7f1a020000000100000000000000000000000000c8420000004000000000000000000000803f0000803f0000803f0000803f0000803f0000803f9a99193fcdcccc3e9a99993e0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Charger Behemoth MK2',family=4128243724,spawn_ability=231,package='2fee91dabcd28f57',row='029e67a2000000004cacb367ecd15ba0020000000100000000000000000000000000c842000000400000000000000000000000000000000000000000000000000000000000000000cdcccc3e9a99193f3333333f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Stalker',family=4128243728,spawn_ability=415,package='e6290d2abffe82c0',row='82b0b05d000000002e424a9d9dca40f501000000010000000000000000000000000048420000004000000000000000000000000000000000000000000000803f0000803f0000803f0000803f0000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000100000000000000'},
 {name='Nursing Spewer MK2',family=4128243729,spawn_ability=194,package='d74c4c4d94304f21',row='c16a826d000000009b0872d1fd2270cc01000000010000000000000000000000000020420000004000000000000000000000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Shrieker',family=4128243731,spawn_ability=388,package='6c07038ae004cc58',row='57522a9600000000dd3524508800096400000000000000000000000000000000000000000000a04000000000000000000000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Alpha Commander',family=4128243734,spawn_ability=481,package='32317f100e081acb',row='ad510b3900000000df974365bbd89cf700000000000000000000000000000000000020420000803f0000000000000000000000000000000000000000000000000000000000000000000000000000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Alpha Warrior',family=4128243735,spawn_ability=481,package='a182233ca927523c',row='f804778f00000000e6c784421efaa6b200000000000000000000000000000000000000000000803f0000000000000000000000000000000000000000000000000000000000000000000000000000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000100000000000000'},
 {name='Spore Charger',family=4128243736,spawn_ability=231,package='04147333a4ed9771',row='029e67a2000000005e60abf49223206b020000000100000000000000000000000000c842000000400000000000000000000000000000000000000000000000000000000000000000cdcc4c3ecdcc4c3e9a99993e9a99993e00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Bile Titan',family=4128243727,spawn_ability=439,package='eb5d0301ae9cc5fa',row='4676033200000000ddafccccf2172e9e03000000010000000000000000000000000034430000004100000000000000000000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f0000803f00000000000000000000000000000000000000000000000000000000000000000000000000000000'},
 {name='Impaler',family=4128243733,spawn_ability=329,package='9e5d7e5aea777b98',dependent='79bc74310ca7c450',row='6533d92d000000003beefb1242e7f8dc020000000000000000000000000000000000a042000000400000000000000000000000000000000000000000000000000000803fcdcc4c3ecdcc4c3ecdcc4c3e9a99993e9a99993e00000000000000000000000000000000000000000000000000000000000000000000000000000000'}
 }
 M.signatures={
 [0x12fe680]='4883ec28488b057d7c0202488b4810ff914003000085c00f',
 [0x12fe350]='4585c00f8475010000415641574883ec3848895c24504c8b'
 }
 function M.new(mem,base,B,emit)
  local ffi=require('ffi')
  local s={last=nil,verified=false,failed=false,packages=nil,cloud_ready=false}
  local function ptr(b,o)return B.ptr(b,o or 0)end
  local function object(rva)return ptr(mem.read(base+rva,8))end
  local function log(t)emit('ALPHA_COMMANDER_SUMMON '..t)end
  local request=ffi.cast('void (*)(void *,const uint64_t *,uint32_t)',base+0x12fe350)
  local ready=ffi.cast('uint8_t (*)(void *)',base+0x12fe680)
  function s.stop()s.last=nil;s.packages=nil;s.cloud_ready=false end
  local function packages(selection,callers)
   local q=object(0x347ceb0);if not q then return false end
   local key=tostring(q)..':'..tostring(selection)..':'..tostring(callers)
   if s.packages~=key then
    s.cloud_ready=false
    local unique,values={},{}
    local function add(package)
     if package and not unique[package]then unique[package]=true;values[#values+1]=package end
    end
    for i,r in ipairs(M.roster)do
     if selection==i+1 or (callers and r.name=='Hunter MK3')then
      add(r.package);add(r.dependent)
     end
    end
    if #values==0 then return true end
    local h=mem.read(q,24);local p=ptr(h);local cap=B.u32(h,8)
    if not p or not cap or cap<1 or cap>65536 then return false end
    local map=mem.read(p,cap*16);if not map then return false end
    local free=0;for i=0,cap-1 do if map:sub(i*16+1,i*16+8)==h:sub(17,24)then free=free+1 end end
    if free<#values then return false end
    local a=ffi.new('uint64_t[?]',#values)
    for i,v in ipairs(values)do ffi.copy(a+i-1,B.raw(v),8)end
    request(ffi.cast('void *',q),a,#values);s.packages=key;log('packages_requested')
    return false
   end
   local loaded=ready(nil)~=0
   if callers then s.cloud_ready=loaded end
   return loaded
  end
  function s.tick(t,active,p)
   if not active then if s.last then s.stop()end;return end
   if s.failed or (s.last and t-s.last<0.5)then return end
   s.last=t
   local ok,why=pcall(function()
    if not s.verified then
     for rva,hex in pairs(M.signatures)do
      local b=B.raw(hex);assert(mem.read(base+rva,#b)==b,'package_signature_changed')
     end
     s.verified=true
    end
    local callers=p.bug_charger_calls or p.bug_stalker_calls or p.bug_titan_calls or p.bug_shrieker_calls
    if p.bug_alpha_summon~=false and p.bug_alpha_resolved_unit then packages(p.bug_alpha_resolved_unit,callers)
    elseif callers then packages(nil,true)end
   end)
   if not ok then s.failed=true;s.stop();log('package_error '..tostring(why))end
  end
  return s
 end
 function M.cloud(mem,base,B,has_node,emit)
  local ffi=require('ffi')
  local s={checked=false,valid=false}
  -- This is the particle used by the native Hunter/Pouncer calling puff,
  -- emitted at the caller before the shared reinforcement request.
  local particle=ffi.new('uint64_t[1]')
  ffi.copy(particle,B.raw('9b749ce87ac66ca5'),8)
  local send=ffi.cast('void (*)(void *,uint64_t,uint32_t)',base+0x11b3310)
  local function ptr(b,o)return B.ptr(b,o or 0)end
  local function tableptr()
   local lib=ptr(mem.read(base+0x346bf98,8))
   return lib and ptr(mem.read(lib+0xf127b8,8))
  end
  function s.finish()end -- the native one-shot puff expires on its own
  function s.begin(c)
   if not s.checked then
    s.checked=true
    local expected=B.raw('48895c24084889742410574883ec20')
    s.valid=mem.read(base+0x11b3310,#expected)==expected
    if not s.valid then emit('BUG_CLOUD disabled_emitter_signature')end
   end
   if not s.valid or mem.read(c.owner,24)~=c.raw then return false end
   local tp=tableptr();local map=tp and mem.read(tp,1376*16)
   if not map then return false end
   local ix,mapping,identity
   for i=0,1375 do
    if map:sub(i*16+1,i*16+8)==c.raw:sub(1,8)then
     ix=B.u32(map,i*16+8);mapping=tp+i*16;identity=map:sub(i*16+1,i*16+16);break
    end
   end
   -- Live Test27 capture: Shriekers have no NPC effect-definition row.
   -- The particle emitter takes a unit handle and node directly; it does not
   -- need that row. Use the same root fallback as Stalkers for this identity.
   local missing_shrieker=not ix and c.raw:sub(1,8)==B.raw('dd35245088000964')
   if not missing_shrieker and (not ix or ix>=1376)then return false end
   local records
   if not missing_shrieker then
    records=mem.read(tp+1376*16+ix*0xf48+8,32*80)
    if not records then return false end
   end
   local handle=B.u32(c.raw,12);local node,source
   if handle and has_node(handle,0x8c5570c9)==1 then node=0x8c5570c9;source='hunter_call_node'end
   if not node and records then
    -- An authored effect attachment is a valid attachment for this exact NPC.
    -- Some Terminid rigs reject the old bot-oriented live-node check even for
    -- their own effect nodes, so use the NPC definition as the authority.
    for i=0,31 do
     local r=records:sub(i*80+1,(i+1)*80)
     local n=B.u32(r,0x20)
     if n and n~=0 and r:sub(1,8)~=string.rep('\0',8)then node=n;source='authored_effect_node';break end
    end
   end
   -- Stalkers have no authored effect slots in the current build. Node zero is
   -- the transform root accepted by the emitter; log it for live validation.
   if not node then node=0;source=missing_shrieker and 'shrieker_transform_root' or 'transform_root'end
   if tableptr()~=tp or (mapping and mem.read(mapping,16)~=identity)
    or (missing_shrieker and mem.read(tp,1376*16)~=map) or mem.read(c.owner,24)~=c.raw then return false end
   local ok,why=pcall(send,ffi.cast('void *',c.owner),particle[0],node)
   if not ok then emit('BUG_CLOUD emitter_error '..tostring(why));return false end
   emit('BUG_CLOUD caller_puff_submitted unit='..c.id..' node='..node..' source='..source)
   return true
  end
  return s
 end
 return M
end)()


local unit_mix=make_unit_mix()
-- Test38: subfaction units (Predator, Spore Burst, Rupture strains) are not selectable. Spore Charger is a common spawn and stays.
-- Predator Stalker stays selectable: no conversion produces it, so it is picked directly (Predator Strain missions only;
-- elsewhere the partial fallback skips it and renormalizes the tab). Saved weights for them
-- migrate visibly: the remaining selected units are renormalized, or the tab becomes native if nothing remains.
local bug_mix=make_unit_mix({is_bug=true,prefix='bug_mix_',strain_only={predator_stalker=true},removed_units={'scavenger_mk2','hunter_mk2','warrior_mk2','brood_commander','bile_spewer','nursing_spewer','charger_behemoth',
  'predator_hunter','rupture_charger','rupture_spewer','rupture_warrior','spore_burst_bile_titan','spore_burst_hunter','spore_burst_scavenger','spore_burst_warrior'},
 -- Test39: nest/POI guard forces (template group +112) follow the Guards mix, like nest holes.
 sources={{key='patrols',label='Patrols',groups={32}},
          {key='drops',label='Bug breaches',groups={80}},
          {key='guards',label='Guards',groups={64,112}},
          {key='outposts',label='Rules',groups={}}},
 units={
  {'scavenger_mk3','Scavenger MK3','Scavenger MK3'},
 {'alpha_commander','Alpha Commander','Alpha Commander'},
 {'bile_spewer_mk2','Bile Spewer MK2','Bile Spewer MK2'},
 {'bile_spitter','Bile Spitter','Bile Spitter'},
 {'bile_titan','Bile Titan','Bile Titan'},
 {'bile_warrior','Bile Warrior','Bile Warrior'},
 {'charger','Charger','Charger'},
 {'charger_behemoth_mk2','Charger Behemoth MK2','Charger Behemoth MK2'},
 {'hive_guard','Hive Guard','Hive Guard'},
 {'hunter_mk3','Hunter MK3','Hunter MK3'},
 {'impaler','Impaler','Impaler'},
 {'nursing_spewer_mk2','Nursing Spewer MK2','Nursing Spewer MK2'},
 {'pouncer','Pouncer','Pouncer'},
 {'predator_stalker','Predator Stalker (Pred Strain Planet)','Predator Stalker'},
 {'shrieker','Shrieker','Shrieker'},
 {'spore_charger','Spore Charger','Spore Charger'},
 {'stalker','Stalker','Stalker'},
 {'warrior_mk3','Warrior MK3','Warrior MK3'},
}})

-- Illuminate uses its native 46-row enemy descriptor. Warp Ship payloads use
-- the same native-row publication as bot drops. The civilian/worker descriptors
-- at +0x668 and +0x670 and special template groups are never selected here.
local illuminate_mix=make_unit_mix({is_illuminate=true,prefix='illuminate_mix_',removed_units={},
 source_exclusions={
  patrols={stingray=true,leviathan=true},
  drops={stingray=true,leviathan=true,watcher=true},
  guards={stingray=true,leviathan=true,watcher=true},
 },
 sources={{key='patrols',label='Patrols',groups={32}},
          {key='drops',label='Warp Ship reinforcements',groups={80}},
          {key='guards',label='Guards',groups={64,112}},
          {key='outposts',label='Rules',groups={}}},
 units={
  {'voteless_light','Voteless Light','Voteless Light'},
  {'voteless_medium','Voteless Medium','Voteless Medium'},
  {'voteless_heavy','Voteless Heavy','Voteless Heavy'},
  {'overseer','Overseer','Overseer'},
  {'elevated_overseer','Elevated Overseer','Elevated Overseer'},
  {'crescent_overseer','Crescent Overseer','Crescent Overseer'},
  {'watcher','Watcher (calls reinforcements)','Watcher'},
  {'fleshmob','Fleshmob','Fleshmob'},
  {'stingray','Stingray (large)','Stingray'},
  {'harvester','Harvester (large)','Harvester'},
  {'leviathan','Leviathan (large)','Leviathan'},
  {'veracitor','Veracitor (mission gated)','Veracitor'},
  {'gatekeeper','Gatekeeper (mission gated)','Gatekeeper'},
  {'obtruder','Obtruder (mission gated)','Obtruder'},
  {'crusher','Crusher (mission gated)','Crusher'},
  {'wretch','Wretch (mission gated)','Wretch'},
}})

-- Entity-specific spawner cache control. No native roster tags are zeroed here.
local bug_hole_cache=(function()
 local M={}
 M.types={
  ['70abf0e97831dd97']={'MK1','predator_stalker'},
  ['89972d9ca732869d']={'MK2','medium'},
  ['065e6d8c54f82abc']={'MK3','medium'},
  ['11d304d861aa66d6']={'MK4','small'},
  ['f951d04953c9589b']={'MK5','small'},
  ['788db12bad8ecc36']={'MK6','medium'},
  ['3ba1193fcfa17647']={'MK7','stalker'},
  ['4b6b36db88f10189']={'MK8','small'},
  ['61bd9c7549b7318c']={'MK9','medium'},
  ['0d14625cfff08bf7']={'MK10','large'},
  ['eb7a54cfad81a1b6']={'MK11',false}, -- current cached member still needs mapping
  ['88a032ed12ef2c3a']={'Titan','heavy'},
 }
 function M.new(mem,base,mix,emit,writefile)
  local B=mix.binary
  local s={clones={},ours={},held={},clone_count=0,last_report=nil,changes=0}
  local function ptr(bytes,off)return B.ptr(bytes,off or 0)end
  local function report(summary,lines)
   if summary==s.last_report then return end
   s.last_report=summary;emit('BUG_HOLE_CACHE '..summary)
   if writefile then
    local out={'Test16: actual hole spawner selections; animation family and tier policy. Counts cover loaded mission spawners, not one nest.',summary}
    for _,line in ipairs(lines or {})do out[#out+1]=line end
    writefile('PickYourBots_holes.txt',table.concat(out,'\n')..'\n')
   end
  end
  local function host()
   local r=ptr(mem.read(base+0x3326d60,8));local h=r and mem.read(r,0x88)
   local cap=B.u32(h,0x70);local desc=ptr(h,0x80);local slots=ptr(h,0x68)
   if not cap or cap<1 or cap>16 or not desc or not slots then return false end
   local d=mem.read(desc,24);local map=mem.read(slots,cap*8)
   if not d or not map or B.u32(d,20)%2~=1 or B.u32(d,8)==B.u32(h,0x74)then return false end
   for i=0,cap-1 do if B.u32(map,i*8)==B.u32(d,8)then return B.u32(map,i*8+4)==0 end end
   return false
  end
  local function snapshot()
   local manager=ptr(mem.read(base+0x33265c8,8));local h=manager and mem.read(manager,0x60)
   local cap,n=B.u32(h,0xc),B.u32(h,0x14)
   local owners,data,flags=ptr(h,0x40),ptr(h,0x48),ptr(h,0x58)
   if cap~=128 or not n or n>128 or(n>0 and(not owners or not data or not flags))then return nil end
   local ob=n==0 and ''or mem.read(owners,n*8)
   local records=n==0 and ''or mem.read(data,n*0x238)
   local fb=n==0 and ''or mem.read(flags,n*2)
   if not ob or not records or not fb then return nil end
   return {manager=manager,n=n,owners=owners,data=data,flags=flags,ob=ob,records=records,fb=fb}
  end
  local function identity(v,i,owner,desc,count)
   if ptr(mem.read(base+0x33265c8,8))~=v.manager then return false end
   local h=mem.read(v.manager,0x60)
   return B.u32(h,0xc)==128 and B.u32(h,0x14)==v.n
    and ptr(h,0x40)==v.owners and ptr(h,0x48)==v.data and ptr(h,0x58)==v.flags
    and ptr(mem.read(v.owners+i*8,8))==owner and mem.read(owner,24)==desc
    and B.u32(desc,20)%2==1 and B.u32(mem.read(v.data+i*0x238+0x108,4),0)==count
  end
  local function offsets(rec)
   local n,cursor=B.u32(rec,0x108),B.u32(rec,0x80)
   if not n or n>16 or not cursor or cursor>8 then return nil end
   local out={};for o=0x40,0x78,8 do out[#out+1]=o end
   for j=0,n-1 do out[#out+1]=0x88+j*8 end
   return out,n
  end
  local function key(v,owner,desc)return tostring(v.manager)..':'..tostring(owner)..':'..B.hex(desc)end
  function s.restore()
   if next(s.ours)==nil and next(s.held)==nil then return 0 end
   if not host()then return 0 end
   local v=snapshot();if not v then return 0 end
   local restored=0
   for i=0,v.n-1 do
    local owner=ptr(v.ob,i*8);local desc=owner and mem.read(owner,24)
    local rec=v.records:sub(i*0x238+1,(i+1)*0x238)
    local list,count=offsets(rec)
    if desc and M.types[B.hex(desc:sub(1,8))]and list then
     for _,off in ipairs(list)do
      local p=ptr(rec,off);local ours=p and s.ours[p]
      if ours and mem.read(ours.source,256)==ours.original and identity(v,i,owner,desc,count)then
       local at=v.data+i*0x238+off
       if mem.read(at,8)==B.pack(p) and mem.write(at,B.pack(ours.source))then restored=restored+1 end
      end
     end
     local id=key(v,owner,desc);local prior=s.held[id]
     if prior and identity(v,i,owner,desc,count)then
      local at=v.flags+i*2
      if mem.read(at,1)=='\1'and mem.write(at,prior)then s.held[id]=nil;restored=restored+1 end
     end
    end
   end
   return restored
  end
  function s.tick(compiled,block_titans)
   -- Test38: nest holes follow the Guards mix (the Nests tab is retired).
   local choices=compiled and compiled.mixes and compiled.mixes.guards
   if not choices or #choices==0 then
    local restored=s.restore();report('guards_vanilla_holes_native restored='..restored);return
   end
   if not host()then report('waiting_for_host');return end
   local v=snapshot();if not v then report('manager_unavailable');return end
   local native={};for _,r in ipairs(compiled.original_rows)do native[r]=true end
   for _,r in ipairs(compiled.rows or {})do native[r]=true end
   local cache,lines,seen={},{},{}
   local holes,patched,paused,unknown,failed=0,0,0,0,0
   for i=0,v.n-1 do
    local owner=ptr(v.ob,i*8);local desc=owner and mem.read(owner,24)
    local kind=desc and M.types[B.hex(desc:sub(1,8))]
    if kind then
     holes=holes+1
     local rec=v.records:sub(i*0x238+1,(i+1)*0x238)
     local list,count=offsets(rec);local id=key(v,owner,desc);seen[id]=true
     local allowed={}
     for _,choice in ipairs(choices)do
      if not (block_titans and (choice.key=='bile_titan' or choice.key=='spore_burst_bile_titan'))
       and mix.hole_accepts(kind[2],choice.key,kind[1])then allowed[#allowed+1]=choice end
     end
     local label=kind[1]
     if not kind[2]then unknown=unknown+1;lines[#lines+1]=label..' unmapped; native selections retained'
     elseif not list or B.u32(desc,20)%2~=1 then failed=failed+1
     elseif #allowed==0 then
      local at=v.flags+i*2;local flag=mem.read(at,1)
      if flag=='\0'and identity(v,i,owner,desc,count)and mem.read(at,1)==flag and mem.write(at,'\1')then s.held[id]=flag;flag='\1';s.changes=s.changes+1 end
      if flag=='\1'then paused=paused+1 else failed=failed+1 end
      lines[#lines+1]=label..' no compatible selected bug; production_disabled='..tostring(flag=='\1')
     else
      local touched,bad=0,0;local selected={}
      for _,off in ipairs(list)do
       local p=ptr(rec,off)
       if p then
        local owned=s.ours[p];local src=owned and owned.source or p
        local row=cache[src]
        if row==nil then row=mem.read(src,256)or false;cache[src]=row end
        if not row or not native[row:sub(1,128)]then bad=bad+1
        else
         -- Repeatable allowed-set selection; exact hole percentages are not required.
         local pick=allowed[((B.u32(desc,8)+math.floor(off/8))%#allowed)+1];selected[pick.key]=true
         local bytes=row:sub(1,8)..pick.donor:sub(9,128)..row:sub(129)
         local ck=tostring(src)..':'..bytes
         local replacement=s.clones[ck]
         if not replacement and s.clone_count<256 then
          replacement=mem.publish_blob(bytes)
          if replacement and mem.read(replacement,256)==bytes then
           s.clones[ck]=replacement;s.ours[replacement]={source=src,original=row};s.clone_count=s.clone_count+1
          else replacement=nil end
         end
         if not replacement then bad=bad+1
         elseif p~=replacement then
          local at=v.data+i*0x238+off
          if identity(v,i,owner,desc,count)and mem.read(at,8)==B.pack(p)and mem.write(at,B.pack(replacement))then touched=touched+1;s.changes=s.changes+1
          else bad=bad+1 end
         end
        end
       elseif rec:sub(off+1,off+8)~=string.rep('\0',8)then bad=bad+1 end
      end
      if s.held[id] and bad==0 and identity(v,i,owner,desc,count)then
       local at=v.flags+i*2
       if mem.read(at,1)=='\1'and mem.write(at,s.held[id])then s.held[id]=nil end
      end
      if bad>0 then failed=failed+1 end
      if touched>0 then patched=patched+1 end
      local keys={};for name in pairs(selected)do keys[#keys+1]=name end;table.sort(keys)
      lines[#lines+1]=label..' selected='..table.concat(keys,',')..' pointers_changed='..touched..' unresolved='..bad
     end
    end
   end
   for id in pairs(s.held)do if not seen[id]then s.held[id]=nil end end
   report(string.format('loaded=%d changed_holes=%d paused=%d unmapped=%d unresolved=%d clones=%d total_pointer_or_flag_changes=%d',holes,patched,paused,unknown,failed,s.clone_count,s.changes),lines)
  end
  return s
 end
 return M
end)()

-- Landed Illuminate Warp Ships have their own AI-spawner selections. These
-- cached row pointers are independent of the +64 placed-Guard templates.
-- Repoint only verified ship selections to private rows using the Guards mix.
local illuminate_ship_guards=(function()
 local M={}
 local SHIP='3779c19db7cdc9b3'
 function M.new(mem,base,mix,emit,writefile)
  local B=mix.binary
  local s={clones={},ours={},changes=0,last_report=nil}
  local function ptr(bytes,off)return B.ptr(bytes,off or 0)end
  local function report(value)
   if value==s.last_report then return end
   s.last_report=value;emit('ILLUMINATE_SHIP_GUARDS '..value)
   if writefile then writefile('PickYourBots_illuminate_ships.txt',
    'Landed Warp Ship production follows the Illuminate Guards mix. Native selections return when Guards is Vanilla.\n'..value..'\n')end
  end
  local function host()
   local root=ptr(mem.read(base+0x3326d60,8));local h=root and mem.read(root,0x88)
   local cap=B.u32(h,0x70);local desc=ptr(h,0x80);local slots=ptr(h,0x68)
   if not cap or cap<1 or cap>16 or not desc or not slots then return false end
   local d=mem.read(desc,24);local map=mem.read(slots,cap*8)
   if not d or not map or B.u32(d,20)%2~=1 or B.u32(d,8)==B.u32(h,0x74)then return false end
   for i=0,cap-1 do if B.u32(map,i*8)==B.u32(d,8)then return B.u32(map,i*8+4)==0 end end
   return false
  end
  local function snapshot()
   local manager=ptr(mem.read(base+0x33265c8,8));local h=manager and mem.read(manager,0x60)
   local cap,n=B.u32(h,0xc),B.u32(h,0x14)
   local owners,data,flags=ptr(h,0x40),ptr(h,0x48),ptr(h,0x58)
   if cap~=128 or not n or n>128 or(n>0 and(not owners or not data or not flags))then return nil end
   local ob=n==0 and ''or mem.read(owners,n*8)
   local records=n==0 and ''or mem.read(data,n*0x238)
   if not ob or not records then return nil end
   return {manager=manager,n=n,owners=owners,data=data,ob=ob,records=records}
  end
  local function identity(v,i,owner,desc,queued)
   if ptr(mem.read(base+0x33265c8,8))~=v.manager then return false end
   local h=mem.read(v.manager,0x60)
   return B.u32(h,0xc)==128 and B.u32(h,0x14)==v.n
    and ptr(h,0x40)==v.owners and ptr(h,0x48)==v.data
    and ptr(mem.read(v.owners+i*8,8))==owner and mem.read(owner,24)==desc
    and B.u32(desc,20)%2==1 and B.u32(mem.read(v.data+i*0x238+0x108,4),0)==queued
  end
  local function slots(rec)
   local queued=B.u32(rec,0x108)
   if not queued or queued>16 then return nil end
   local out={}
   for off=0x40,0x78,8 do out[#out+1]=off end
   for j=0,queued-1 do out[#out+1]=0x88+j*8 end
   return out,queued
  end
  function s.restore()
   if not next(s.ours) or not host()then return 0 end
   local v=snapshot();if not v then return 0 end
   local restored=0
   for i=0,v.n-1 do
    local owner=ptr(v.ob,i*8);local desc=owner and mem.read(owner,24)
    if desc and B.hex(desc:sub(1,8))==SHIP then
     local rec=v.records:sub(i*0x238+1,(i+1)*0x238)
     local list,queued=slots(rec)
     if list then for _,off in ipairs(list)do
      local p=ptr(rec,off);local ours=p and s.ours[p]
      if ours and mem.read(ours.source,256)==ours.original and identity(v,i,owner,desc,queued)then
       local at=v.data+i*0x238+off
       if mem.read(at,8)==B.pack(p) and mem.write(at,B.pack(ours.source))then restored=restored+1 end
      end
     end end
    end
   end
   return restored
  end
  function s.tick(compiled)
   local choices=compiled and compiled.mixes and compiled.mixes.guards
   if not compiled or compiled.pass_through or not choices or #choices==0 then
    report('guards_vanilla restored='..s.restore());return
   end
   if not host()then report('waiting_for_host');return end
   local v=snapshot();if not v then report('manager_unavailable');return end
   local native={}
   for _,row in ipairs(compiled.original_rows)do native[row]=true end
   for _,row in ipairs(compiled.rows)do native[row]=true end
   local ships,changed,unresolved=0,0,0
   local selected={}
   for i=0,v.n-1 do
    local owner=ptr(v.ob,i*8);local desc=owner and mem.read(owner,24)
    if desc and B.hex(desc:sub(1,8))==SHIP then
     ships=ships+1
     local rec=v.records:sub(i*0x238+1,(i+1)*0x238)
     local list,queued=slots(rec)
     if not list then unresolved=unresolved+1
     else
      for k,off in ipairs(list)do
       local p=ptr(rec,off)
       if p then
        local owned=s.ours[p];local src=owned and owned.source or p
        local row=owned and owned.original or mem.read(src,256)
        if not row or #row~=256 or not native[row:sub(1,128)] then unresolved=unresolved+1
        else
         -- Evenly distribute finite ship slots according to the selected
         -- weights; zero-weight units never receive a pointer.
         local fraction=(k-0.5)/#list;local cumulative=0;local pick=choices[#choices]
         for _,choice in ipairs(choices)do
          cumulative=cumulative+choice.share
          if fraction<cumulative then pick=choice;break end
         end
         local bytes=row:sub(1,8)..pick.donor:sub(9,128)..row:sub(129)
         selected[pick.key]=(selected[pick.key] or 0)+1
         local key=tostring(src)..':'..bytes
         local replacement=s.clones[key]
         if not replacement then
          replacement=mem.publish_blob(bytes)
          if replacement and mem.read(replacement,256)==bytes then
           s.clones[key]=replacement;s.ours[replacement]={source=src,original=row}
          else replacement=nil end
         end
         if not replacement then unresolved=unresolved+1
         elseif p~=replacement then
          local at=v.data+i*0x238+off
          if identity(v,i,owner,desc,queued) and mem.read(at,8)==B.pack(p)
           and mem.write(at,B.pack(replacement))then changed=changed+1;s.changes=s.changes+1
          else unresolved=unresolved+1 end
         end
        end
       elseif rec:sub(off+1,off+8)~=string.rep('\0',8)then unresolved=unresolved+1 end
      end
     end
    end
   end
   local names={};for key,count in pairs(selected)do names[#names+1]=key..'='..count end
   table.sort(names)
   report(string.format('loaded_ships=%d changed_pointers=%d unresolved=%d total_changes=%d rows=%s',ships,changed,unresolved,s.changes,table.concat(names,',')))
  end
  return s
 end
 return M
end)()

-- Expand ordinary Terminid GuardForce positions for the selected Guards mix.
-- Data-only changes: native budgets, used/reserved flags and placement stay intact.
local bug_guard_slots=(function()
 local M={}
 function M.affordable_price(budget,posts)
  if not budget or budget<=0 or budget>1e7 or not posts or posts<1 then return nil end
  -- Round downward and leave float accumulation margin; no native budget increase.
  local p=math.floor((budget/posts)*0.999*1024)/1024
  return p>0 and p or nil
 end
 local function band(a,b)
  local n,p=0,1
  while a>0 and b>0 do
   if a%2==1 and b%2==1 then n=n+p end
   a=math.floor(a/2);b=math.floor(b/2);p=p*2
  end
  return n
 end
 local function bor(a,b)return a+b-band(a,b)end
 function M.new(mem,base,mix,emit,writefile)
  local B=mix.binary
  local s={held={},last_report=nil,last_stamp=nil}
  local function ptr(b,o)return B.ptr(b,o or 0)end
  local function report(text)
   if s.last_report==text then return end
   s.last_report=text;emit('BUG_GUARD_SLOTS '..text)
   if writefile then writefile('PickYourBots_guards.txt','Test16: initial Terminid guard positions and shared affordable price.\n'..text..'\nAlready activated groups are not replayed. Native budgets and placement checks still apply.\n')end
  end
  local function host()
   local root=ptr(mem.read(base+0x3326d60,8));local h=root and mem.read(root,0x88)
   local cap=B.u32(h,0x70);local desc=ptr(h,0x80);local slots=ptr(h,0x68)
   if not cap or cap<1 or cap>16 or not desc or not slots then return false end
   local d=mem.read(desc,24);local map=mem.read(slots,cap*8)
   if not d or not map or B.u32(d,20)%2~=1 or B.u32(d,8)==B.u32(h,0x74)then return false end
   for i=0,cap-1 do if B.u32(map,i*8)==B.u32(d,8)then return B.u32(map,i*8+4)==0 end end
   return false
  end
  local function snapshot()
   local manager=ptr(mem.read(base+0x33265c0,8));local h=manager and mem.read(manager,0x58)
   local cap,n,auth=B.u32(h,0),B.u32(h,12),B.u32(h,16)
   local owners,components=ptr(h,0x38),ptr(h,0x48)
   local points=ptr(mem.read(base+0x346d5c0,8))
   if cap~=96 or not n or n>96 or not auth or auth>n or not points or not owners or not components then return nil end
   local ob=n==0 and ''or mem.read(owners,n*8)
   local cb=n==0 and ''or mem.read(components,n*0x2b8)
   if not ob or not cb then return nil end
   return {manager=manager,h=h,n=n,auth=auth,owners=owners,components=components,points=points,ob=ob,cb=cb}
  end
  local function identity(e)
   local v=e.v
   if ptr(mem.read(base+0x33265c0,8))~=v.manager or ptr(mem.read(base+0x346d5c0,8))~=v.points then return false end
   local h=mem.read(v.manager,0x58);local n=B.u32(h,12)
   return B.u32(h,0)==96 and n and e.i<n and e.i<(B.u32(h,16)or 0)
    and ptr(h,0x38)==v.owners and ptr(h,0x48)==v.components
    and mem.read(v.owners+e.i*8,8)==B.pack(e.owner) and mem.read(e.owner,24)==e.desc
    and mem.read(v.components+e.i*0x2b8,0x2b8)==e.comp
    and mem.read(e.at,0x24)==e.prefix
  end
  function s.restore()
   if not next(s.held)then s.last_stamp=nil;return 0 end
   if not host()then return 0 end
   local n=0
   for at,e in pairs(s.held)do
    if identity(e)and mem.read(at+0x28,4)==e.changed then
     if mem.write(at+0x28,e.original)then n=n+1;s.held[at]=nil end
    else s.held[at]=nil end
   end
   s.last_stamp=nil;return n
  end
  function s.tick(compiled)
   compiled.guard_price=nil
   local choices=compiled.mixes and compiled.mixes.guards or {}
   if compiled.pass_through or #choices==0 then s.restore();report('vanilla');return end
   if not host()then report('waiting_for_host');return end
   for _,sig in ipairs({{0x90ab2d,'4c8b158cbaa102'},{0x90ec29,'e8621bc0ff8b480841854e280f8506010000'},{0x90f069,'e82217c0ff8b480841854f287408'}})do
    local expected=B.raw(sig[2])
    if mem.read(base+sig[1],#expected)~=expected then report('layout_signature_changed');return end
   end
   local v=snapshot();if not v then report('manager_not_ready');return end
   local director=ptr(mem.read(base+0x3326d10,8))
   local budget_bytes=director and mem.read(director+0x518b4,4)
   local base_budget=B.f32(budget_bytes,0)
   local stamp=B.pack(v.manager)..v.h..v.ob..v.cb..B.pack(v.points)..(budget_bytes or '')
   if s.last_stamp==stamp and s.compiled==compiled then compiled.guard_price=s.price;return end
   local library=ptr(mem.read(base+0x346bf98,8))
   local bp=library and ptr(mem.read(library+0xf12d58,8))
   local gp=library and ptr(mem.read(library+0xf12b08,8))
   local bh=bp and mem.read(bp,2008*16);local gh=gp and mem.read(gp,42*16)
   if not bh or not gh then report('definitions_not_ready');return end
   local indexes={}
   for i=0,2007 do indexes[bh:sub(i*16+1,i*16+8)]=B.u32(bh,i*16+8)end
   local mask=0
   for _,choice in ipairs(choices)do
    local ix=indexes[choice.donor:sub(9,16)]
    local row=ix and ix<2008 and mem.read(bp+2008*16+ix*12,12)
    local m=B.u32(row,8)
    if not m or m==0 then report('selected_behavior_not_ready');return end
    mask=bor(mask,m)
   end
   local definitions,budgets={},{}
   for i=0,41 do
    local ix=B.u32(gh,i*16+8)
    if ix and ix<42 then
     local row=mem.read(gp+(42+ix)*16,16)
     if row then
      local key=gh:sub(i*16+1,i*16+8)
      definitions[key]=B.u32(row,8)==2 and B.u32(row,12)==0
      local override,mult=B.f32(row,0),B.f32(row,4)
      if override and mult and mult>=0 and base_budget and base_budget>=0 then budgets[key]=override>0 and override or base_budget*mult end
     end
    end
   end
   local groups,protected={},{}
   local lowest,price_invalid=nil,false
   for i=0,v.n-1 do
    local owner=ptr(v.ob,i*8);local desc=owner and mem.read(owner,24)
    local comp=v.cb:sub(i*0x2b8+1,(i+1)*0x2b8);local count=B.u32(comp,0x1a8)
    if not desc or not count or count>96 then report('group_layout_invalid');return end
    local allowed=i<v.auth and B.u32(desc,20)%2==1 and definitions[desc:sub(1,8)]==true
    if allowed and count>0 then
     local p=M.affordable_price(budgets[desc:sub(1,8)],count)
     if p then lowest=lowest and math.min(lowest,p)or p else price_invalid=true end
    end
    local g={v=v,i=i,owner=owner,desc=desc,comp=comp,slots={},allowed=allowed}
    for j=0,count-1 do
     local ix=B.u32(comp,0x28+j*4)
     if not ix or ix>=32768 then report('position_index_invalid');return end
     g.slots[#g.slots+1]=ix
     if not allowed then protected[ix]=true end
    end
    groups[#groups+1]=g
   end
   if mem.read(v.manager,0x58)~=v.h or mem.read(v.owners,v.n*8)~=v.ob or mem.read(v.components,v.n*0x2b8)~=v.cb then report('manager_changed');return end
   if director and mem.read(director+0x518b4,4)~=budget_bytes then report('budget_changed');return end
   s.price=not price_invalid and lowest or nil;compiled.guard_price=s.price
   local changed,restricted,failed=0,0,0
   for _,g in ipairs(groups)do if g.allowed then
    for _,ix in ipairs(g.slots)do if not protected[ix]then
     local at=v.points+ix*0x58;local row=mem.read(at,0x58)
     local old=B.u32(row,0x28);local flags=B.u32(row,0x24)
     if not old or not flags then failed=failed+1
     elseif band(flags,0x340)==0 and band(old,mask)==0 then
      restricted=restricted+1
      local e={v=v,i=g.i,owner=g.owner,desc=g.desc,comp=g.comp,at=at,prefix=row:sub(1,0x24),original=row:sub(0x29,0x2c),changed=B.pack(bor(old,mask),4)}
      if identity(e)and mem.read(at,0x58)==row and mem.write(at+0x28,e.changed)then
       s.held[at]=e;changed=changed+1
      else failed=failed+1 end
     end
    end end
   end end
   if failed==0 then s.last_stamp=stamp;s.compiled=compiled end
   local held=0;for _ in pairs(s.held)do held=held+1 end
   report(string.format('groups=%d selected_mask=0x%x expanded=%d held=%d unresolved=%d shared_guard_price=%s',v.n,mask,changed,held,failed,tostring(s.price or 'unavailable')))
  end
  return s
 end
 return M
end)()

-- Changes only the captured Hive World Titan -> Charger variant rule.
local titan_replacement={}
function titan_replacement.rewrite(B,bytes,mode,tags,rows,difficulty)
 -- Native Dragonroach templates and spawning remain independent and untouched.
 -- Match mission authoring; never wait for an already spawned Dragonroach.
 if mode==1 then return bytes,{} end
 if mode~=2 and mode~=3 then return nil,'invalid_titan_replacement' end
 if type(bytes)~='string' or #bytes%48~=0 or #bytes>4096*48 then return nil,'invalid_titan_variant_table' end
 local titan=B.raw('ddafccccf2172e9e');local charger=B.raw('b064c698ffcd7f1a')
 local matches={}
 for o=0,#bytes-48,48 do
  local r=bytes:sub(o+1,o+48)
  if tags[B.u32(r,0)] and r:sub(9,16)==titan and r:sub(17,24)==charger then matches[#matches+1]=o end
 end
 if #matches==0 then return bytes,{} end
 local target,label=titan,'Bile_Titan (Charger replacement blocked)'
 if mode==3 then
  local dragon=B.raw('aafaa321a4480b96');local eligible=false
  if type(rows)=='string' and #rows%128==0 and difficulty and difficulty>=1 and difficulty<=10 and difficulty%1==0 then
   for o=0,#rows-128,128 do
    local r=rows:sub(o+1,o+128)
    if r:sub(9,16)==dragon and B.eligible(r,tags) and B.f32(r,0x30+(difficulty-1)*4)>0 then eligible=true;break end
   end
  end
  if eligible then target=dragon;label='Dragonroach'
  else label='Bile_Titan (Dragonroach unavailable in native mission roster; other mixes remain active)' end
 end
 local changes={}
 for _,o in ipairs(matches)do
  bytes=B.put(bytes,o+16,target)
  changes[#changes+1]=string.format('entry=%d Bile_Titan->%s',o/48,label)
 end
 return bytes,changes
end

-- Test31 native data publication. No new roster/header/template addresses,
-- page protection changes, executable writes, or native calls.
local native_bot_drop_data=(function()
 local M={}
 function M.restore(mem,journal)
  local restored,skipped=0,0
  for i=#journal,1,-1 do local e=journal[i]
   local current=mem.read(e.address,8)
   if current==e.after then
    if mem.write(e.address,e.before) then restored=restored+1 else skipped=skipped+1 end
   elseif current~=e.before then skipped=skipped+1 end
  end
  return restored,skipped
 end
 function M.apply(mem,base,B,rows_address,rows,groups,compiled,valid)
  local plan,seen={},{}
  local function add(address,before,after)
   if #before~=#after or #before%8~=0 or address%8~=0 then return false,'native_data_alignment' end
   for o=0,#before-1,8 do
    local a,b=before:sub(o+1,o+8),after:sub(o+1,o+8)
    if a~=b then
     local at=address+o;local prior=seen[at]
     if prior and (prior.before~=a or prior.after~=b) then return false,'native_data_alias_conflict' end
     if not prior then
      local r=mem.region(at)
      if not r or r.state~=0x1000 or r.protect~=4 or at+8>r.base+r.size
       or not (r.kind==0x20000 or (r.kind==0x1000000 and r.allocation==base)) then return false,'native_data_not_writable' end
      if r.kind==0x1000000 and not mem.allow_image_field(at,base) then return false,'native_data_registration_failed' end
      if not mem.writable(at,8) or mem.read(at,8)~=a then return false,'native_data_changed_before_apply' end
      local e={address=at,before=a,after=b};plan[#plan+1]=e;seen[at]=e
     end
    end
   end
   return true
  end
  local ok,why=add(rows_address,rows,compiled.row_bytes)
  if not ok then return nil,why end
  for offset,input in pairs(groups)do
   local bytes=compiled.groups[offset]
   if bytes then ok,why=add(input.address,input.bytes,bytes);if not ok then return nil,why end end
  end
  if not valid() then return nil,'native_context_changed_before_apply' end
  local written={}
  for _,e in ipairs(plan)do
   if not valid() or mem.read(e.address,8)~=e.before or not mem.write(e.address,e.after) then
    -- Include a failed write if readback shows it actually reached memory.
    if mem.read(e.address,8)==e.after then written[#written+1]=e end
    local _,skipped=M.restore(mem,written)
    if skipped>0 then error('native_data_rollback_incomplete; restart the game before retrying') end
    return nil,'native_data_apply_failed rollback_skipped='..skipped
   end
   written[#written+1]=e
  end
  return written
 end
 return M
end)()

local mix_engine = (function()
    local B=unit_mix.binary
    return function(mem,profile,emit,writefile,mix,faction_name)
        mix=mix or unit_mix;faction_name=faction_name or 'automaton'
        local mix_file=faction_name=='terminid' and 'PickYourBots_terminid_mix.txt' or faction_name=='illuminate' and 'PickYourBots_illuminate_mix.txt' or 'PickYourBots_mix.txt'
        local base=mem.module('game.dll');if not base then return nil,'game_module_unavailable'end
        local holes=mix.is_bug and bug_hole_cache.new(mem,base,mix,emit,writefile) or nil
        local illuminate_ships=mix.is_illuminate and illuminate_ship_guards.new(mem,base,mix,emit,writefile) or nil
        local guard_slots=mix.is_bug and bug_guard_slots.new(mem,base,mix,emit,writefile) or nil
        local state={rosters={},headers={},backups={},patched=0,phase='mix_waiting'}
        local active,blocked,last=nil,nil,-10
        local titan_hashes=mix.is_bug and {
            [B.raw('ddafccccf2172e9e')]=true,
            [B.raw('97a497d084cb04ef')]=true,
            [B.raw('aafaa321a4480b96')]=true,
        } or nil
        local function director()return B.ptr(mem.read(base+profile.hints.director_global_rva,8),0)end
        local function report(s)if s~=blocked then blocked=s;emit('unit_mix '..s)end end
        local function read_tags(d)
            local s=mem.read(d+0x518d4,0x44);local n=B.u32(s,0x40)
            if not n or n>16 then return nil end
            local t={};for i=0,n-1 do t[B.u32(s,i*4)]=true end;return t
        end
        local function stats_for(compiled,d,allow_zero)
            local diff=B.u32(mem.read(d+0x518c4,4),0);local tags=read_tags(d)
            if not diff or diff<1 or diff>10 or not tags then return nil end
            local stats={}
            for _,r in ipairs(compiled.rows)do
                if B.eligible(r,tags)then
                    local w=B.f32(r,0x30+(diff-1)*4)
                    local tag=B.u32(r,0);local s=stats[tag]
                    if allow_zero and not s then s={weight=0,cost=0};stats[tag]=s end
                    if w and w>0 then
                        if not s then s={weight=0,cost=0};stats[tag]=s end
                        s.weight=s.weight+w;s.cost=s.cost+w*B.f32(r,0x20)
                    end
                end
            end
            for _,s in pairs(stats)do s.cost=s.weight>0 and s.cost/s.weight or 1 end
            return stats
        end
        -- Existing native candidates store a copy of their template's eight entries.
        -- Update only candidates traced to an original or cloned template we own.
        local function refresh_cache(a,restore)
            if a.compiled.pass_through then return 0 end
            local d=a.director;if director()~=d or B.ptr(mem.read(d+0x660,8),0)~=a.shadow then return 0 end
            local stats=stats_for(restore and {rows=a.compiled.original_rows}or a.compiled,d,
                not restore and a.heavy_blocked);if not stats then return 0 end
            local context=d+profile.candidate_context
            local counts=mem.read(context+profile.candidate_counts,32);if not counts then return 0 end
            local changed=0
            for index,pool in ipairs(profile.pools)do
                local n=B.u32(counts,(index-1)*4)
                if n and n<=pool[2]then
                    for i=0,n-1 do
                        local addr=context+pool[1]+i*profile.candidate_stride
                        local old=mem.read(addr,0xd8);local tp=B.ptr(old,0xa8)
                        local t=tp and a.compiled.templates[tp]
                        if t and #B.entries(t.record)>0 then
                            local record=restore and t.original_record or t.record;local en=B.entries(record)
                            local out=B.put(old,0,record:sub(1,0x60))
                            out=B.put(out,0x60,B.pack(#en,4))
                            local scale=B.f32(record,0xe4);local total=0;local valid=scale and scale>=0 and scale<10000
                            for j,e in ipairs(en)do
                                local s=stats[e.tag]
                                if not s then valid=false;break end
                                local unit_cost=s.cost
                                unit_cost=mix.breach_candidate_unit_cost(a.compiled,profile,t.source,e.tag,unit_cost,restore)
                                local cost=mix.candidate_entry_cost(t.group,unit_cost,e.n,scale or 1)
                                if not restore and mix.is_bug and t.group==64 and (e.tag==a.compiled.synthetic.guards or (a.compiled.source_tags.guards or {})[e.tag]) and a.compiled.guard_price then cost=a.compiled.guard_price end
                                out=B.put(out,0x64+(j-1)*4,B.float(cost))
                                out=B.put(out,0x84+(j-1)*4,B.float(s.weight));total=total+cost
                            end
                            if valid then
                                out=B.put(out,0xd4,B.float(total))
                                if restore then out=B.put(out,0xa8,B.pack(t.original_address))end
                                if out~=old and mem.read(addr,0xd8)==old and mem.write(addr,out)then changed=changed+1 end
                            else report('cache_not_ready source='..t.source..' (native eligibility or cost unavailable)')end
                        end
                    end
                else report('cache_count_invalid pool='..index)end
            end
            return changed
        end
        local function apply(d,haddr)
            -- Read-only layout fingerprints from the supplied native captures. Never patch code.
            for _,v in ipairs({
                {0x9531f0,'8bfd48c1e70749033c24391f'},
                {0x95321b,'f30f10448730'},
                {0x94c387,'83f908'},
                {0x94cdb2,'c644245001c644244801'}, -- group +64 uses per-unit guard cost
                {0x94c243,'80bc247001000000'}, -- native cost-mode argument, separate from +d0
                {0x177e3c0,'48895c2408488bda4c8d4a10'},
            })do
                local expected=B.raw(v[2])
                if mem.read(base+v[1],#expected)~=expected then return nil,string.format('layout_signature_changed_rva_%x',v[1])end
            end
            local h=mem.read(haddr,0xb0);local rp=B.ptr(h,0);local n=B.u32(h,8)
            if not rp or not n or n<30 or n>128 then return nil,'waiting_for_faction_roster'end
            local rows=mem.read(rp,n*128);if not rows then return nil,'roster_unreadable'end
            local tags=read_tags(d);if not tags then return nil,'mission_tags_unreadable'end
            local groups={}
            for _,g in ipairs(profile.groups)do
                local p=B.ptr(h,g[1]);local count=B.u32(h,g[1]+8)
                if not count or count>512 then return nil,'template_count_invalid'end
                if count>0 then
                    local s=p and mem.read(p,count*0x118)
                    if not s then return nil,'template_unreadable'end
                    groups[g[1]]={bytes=s,address=p}
                end
            end
            state.factory_original=nil
            for o=0,#rows-256,128 do
                if rows:sub(o+1,o+16)==B.raw('bf2db6210000000044703d8525e563ae')then
                    state.factory_original=rows:sub(o+1,o+256);break
                end
            end
            do local dv=B.u32(mem.read(d+0x518c4,4),0);profile.difficulty=(dv and dv>=1 and dv<=10) and dv or nil end
            profile.active_patrol_templates=nil
            local patrol_selection
            if not (profile.mix_vanilla and profile.mix_vanilla.patrols) then
                local why
                patrol_selection,why=mix.read_patrol_selection(mem.read,d+profile.candidate_context,profile,groups[32])
                if not patrol_selection then return nil,why end
                profile.active_patrol_templates=patrol_selection.weights
            end
            profile.active_breach_templates=nil
            local breach_selection
            if not (profile.mix_vanilla and profile.mix_vanilla.drops) then
                local why
                breach_selection,why=mix.read_breach_selection(mem.read,d+profile.candidate_context,profile,groups[80])
                if not breach_selection then return nil,why end
                profile.active_breach_templates=breach_selection.weights
            end
            profile.active_guard_templates=nil
            profile.guard_native_context=nil
            local guard_selection,guard_context
            if mix.is_bug and not (profile.mix_vanilla and profile.mix_vanilla.guards) then
                local why
                guard_selection,why=mix.read_guard_selection(mem.read,d+profile.candidate_context,profile,groups[64])
                if not guard_selection then return nil,why end
                profile.active_guard_templates=guard_selection.weights
                guard_context,why=mix.read_guard_context(mem.read,base,d)
                if not guard_context then return nil,why end
                if guard_context.difficulty~=profile.difficulty then return nil,'waiting_for_stable_guard_difficulty' end
                profile.guard_native_context=guard_context
                tags=guard_context.tags
            end
            profile.active_guard112_templates=nil
            local guard112_selection
            if mix.is_bug and not (profile.mix_vanilla and profile.mix_vanilla.guards) then
                local why
                guard112_selection,why=mix.read_guard112_selection(mem.read,d+profile.candidate_context,profile,groups[112])
                if not guard112_selection then return nil,why end
                profile.active_guard112_templates=guard112_selection.weights
            end
            profile.active_drop_templates=nil
            profile.active_drop_template_count=nil
            if mix.is_illuminate and breach_selection then
                if breach_selection.count<1 then return nil,'waiting_for_illuminate_drop_candidates' end
                local selected={}
                for at in pairs(breach_selection.weights)do selected[at]=true end
                profile.active_drop_templates=selected
                profile.active_drop_template_count=breach_selection.unique
            end
            if mix.is_bug then profile.bug_alpha_resolved_unit=nil end
            local compiled,why=mix.compile(profile,rows,groups,tags)
            do
                local rt=rawget(_G,'PickYourBots')
                if rt and rt.cache_roster and why~='roster_layout_unknown' then
                    local list={};for t in pairs(tags)do list[#list+1]=string.format('%08x',t)end;table.sort(list)
                    local sum=0;for i=1,#rows,3 do sum=(sum*31+rows:byte(i))%4294967296 end
                    local key=string.format('%s|d%s|%s|rows%d|%08x',faction_name,tostring(profile.difficulty),table.concat(list,','),n,sum)
                    local snap={'faction='..faction_name,'difficulty='..tostring(profile.difficulty),'mission_tags='..table.concat(list,','),
                        string.format('rows=%d spare_pool_rows=%s result=%s',n,tostring(compiled and compiled.stats.pool_rows_free or 'n/a'),compiled and 'compiled' or tostring(why)),
                        'header='..B.hex(h),'roster='..B.hex(rows)}
                    do
                        local vc=B.u32(h,0x18);local vp=B.ptr(h,0x10)
                        local vb=vc and vc>0 and vc<=4096 and vp and mem.read(vp,vc*0x30)
                        snap[#snap+1]='variants='..(vb and B.hex(vb) or 'unavailable')
                    end
                    for _,g in ipairs(profile.groups)do
                        local input=groups[g[1]]
                        if input then snap[#snap+1]=string.format('group=%d address=0x%x bytes=%s',g[1],input.address,B.hex(input.bytes))end
                    end
                    pcall(rt.cache_roster,key,table.concat(snap,'\n'))
                end
            end
            if not compiled then return nil,why end
            if #compiled.rows>64 then return nil,string.format('roster_over_64_refused rows=%d limit=64',#compiled.rows) end
            local tanks_stay=mix.tanks_requested(profile,compiled)
            local titan_mode=mix.is_bug and (profile.bug_titan_replacement or 1) or 1
            local variants_original,variants_modified,variants_pointer
            local variant_changes={}
            if tanks_stay or titan_mode~=1 then
                local count=B.u32(h,0x18)
                if not count or count>4096 then return nil,'tank_variant_count_invalid'end
                if count>0 then
                    -- Captured native variant selector: input +8, output +0x10, stride 0x30.
                    for _,pin in ipairs({{0x949acf,'493b5108'},{0x949b42,'498b4cd710'},{0x949b26,'4983c130'}})do
                        local expected=B.raw(pin[2])
                        if mem.read(base+pin[1],#expected)~=expected then return nil,'tank_variant_layout_changed'end
                    end
                    variants_pointer=B.ptr(h,0x10)
                    variants_original=variants_pointer and mem.read(variants_pointer,count*0x30)
                    if not variants_original or #variants_original~=count*0x30 then return nil,'tank_variant_table_unreadable'end
                    local changed
                    if titan_mode~=1 then
                        variants_modified,changed=titan_replacement.rewrite(B,variants_original,titan_mode,tags,rows,profile.difficulty)
                    else
                        -- A tank selected anywhere in the mix must retain its identity
                        -- even when the native variant selector uses tags outside the
                        -- director's mission-tag list. Change all nine matching rules
                        -- in a private copy; never edit the live variant table.
                        variants_modified,changed=mix.neutralize_tank_variants(variants_original)
                    end
                    if not variants_modified then return nil,changed end
                    if tanks_stay and #changed~=9 then
                        return nil,'tank_variant_rules_unexpected expected=9 got='..#changed
                    end
                    variant_changes=changed
                end
            end
            compiled.pass_through=compiled.pass_through and #variant_changes==0
            state.tank_variants=0;state.tanks_stay=tanks_stay
            if compiled.pass_through then
                emit('unit_mix_all_vanilla original_descriptor_retained')
                if writefile then writefile(mix_file,'All four mixes are VANILLA; no descriptor or cache changes.\n')end
                state.director_addr=d
                return {director=d,original=haddr,shadow=haddr,slots={},compiled=compiled,original_bytes=h}
            end
            -- Refuse publication if the selection set changed while compiling.
            if patrol_selection and (director()~=d or mem.read(d+0x660,8)~=B.pack(haddr)
                or mem.read(patrol_selection.counts_at,32)~=patrol_selection.counts
                or (#patrol_selection.bytes>0 and mem.read(patrol_selection.address,#patrol_selection.bytes)~=patrol_selection.bytes)) then
                return nil,'waiting_for_stable_patrol_selection_during_build'
            end
            if breach_selection and (director()~=d or mem.read(d+0x660,8)~=B.pack(haddr)
                or mem.read(breach_selection.counts_at,32)~=breach_selection.counts
                or (#breach_selection.bytes>0 and mem.read(breach_selection.address,#breach_selection.bytes)~=breach_selection.bytes)) then
                return nil,'waiting_for_stable_breach_selection_during_build'
            end
            if guard_selection and (director()~=d or mem.read(d+0x660,8)~=B.pack(haddr)
                or mem.read(guard_selection.counts_at,32)~=guard_selection.counts
                or (#guard_selection.bytes>0 and mem.read(guard_selection.address,#guard_selection.bytes)~=guard_selection.bytes)) then
                return nil,'waiting_for_stable_guard_selection_during_build'
            end
            if guard_context then
                for _,c in ipairs(guard_context.checks)do
                    if mem.read(c.at,#c.bytes)~=c.bytes then return nil,'waiting_for_stable_guard_eligibility_during_build' end
                end
            end
            if guard112_selection and (director()~=d or mem.read(d+0x660,8)~=B.pack(haddr)
                or mem.read(guard112_selection.counts_at,32)~=guard112_selection.counts
                or (#guard112_selection.bytes>0 and mem.read(guard112_selection.address,#guard112_selection.bytes)~=guard112_selection.bytes)) then
                return nil,'waiting_for_stable_guard112_selection_during_build'
            end
            local slots={}
            for _,off in ipairs(profile.slot_offsets)do if B.ptr(mem.read(d+off,8),0)==haddr then slots[#slots+1]=off end end
            if #slots==0 then return nil,'director_header_changed'end
            local rowptr,shadowptr,native_journal
            if compiled.native_bot_drops then
                local private_header
                if #variant_changes>0 then
                    if mem.read(variants_pointer,#variants_original)~=variants_original then return nil,'tank_variant_changed_during_build'end
                    local variant_copy=mem.publish_blob(variants_modified)
                    if not variant_copy then return nil,'tank_variant_allocation_failed'end
                    if mem.read(variant_copy,#variants_modified)~=variants_modified then return nil,'tank_variant_copy_check_failed'end
                    private_header=mem.publish_blob(B.put(h,0x10,B.pack(variant_copy)))
                    if not private_header then return nil,'tank_variant_header_allocation_failed'end
                    if mem.read(private_header,0xb0)~=B.put(h,0x10,B.pack(variant_copy)) then return nil,'tank_variant_header_check_failed'end
                end
                local function valid()
                    if director()~=d or mem.read(haddr,0xb0)~=h then return false end
                    for _,off in ipairs(slots)do if mem.read(d+off,8)~=B.pack(haddr)then return false end end
                    return true
                end
                native_journal,why=native_bot_drop_data.apply(mem,base,B,rp,rows,groups,compiled,valid)
                if not native_journal then return nil,why end
                rowptr=rp;shadowptr=private_header or haddr
                if private_header then
                    local written={}
                    for _,off in ipairs(slots)do
                        local at=d+off
                        local context_ok=director()==d and mem.read(haddr,0xb0)==h and mem.read(at,8)==B.pack(haddr)
                        local published=context_ok and mem.write(at,B.pack(private_header))
                        if not published then
                            if mem.read(at,8)==B.pack(private_header)then written[#written+1]=off end
                            local pointer_rollback_failed=false
                            for _,done in ipairs(written)do
                                local ptr_at=d+done
                                if mem.read(ptr_at,8)==B.pack(private_header) and not mem.write(ptr_at,B.pack(haddr))then
                                    pointer_rollback_failed=true
                                end
                            end
                            local _,skipped=native_bot_drop_data.restore(mem,native_journal)
                            if pointer_rollback_failed or skipped>0 then
                                error('native_tank_variant_publish_rollback_incomplete; restart the game before retrying')
                            end
                            return nil,'tank_variant_header_publish_failed'
                        end
                        written[#written+1]=off
                    end
                end
                emit('native_bot_drop_data_applied fields='..#native_journal..' descriptor='..(private_header and 'private_variant_header' or 'original')..' rows=original templates=original')
            else
            -- Allocate and fully populate a private descriptor before publishing any pointer.
            rowptr=mem.publish_blob(compiled.row_bytes);if not rowptr then return nil,'row_allocation_failed'end
            local shadow=B.put(h,0,B.pack(rowptr));shadow=B.put(shadow,8,B.pack(#compiled.rows,4))
            -- Native variant remapping would override selected entities and cost estimates.
            -- Clone only matching tank rules or the active ground Titan-to-Charger rule.
            if #variant_changes>0 then
                local variant_copy=mem.publish_blob(variants_modified)
                if not variant_copy then return nil,'tank_variant_allocation_failed'end
                if mem.read(variant_copy,#variants_modified)~=variants_modified then return nil,'tank_variant_copy_check_failed'end
                shadow=B.put(shadow,0x10,B.pack(variant_copy))
            end
            for _,g in ipairs(profile.groups)do
                local bytes=compiled.groups[g[1]]
                if bytes then
                    local p=mem.publish_blob(bytes);if not p then return nil,'template_allocation_failed'end
                    shadow=B.put(shadow,g[1],B.pack(p))
                    for i=0,#bytes/0x118-1 do
                        compiled.templates[p+i*0x118]=compiled.templates[groups[g[1]].address+i*0x118]
                    end
                end
            end
            shadowptr=mem.publish_blob(shadow);if not shadowptr then return nil,'header_allocation_failed'end
            if director()~=d or mem.read(haddr,0xb0)~=h then return nil,'mission_changed_during_build'end
            if variants_original and mem.read(variants_pointer,#variants_original)~=variants_original then return nil,'tank_variant_changed_during_build'end
            local written={}
            for _,off in ipairs(slots)do
                local at=d+off
                if mem.read(at,8)~=B.pack(haddr) or not mem.write(at,B.pack(shadowptr)) then
                    for _,done in ipairs(written)do if mem.read(d+done,8)==B.pack(shadowptr)then mem.write(d+done,B.pack(haddr))end end
                    return nil,'header_publish_failed'
                end
                written[#written+1]=off
            end
            end
            local a={director=d,original=haddr,shadow=shadowptr,slots=slots,compiled=compiled,original_bytes=h,rowptr=rowptr,heavy_blocked=false,native_journal=native_journal}
            if titan_hashes then
                a.heavy_rows={}
                for i,r in ipairs(compiled.rows)do
                    if titan_hashes[r:sub(9,16)] then a.heavy_rows[#a.heavy_rows+1]={index=i,original=r,blocked=B.put(r,0x30,string.rep('\0',40))}end
                end
            end
            state.director_addr=d
            state.tank_variants=tanks_stay and #variant_changes or 0
            state.titan_variants=titan_mode~=1 and #variant_changes or 0
            local variant_summary=string.format('tank_variants=%d tanks_stay=%s titan_replacement_mode=%d titan_rules_changed=%d scope=%s',state.tank_variants,tostring(tanks_stay),titan_mode,state.titan_variants,compiled.native_bot_drops and 'native_rows_private_variants' or 'private_descriptor')
            emit('tank_variants_neutralized entries='..state.tank_variants..' tanks_stay='..tostring(tanks_stay))
            for _,change in ipairs(variant_changes)do emit((titan_mode~=1 and 'titan_variant ' or 'tank_variant ')..change)end
            if writefile then
                local capture={'Pick your bots selective tank variant correction',variant_summary,
                    compiled.native_bot_drops and 'Native roster and template fields remain in place; all nine tank-to-Walker rules change only in a private variant copy.' or
                        'Private variant copy: only selected exact tank or active Hive World Titan-to-Charger rules change. All other rules remain intact.',
                    'original='..(variants_original and B.hex(variants_original)or 'not_read'),
                    (compiled.native_bot_drops and 'native_result=' or 'private_copy=')..(variants_modified and B.hex(variants_modified)or 'not_created')}
                for _,change in ipairs(variant_changes)do capture[#capture+1]=change end
                writefile('PickYourBots_variants.txt',table.concat(capture,'\n')..'\n')
            end
            state.rosters={[rowptr]={is_image=false}};state.headers={[shadowptr]={rows=rowptr,count=#compiled.rows}}
            local lines={'PER-UNIT MIX '..profile.version..' / '..faction_name,'validated percentages; fixed direct-entity templates are untouched; actual spawns also depend on game budgets, transport capacity and population limits',
                string.format('original_rows=%d compiled_rows=%d direct_entity_bypasses=%d',n,#compiled.rows,compiled.stats.direct_bypass or 0)}
            lines[#lines+1]=variant_summary
            for _,s in ipairs(compiled.summary)do lines[#lines+1]=s;emit('unit_mix_applied '..s)end
            for _,g in ipairs(profile.groups)do
                local input=groups[g[1]]
                if input then lines[#lines+1]=string.format('template_group=%d records=%d',g[1],#input.bytes/0x118)end
            end
            lines[#lines+1]='drop_cost_divisor='..tostring(profile.drop_cost_divisor or 1)..' rounding=nearest_integer minimum=1 scope=custom_drops cost_locked_1x=annihilator,shredder,barrager,factory_strider,rocket_strider factory_drop_entries_replaced='..tostring(compiled.stats.factory_drop_entries or 0)
            lines[#lines+1]='protected_factory_drop_entries_preserved='..tostring(compiled.stats.factory_drop_entries_preserved or 0)..' bot_mix_method='..(compiled.native_bot_drops and 'selected_native_rows_and_native_data_addresses' or 'private_descriptor_and_custom_tags')
            for _,src in ipairs(mix.sources)do
                local before,after=mix.weighted_cost(profile.mixes[src.key],src.key=='drops'and(profile.drop_cost_divisor or 1)or nil)
                if before then lines[#lines+1]=string.format('weighted_base_cost source=%s before=%.4f after=%.4f enabled=%s excludes_native_extras=true',src.key,before,after,tostring(not profile.mix_vanilla[src.key]))end
            end
            lines[#lines+1]='drop_cost_override='..tostring(profile.guard.retag_cost or 0)..' drop_minimum='..tostring(profile.drop_fill.fill or 0)
            lines[#lines+1]='patrol_extra_troopers='..tostring(profile.mix_vanilla.patrols and 0 or(profile.patrol_extra_troopers or 0))..' saved='..tostring(profile.patrol_extra_troopers or 0)..' templates='..tostring(compiled.stats.patrol_extra_records or 0)
            lines[#lines+1]='guards_and_outposts: original trooper rows preserved (MG and non-MG); percentages apply to other eligible rows only'
            local stat=stats_for(compiled,d)
            if stat then
                for _,src in ipairs(mix.sources)do
                    local tag=compiled.synthetic[src.key];local st=tag and stat[tag]
                    if st then lines[#lines+1]=string.format('source=%s eligible_weight=%.6f average_spawn_cost=%.6f',src.key,st.weight,st.cost)end
                end
            end
            if writefile then
                local snapshot={'AAR Test3 original spawn descriptor and template snapshot',
                    'MG assignments are not inferred from unit identity or guard group number.',
                    'header='..B.hex(h),'roster='..B.hex(rows)}
                for _,g in ipairs(profile.groups)do
                    local input=groups[g[1]]
                    if input then snapshot[#snapshot+1]=string.format('group=%d address=0x%x bytes=%s',g[1],input.address,B.hex(input.bytes))end
                end
                writefile('PickYourBots_spawn_sources.txt',table.concat(snapshot,'\n')..'\n')
            end
            if writefile then writefile(mix_file,table.concat(lines,'\n')..'\n')end
            emit(string.format('unit_mix_installed director=0x%x original=0x%x shadow=0x%x rows=%d',d,haddr,shadowptr,#compiled.rows))
            do
                local rt=rawget(_G,'PickYourBots')
                local who=faction_name=='terminid' and 'PICK YOUR BUGS' or faction_name=='illuminate' and 'PICK YOUR SQUIDS' or 'PICK YOUR BOTS'
                local w=compiled.warnings or {}
                if rt and rt.publish_banner and not compiled.pass_through then
                    if #w==0 then rt.publish_banner(who..': MIX APPLIED',false)
                    else rt.publish_banner(who..': MIX APPLIED WITH '..#w..' CHANGE'..(#w>1 and 'S' or '')..' - '..w[1]:gsub('_',' '),true) end
                end
                for _,line in ipairs(w)do emit('unit_mix_warning '..line)end
            end
            return a
        end
        function state.restore_all()
            local restored=0
            if guard_slots then emit('BUG_GUARD_SLOTS restored='..guard_slots.restore())end
            if holes then emit('BUG_HOLE_CACHE restored='..holes.restore())end
            if illuminate_ships then emit('ILLUMINATE_SHIP_GUARDS restored='..illuminate_ships.restore())end
            if active and director()==active.director then
                local reset=refresh_cache(active,true)
                emit("unit_mix_native_cache_restored entries="..reset)
                if active.shadow~=active.original then
                    for _,off in ipairs(active.slots)do
                        local p=active.director+off
                        if mem.read(p,8)==B.pack(active.shadow) and mem.read(active.original,0xb0)==active.original_bytes
                            and mem.write(p,B.pack(active.original))then restored=restored+1 end
                    end
                end
            end
            if active and active.native_journal then
                if active.shadow~=active.original and director()==active.director then
                    for _,off in ipairs(active.slots)do
                        if mem.read(active.director+off,8)==B.pack(active.shadow)then
                            state.native_restore_blocked=true
                            return restored,1,'private_variant_header_detach_failed_restart_game'
                        end
                    end
                end
                local n,skipped=native_bot_drop_data.restore(mem,active.native_journal)
                emit('native_bot_drop_data_restored fields='..n..' skipped='..skipped)
                if skipped>0 then
                    state.native_restore_blocked=true
                    return n,skipped,'native_data_restore'
                end
                state.native_restore_blocked=nil
                active=nil;return n,skipped,'native_data_restore'
            end
            active=nil;return restored,0,'private_descriptor_detached; buffers_retained_for_cached_references'
        end
        function state.in_mission()return director()~=nil end
        function state.restore_native_bot_data()
            if active and active.native_journal then return state.restore_all() end
        end
        function state.set_heavy_suppressed(should_block)
            if not titan_hashes or not active or not active.rowptr then return false,'roster_not_ready' end
            should_block=should_block==true
            if active.heavy_blocked==should_block then return true end
            if director()~=active.director or B.ptr(mem.read(active.director+0x660,8),0)~=active.shadow then return false,'director_changed' end
            local plan={}
            for _,item in ipairs(active.heavy_rows)do
                local address=active.rowptr+(item.index-1)*128
                local before=active.heavy_blocked and item.blocked or item.original
                local after=should_block and item.blocked or item.original
                if mem.read(address,128)~=before then return false,'heavy_row_changed' end
                plan[#plan+1]={address=address,before=before,after=after,item=item}
            end
            local written={}
            for _,entry in ipairs(plan)do
                if mem.read(entry.address,128)~=entry.before or not mem.write(entry.address,entry.after)then
                    for i=#written,1,-1 do local prior=written[i]
                        if mem.read(prior.address,128)==prior.after then mem.write(prior.address,prior.before)end
                    end
                    return false,'heavy_row_write_failed'
                end
                written[#written+1]=entry
            end
            for _,entry in ipairs(plan)do active.compiled.rows[entry.item.index]=entry.after end
            active.heavy_blocked=should_block
            local refreshed=refresh_cache(active)
            if holes then holes.tick(active.compiled,should_block)end
            emit('TITAN_CLASS_SELECTION blocked='..tostring(should_block)..' rows='..#plan..' cached_candidates='..refreshed)
            return true
        end
        function state.poll()
            local now=os.clock();if now-last<0.5 then return state.status or 'mix_waiting'end;last=now
            if state.native_restore_blocked then state.status='mix_waiting:native_restore_conflict_restart_game';return state.status end
            local d=director()
            if not d then if active then state.restore_all()end;state.director_addr=nil;state.rosters={};state.headers={};state.status='roster_not_in_memory';return state.status end
            local h=B.ptr(mem.read(d+0x660,8),0)
            if not h then if active then state.restore_all()end;state.status='mix_waiting';return state.status end
            if not active or d~=active.director or h~=active.shadow then
                if active then state.restore_all()end
                active=nil
                local a,why=apply(d,h)
                if not a then
                    if why~=blocked and writefile then writefile(mix_file,'NOT INSTALLED: '..tostring(why)..'\n')end
                    local rt=rawget(_G,'PickYourBots')
                    if why~=blocked and rt and rt.publish_banner and not tostring(why):find('^waiting') and not tostring(why):find('unreadable')
                        and not tostring(why):find('changed_during_build') and why~='roster_layout_unknown' then
                        rt.publish_banner((faction_name=='terminid' and 'PICK YOUR BUGS' or faction_name=='illuminate' and 'PICK YOUR SQUIDS' or 'PICK YOUR BOTS')..': MIX NOT APPLIED - '..tostring(why):gsub('_',' '):sub(1,120),true)
                    end
                    report(why);state.status='mix_waiting:'..why;return state.status end
                active=a;blocked=nil;state.patched=state.patched+1
            end
            if guard_slots then guard_slots.tick(active.compiled)end
            local count=refresh_cache(active)
            if holes then holes.tick(active.compiled,active.heavy_blocked)end
            if illuminate_ships then illuminate_ships.tick(active.compiled)end
            if count>0 then emit('unit_mix_cache_refreshed candidates='..count)end
            state.patched=state.patched+count;state.status=(faction_name=='terminid' and 'active_terminids_replaced' or faction_name=='illuminate' and 'active_illuminate_replaced' or 'active_automatons_replaced')
            return state.status
        end
        return state
    end
end)()

local engine = (function()
return function(mem, profile, emit, writefile)
    if profile.disabled_by_menu then return {poll=function()return 'disabled_in_menu'end,restore_all=function()return 0,0,'disabled'end,in_mission=function()return false end} end
    if profile.mix_enabled then return mix_engine(mem, profile, emit, writefile) end
    local function raw(hex) return (hex:gsub('..', function(b) return string.char(tonumber(b, 16)) end)) end
    local function hexof(s)
        if type(s) ~= 'string' then return '' end
        return (s:gsub('.', function(c) return string.format('%02x', c:byte()) end))
    end
    local function u32(s, o)
        if not s or o + 4 > #s then return nil end
        local a,b,c,d = s:byte(o+1,o+4)
        return a+b*256+c*65536+d*16777216
    end
    local function ptr(s, o)
        local lo, hi = u32(s,o), u32(s,o+4)
        if not lo or not hi or hi >= 32768 then return nil end
        local n = lo + hi*4294967296
        if n < 65536 then return nil end
        return n
    end
    local function pack(n)
        local bytes = {}
        for i=1,8 do bytes[i]=string.char(n%256); n=math.floor(n/256) end
        return table.concat(bytes)
    end
    local function put(s,o,b) return s:sub(1,o)..b..s:sub(o+#b+1) end

    local cfg = profile.config or {}
    local function on(name) return cfg[name] ~= false end

    local target = raw(profile.target_le)
    local tagset, entityset, keepset = {}, {}, {}
    for _, t in ipairs(profile.tags) do tagset[raw(t)] = true end
    for _, e in ipairs(profile.entities_le) do entityset[raw(e)] = true end
    for _, e in ipairs(profile.keep_entities_le or {}) do keepset[raw(e)] = true end
    entityset[target] = true   -- named or raw target hash: never rejected
    local function resolve_le(n)
        if type(n) ~= 'string' then return nil end
        if n:match('^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$') then return n:lower() end
        return profile.names[n] or (profile.units and profile.units[n])
    end
    local target_list = {}
    for _, n in ipairs(profile.targets or {}) do
        if resolve_le(n) then target_list[#target_list + 1] = raw(resolve_le(n)) end
    end
    if #target_list == 0 then target_list[1] = target end
    local target_set = {}
    for _, t in ipairs(target_list) do target_set[t] = true; entityset[t] = true end
    local name_of = {}
    for name, le in pairs(profile.units or {}) do name_of[raw(le)] = name end
    for name, le in pairs(profile.names or {}) do name_of[raw(le)] = name end
    local GUARD = profile.guard or {}
    local guard_group_set = {}
    for _, g in ipairs(GUARD.groups or {}) do guard_group_set[g] = true end
    local retag4 = raw(GUARD.retag or '')
    local is_trooper = {}
    for _, n in ipairs(profile.trooper_names or {}) do
        if resolve_le(n) then is_trooper[raw(resolve_le(n))] = true end
    end
    for _, le in ipairs(profile.trooper_le or {}) do is_trooper[raw(le)] = true end
    local drop_units, drop_cost4 = {}, nil
    for _, n in ipairs(GUARD.retag_units or {}) do
        if resolve_le(n) then drop_units[#drop_units + 1] = raw(resolve_le(n)) end
    end
    if type(GUARD.retag_cost) == 'number' then
        local ffi = require('ffi')
        drop_cost4 = ffi.string(ffi.new('float[1]', GUARD.retag_cost), 4)
    end
    local guard_units = {}
    for _, n in ipairs(GUARD.units or {}) do
        if resolve_le(n) then guard_units[#guard_units + 1] = raw(resolve_le(n)) end
    end
    local guard_tags = {}          -- 4 byte tag -> number of guard records that use it
    local PATROL = profile.patrol or {}
    local patrol_group_set = {}
    for _, g in ipairs(PATROL.groups or {}) do patrol_group_set[g] = true end
    local patrol_tag4 = raw(PATROL.tag or '')
    local function patrol_active()
        return #(PATROL.counts or {}) > 0 and #patrol_tag4 == 4 and next(patrol_group_set) ~= nil
    end
    local POI = profile.poi or {}
    local poi_every = (type(POI.every) == 'number' and POI.every >= 2) and math.floor(POI.every) or 0
    local poi_phase = (type(POI.phase) == 'number') and math.floor(POI.phase) or 1
    local FILL = profile.drop_fill or {}
    local fill_n = (type(FILL.fill) == 'number' and FILL.fill >= 2) and math.floor(FILL.fill) or 0
    local fill_group_set = {}
    for _, g in ipairs(FILL.groups or {}) do fill_group_set[g] = true end
    local guard_others = (GUARD.others == 'trooper') and 'trooper' or 'target'
    local function guard_active()
        return GUARD.enabled ~= false and #retag4 == 4 and next(guard_group_set) ~= nil
            and (profile.config or {}).guard_troopers ~= false
    end

    local base = mem.module('game.dll')
    if not base then return nil, 'game_module_unavailable' end

    local STRIDE = profile.row_stride
    local WINDOW = profile.row_window
    local MIN_HITS = profile.min_tag_hits
    local LOW_MIN = profile.min_tag_hits_low

    local state = {
        rosters = {}, headers = {}, header_of = {}, header_slots = {},
        unknown_reported = {}, behavior_blocks = {},
        patched = 0, dumps = 0, backups = {}, phase = 'init',
    }

    --========================================================== 内容校验
    -- 探针:挑几行分散在名录各处的行。
    --   tier1 = 标签+实体(16 字节,极稀有) —— 实体若变了就找不到,但还有 tier2
    --   tier2 = 只用标签(8 字节)       —— 实体变了也能找到
    -- 探针数量要克制:每块(128KB)每多一个探针就多一次全块搜索。
    local PROBE_ROWS = {1, 3, 8, 15, 25, 36}
    local function scan_needles()
        local out = {}
        for _, i in ipairs(PROBE_ROWS) do
            local row = profile.rows[i]
            if row then out[#out+1] = { pat = raw(row[1]) .. raw(row[2]), len = 16, tier = 1 } end
        end
        for _, i in ipairs(PROBE_ROWS) do
            local row = profile.rows[i]
            if row then out[#out+1] = { pat = raw(row[1]), len = 8, tier = 2 } end
        end
        return out
    end

    local function row_tag_at(bytes, k) return bytes:sub(k*STRIDE + 1, k*STRIDE + 8) end
    local function row_entity_at(bytes, k) return bytes:sub(k*STRIDE + 9, k*STRIDE + 16) end

    -- ★ 判据必须是"从第 0 行开始连续命中多长",不是"48 行里总共命中多少"。
    --   用总数会把"起点下方 18 行"的位置也判成合法(窗口里仍覆盖 ≥30 条名录行),
    --   而向下归一化救不了它 —— 实测会一份名录变成 19 份,进而到处乱写。
    local function leading_run(addr)
        local bytes = mem.read(addr, WINDOW * STRIDE)
        if not bytes then return 0 end
        local n = 0
        for k = 0, WINDOW - 1 do
            if tagset[row_tag_at(bytes, k)] then n = n + 1 else break end
        end
        return n
    end

    local function normalize_start(addr)
        local b = addr
        for _ = 1, 256 do
            local prev = b - STRIDE
            if prev < 65536 then break end
            local one = mem.read(prev, STRIDE)
            if not one or not tagset[one:sub(1, 8)] then break end
            b = prev
        end
        return b
    end

    local function snapshot(addr, count)
        local bytes = mem.read(addr, count * STRIDE)
        if not bytes then return nil end
        local tags, ents = {}, {}
        for k = 0, count - 1 do
            tags[#tags+1] = hexof(row_tag_at(bytes, k))
            ents[#ents+1] = hexof(row_entity_at(bytes, k))
        end
        return { tags = tags, entities = ents, raw = bytes }
    end

    --========================================================== 写入
    local function flush_backup()
        if type(writefile) ~= 'function' or #state.backups == 0 then return end
        local lines = { '# original bytes before our writes (kind, address, LE hex)' }
        for i = 1, #state.backups do lines[#lines+1] = state.backups[i] end
        writefile('PickYourBots_backup.txt', table.concat(lines, '\n') .. '\n')
    end

    local function record_backup(kind, addr, original, written)
        if written and #original == 8 and #written == 8 then
            state.restore_list = state.restore_list or {}
            state.restore_list[#state.restore_list + 1] = { addr = addr, original = original, written = written }
        end
        state.backups[#state.backups+1] = string.format('%-9s 0x%016x %s', kind, addr, hexof(original))
        if #state.backups == 1 or #state.backups % 8 == 0 then flush_backup() end
    end

    local write_tag4      -- defined with the guard helpers below
    local function write_entity(addr, original, kind, is_image, value)
        if is_image and not mem.is_allowed_image_field(addr) then
            if not mem.allow_image_field(addr, base) then
                emit(string.format('image_field_register_failed 0x%x', addr))
                return false
            end
        end
        if not mem.writable(addr, 8) then
            emit(string.format('%s_field_not_writable 0x%x', kind, addr))
            return false
        end
        local ok, why = mem.write(addr, value or target)
        if not ok then
            emit(string.format('%s_write_rejected 0x%x reason=%s', kind, addr, tostring(why)))
            return false
        end
        record_backup(kind, addr, original, value or target)
        return true
    end

    -- 名录行:逐行内容校验后写入
    local function patch_rows(addr, is_image)
        local bytes = mem.read(addr, WINDOW * STRIDE)
        if not bytes then return 0, 0, nil end
        local seen, patched = 0, 0
        local ents = {}
        local drop_i = 0
        for k = 0, WINDOW - 1 do
            local tag = row_tag_at(bytes, k)
            local ent = row_entity_at(bytes, k)
            if tag ~= string.rep('\0', 8) then ents[#ents+1] = ent end
            if tagset[tag] then
                seen = seen + 1
                if keepset[ent] or ent == string.rep('\0', 8) then
                    -- exempt units (spawners, gunships) stay as they are
                elseif guard_active() and #drop_units > 0 and tag:sub(1, 4) == retag4 then
                    -- the rows every drop and patrol now asks for: the chosen units in turn, plus their cost
                    local unit = drop_units[(drop_i % #drop_units) + 1]
                    drop_i = drop_i + 1
                    if ent ~= unit and write_entity(addr + k * STRIDE + 8, ent, 'row', is_image, unit) then
                        patched = patched + 1
                    end
                    -- the spawn cost is the float at +0x20 (v1.5 to v1.9 wrote it at +0x1C by mistake);
                    -- only rows whose current value looks like a cost (1 to 1000) are touched
                    if drop_cost4 then
                        local cur = bytes:sub(k * STRIDE + 0x21, k * STRIDE + 0x24)
                        local ffi = require('ffi')
                        local fv = ffi.new('float[1]'); ffi.copy(fv, cur, 4)
                        if cur ~= drop_cost4 and fv[0] >= 1 and fv[0] <= 1000 then
                            if write_tag4(addr + k * STRIDE + 0x20, drop_cost4) then patched = patched + 1 end
                        end
                    end
                elseif guard_active() and is_trooper[ent] then
                    -- basic troopers stay vanilla everywhere: guard posts need them (emplaced guns);
                    -- drops and patrols never ask for these rows any more (their tags were redirected)
                    state.guard_rows_kept_pass = (state.guard_rows_kept_pass or 0) + 1
                elseif guard_active() and guard_others == 'trooper' and guard_tags[tag:sub(1, 4)] and #guard_units > 0 then
                    local unit = guard_units[(k % #guard_units) + 1]
                    if write_entity(addr + k * STRIDE + 8, ent, 'row', is_image, unit) then
                        patched = patched + 1
                        state.guard_rows_converted = (state.guard_rows_converted or 0) + 1
                    end
                elseif guard_active() and poi_every > 0 and #guard_units > 0 and (k % poi_every) == (poi_phase % poi_every) then
                    -- every Nth remaining row is a basic trooper, so fortress and outpost guards include some
                    local unit = guard_units[(k % #guard_units) + 1]
                    if write_entity(addr + k * STRIDE + 8, ent, 'row', is_image, unit) then
                        patched = patched + 1
                        state.poi_rows = (state.poi_rows or 0) + 1
                    end
                elseif not target_set[ent] then
                    local unit = target_list[(k % #target_list) + 1]
                    if write_entity(addr + k * STRIDE + 8, ent, 'row', is_image, unit) then
                        patched = patched + 1
                    end
                end
            end
        end
        return seen, patched, ents
    end

    -- 8 组刷新模板:表头 +off 是数组指针、+off+8 是条数；记录内 +0x100 是直接实体
    local function patch_templates(header)
        local h = mem.read(header, 0xb0)
        if not h then return 0, 0 end
        local groups, edited = 0, 0
        for _, g in ipairs(profile.groups) do
            local off = g[1]
            local address = ptr(h, off)
            local count = u32(h, off + 8)
            if address and count and count > 0 and count <= 512 then
                local bytes = mem.read(address, count * 0x118)
                if bytes then
                    groups = groups + 1
                    for i = 0, count - 1 do
                        local o = i * 0x118 + 0x100
                        local id = bytes:sub(o + 1, o + 8)
                        if entityset[id] and not keepset[id] and not target_set[id] then
                            if write_entity(address + o, id, 'template', false) then
                                edited = edited + 1
                            end
                        elseif not entityset[id] and not keepset[id] and id ~= string.rep('\0', 8)
                            and id ~= raw(profile.squad_container_le)
                            and not state.unknown_reported[id] then
                            state.unknown_reported[id] = true
                            emit('unmapped_template_entity=' .. hexof(id))
                        end
                    end
                end
            end
        end
        return groups, edited
    end

    --========================================================== guard posts keep troopers
    local function guard_enabled()
        return GUARD.enabled ~= false and #retag4 == 4 and next(guard_group_set) ~= nil
    end

    local function group_bytes(h, off)
        local address = ptr(h, off)
        local count = u32(h, off + 8)
        if not address or not count or count < 1 or count > 512 then return nil end
        local bytes = mem.read(address, count * 0x118)
        if not bytes then return nil end
        return address, count, bytes
    end

    -- entries of one template record: (tag u32, count u32, pad u32) x n, then the squad container
    local function record_entries(bytes, i)
        local out = {}
        for e = 0, 20 do
            local o = i * 0x118 + e * 12
            local t = bytes:sub(o + 1, o + 4)
            local c = u32(bytes, o + 4)
            if t == '\0\0\0\0' or not c or c == 0 or c > 1000 then break end
            out[#out + 1] = { o = o, tag = t, count = c }
        end
        return out
    end

    local function tag_rows_desc(tag4)
        local names, seen = {}, {}
        for _, info in pairs(state.rosters) do
            local snap = info.snapshot
            if snap then
                for i = 1, #snap.tags do
                    if snap.tags[i]:sub(1, 8) == hexof(tag4) then
                        local n = name_of[raw(snap.entities[i])] or snap.entities[i]:sub(1, 8)
                        if not seen[n] then seen[n] = true; names[#names + 1] = n end
                    end
                end
                if #names > 0 then break end
            end
        end
        table.sort(names)
        return #names > 0 and table.concat(names, ',') or '?'
    end

    -- one line per template group, once: which tags it asks for (lets the guard group be checked)
    local function describe_groups(haddr, h)
        if state.described and state.described[haddr] then return end
        state.described = state.described or {}
        state.described[haddr] = true
        for _, g in ipairs(profile.groups) do
            local address, count, bytes = group_bytes(h, g[1])
            if bytes then
                local per, order = {}, {}
                for i = 0, count - 1 do
                    for _, en in ipairs(record_entries(bytes, i)) do
                        local key = hexof(en.tag)
                        if not per[key] then per[key] = { records = 0, units = 0, tag = en.tag }; order[#order + 1] = key end
                        per[key].records = per[key].records + 1
                        per[key].units = per[key].units + en.count
                    end
                end
                local parts = {}
                for _, key in ipairs(order) do
                    parts[#parts + 1] = string.format('%s[x%d recs, %d units: %s]', key, per[key].records,
                        per[key].units, tag_rows_desc(per[key].tag))
                end
                emit(string.format('template_group +%d records=%d%s tags=%s', g[1], count,
                    guard_group_set[g[1]] and ' (GUARD)' or '', #parts > 0 and table.concat(parts, ' ') or '-'))
            end
        end
    end

    --========================================================== variant table dump
    -- header +0x10 = pointer to the variant table, +0x18 = its entry count; header +0xA0 = another table.
    -- Nothing is assumed about the entry layout: the raw bytes are written 32 per line and every
    -- 4 or 8 byte value that matches a known roster tag, roster id or unit name is labelled.
    local function dump_variants(haddr, h)
        if not on('dump_variants') or type(writefile) ~= 'function' then return end
        state.variant_dumped = state.variant_dumped or {}
        if state.variant_dumped[haddr] then return end
        state.variant_dumped[haddr] = true

        local name_lookup = {}
        for n, le in pairs(profile.units or {}) do name_lookup[raw(le)] = n end
        for n, le in pairs(profile.names or {}) do name_lookup[raw(le)] = n end
        for le, n in pairs(profile.extra_names or {}) do
            if not name_lookup[raw(le)] then name_lookup[raw(le)] = n end
        end
        local tag_rows, id_rows = {}, {}
        for _, info in pairs(state.rosters) do
            local snap = info.snapshot
            if snap then
                for i = 0, #snap.tags - 1 do
                    local o = i * STRIDE
                    local t = snap.raw:sub(o + 1, o + 4)
                    if snap.raw:sub(o + 5, o + 8) == '\0\0\0\0' and t ~= '\0\0\0\0' then
                        tag_rows[t] = (tag_rows[t] and (tag_rows[t] .. ',') or '') .. i
                    end
                    for p = 0x58, 0x7C, 4 do
                        local d = snap.raw:sub(o + p + 1, o + p + 4)
                        if d ~= '\0\0\0\0' then id_rows[d] = (id_rows[d] and (id_rows[d] .. ',') or '') .. i end
                    end
                end
                break
            end
        end

        local function label(bytes, o)
            local notes = {}
            for p = 0, 28, 4 do
                local d = bytes:sub(o + p + 1, o + p + 4)
                if #d == 4 then
                    if p % 8 == 0 then
                        local q = bytes:sub(o + p + 1, o + p + 8)
                        if #q == 8 and name_lookup[q] then notes[#notes + 1] = string.format('+%d unit=%s', p, name_lookup[q]) end
                    end
                    if tag_rows[d] then notes[#notes + 1] = string.format('+%d tag=%s(rows %s)', p, hexof(d), tag_rows[d]) end
                    if id_rows[d] then notes[#notes + 1] = string.format('+%d rowid=%s(rows %s)', p, hexof(d), id_rows[d]) end
                    local hi = u32(bytes, o + p + 4)
                    if p % 8 == 0 and hi and hi >= 256 and hi < 32768 then notes[#notes + 1] = string.format('+%d ptr', p) end
                end
            end
            return table.concat(notes, '  ')
        end

        local lines = {
            '# All Automatons Replaced: variant table dump (nothing here was changed)',
            string.format('# header=0x%x  variant ptr=0x%x count=%s   second table ptr=0x%x count=%s',
                haddr, ptr(h, 0x10) or 0, tostring(u32(h, 0x18)), ptr(h, 0xA0) or 0, tostring(u32(h, 0xA8))),
            '# header (0xB0 bytes, 8 dwords per line):',
        }
        for o = 0, 0xA0, 32 do
            local parts = {}
            for p = 0, 28, 4 do parts[#parts + 1] = hexof(h:sub(o + p + 1, o + p + 4)) end
            lines[#lines + 1] = string.format('hdr+0x%02x  %s', o, table.concat(parts, ' '))
        end
        local function table_dump(title, address, sizes)
            if not address then lines[#lines + 1] = '# ' .. title .. ': no pointer'; return end
            local bytes
            for _, n in ipairs(sizes) do
                bytes = mem.read(address, n)
                if bytes then break end
            end
            if not bytes then lines[#lines + 1] = string.format('# %s at 0x%x: unreadable', title, address); return end
            lines[#lines + 1] = string.format('# %s at 0x%x, %d bytes:', title, address, #bytes)
            for o = 0, #bytes - 32, 32 do
                local parts = {}
                for p = 0, 28, 4 do parts[#parts + 1] = hexof(bytes:sub(o + p + 1, o + p + 4)) end
                local l = label(bytes, o)
                lines[#lines + 1] = string.format('+0x%04x  %s%s', o, table.concat(parts, ' '), l ~= '' and ('   | ' .. l) or '')
            end
        end
        table_dump('variant table', ptr(h, 0x10), { 8192, 6144, 4096, 2048, 1024, 512 })
        table_dump('second table', ptr(h, 0xA0), { 2048, 1024, 512, 256 })
        writefile('PickYourBots_variants.txt', table.concat(lines, '\n') .. '\n')
        emit(string.format('variants_dumped file=PickYourBots_variants.txt count=%s lines=%d',
            tostring(u32(h, 0x18)), #lines))
    end

    local function collect_guard_tags(headers)
        local tags = {}
        if not guard_enabled() or not on('guard_troopers') then return tags end
        for haddr in pairs(headers) do
            local h = mem.read(haddr, 0xb0)
            if h then
                describe_groups(haddr, h)
                dump_variants(haddr, h)
                for _, g in ipairs(profile.groups) do
                    if guard_group_set[g[1]] then
                        local _, count, bytes = group_bytes(h, g[1])
                        if bytes then
                            for i = 0, count - 1 do
                                for _, en in ipairs(record_entries(bytes, i)) do
                                    if en.tag ~= retag4 then tags[en.tag] = (tags[en.tag] or 0) + 1 end
                                end
                            end
                        end
                    end
                end
            end
        end
        return tags
    end

    -- 4 byte tag write through an aligned 8 byte window (game.dll image pages only allow
    -- registered, 8 byte aligned fields)
    write_tag4 = function(addr, tag4)
        local aligned = addr - (addr % 8)
        local within = addr - aligned
        if within > 4 then return false end
        local cur = mem.read(aligned, 8)
        if not cur then return false end
        local new = cur:sub(1, within) .. tag4 .. cur:sub(within + 5)
        local r = mem.region(aligned)
        if r and r.kind == 0x1000000 and not mem.is_allowed_image_field(aligned) then
            if not mem.allow_image_field(aligned, base) then return false end
        end
        if not mem.writable(aligned, 8) then
            if not state.tag_write_reported then
                state.tag_write_reported = true
                emit(string.format('template_tag_not_writable 0x%x kind=%s protect=%s', aligned,
                    r and string.format('0x%x', r.kind) or '?', r and string.format('0x%x', r.protect) or '?'))
            end
            return false
        end
        local ok = mem.write(aligned, new)
        if ok then record_backup('tpl_tag', aligned, cur, new) end
        return ok
    end

    local function retag_tag_exists()
        for _, info in pairs(state.rosters) do
            local snap = info.snapshot
            if snap then
                for i = 1, #snap.tags do
                    if snap.tags[i]:sub(1, 8) == hexof(retag4) then return true end
                end
            end
        end
        return false
    end

    -- A keep exemption on a roster entity is not enough: the non-guard
    -- template may still redirect that entity's entire spawn tag to the Hulk
    -- row. Preserve a tag when every row using it is explicitly kept. The
    -- siege engine and Factory Strider share 5ad0d33e, so convoy requests
    -- must continue to use their original rows.
    local function kept_only_tags()
        local totals, kept = {}, {}
        for _, info in pairs(state.rosters) do
            local snap = info.snapshot
            if snap then
                for i, full_tag in ipairs(snap.tags) do
                    local tag4 = raw(full_tag:sub(1, 8))
                    totals[tag4] = (totals[tag4] or 0) + 1
                    if keepset[raw(snap.entities[i])] then kept[tag4] = (kept[tag4] or 0) + 1 end
                end
            end
        end
        local protected = {}
        for tag4, n in pairs(totals) do if kept[tag4] == n then protected[tag4] = true end end
        return protected
    end

    -- Every non-guard group may redirect guard tags except tags whose whole
    -- roster is explicitly kept (including the convoy's shared Strider tag).
    local function retag_non_guard(header)
        if not guard_enabled() or not on('guard_troopers') or next(guard_tags) == nil then return 0 end
        if not retag_tag_exists() then
            if not state.retag_missing_reported then
                state.retag_missing_reported = true
                emit('retag_tag_not_in_roster ' .. hexof(retag4) .. ' (drops keep their own tags; check guard_retag)')
            end
            return 0
        end
        local h = mem.read(header, 0xb0)
        if not h then return 0 end
        local protected = kept_only_tags()
        state.preserved_tag_reported = state.preserved_tag_reported or {}
        for tag4 in pairs(protected) do
            if guard_tags[tag4] and not state.preserved_tag_reported[tag4] then
                state.preserved_tag_reported[tag4] = true
                emit('preserved_template_tag=' .. hexof(tag4) .. ' reason=all_roster_rows_kept')
            end
        end
        local changed = 0
        for _, g in ipairs(profile.groups) do
            if not guard_group_set[g[1]] then
                local address, count, bytes = group_bytes(h, g[1])
                if bytes then
                    for i = 0, count - 1 do
                        for _, en in ipairs(record_entries(bytes, i)) do
                            if guard_tags[en.tag] and not protected[en.tag]
                                and write_tag4(address + en.o, retag4) then
                                changed = changed + 1
                            end
                        end
                    end
                end
            end
        end
        return changed
    end

    local function u32_string(n)
        return string.char(n % 256, math.floor(n / 256) % 256, math.floor(n / 65536) % 256, math.floor(n / 16777216) % 256)
    end

    local function roster_has_tag(tag4)
        for _, info in pairs(state.rosters) do
            local snap = info.snapshot
            if snap then
                for i = 1, #snap.tags do
                    if snap.tags[i]:sub(1, 8) == hexof(tag4) then return true end
                end
            end
        end
        return false
    end

    -- append (tag, count) to every non empty record of the patrol groups that has room and no such entry yet
    local function add_patrol_troopers(header)
        if not patrol_active() then return 0 end
        if not roster_has_tag(patrol_tag4) then
            if not state.patrol_tag_reported then
                state.patrol_tag_reported = true
                emit('patrol_tag_not_in_roster ' .. hexof(patrol_tag4) .. ' (no troopers added)')
            end
            return 0
        end
        local h = mem.read(header, 0xb0)
        if not h then return 0 end
        local added = 0
        for _, g in ipairs(profile.groups) do
            if patrol_group_set[g[1]] then
                local address, count, bytes = group_bytes(h, g[1])
                if bytes then
                    for i = 0, count - 1 do
                        local ents = record_entries(bytes, i)
                        if #ents > 0 and #ents <= 19 then
                            local has = false
                            for _, en in ipairs(ents) do
                                if en.tag == patrol_tag4 then has = true; break end
                            end
                            if not has then
                                local n = PATROL.counts[(i % #PATROL.counts) + 1]
                                local at = address + i * 0x118 + #ents * 12
                                if write_tag4(at, patrol_tag4) and write_tag4(at + 4, u32_string(n)) then
                                    added = added + 1
                                end
                            end
                        end
                    end
                end
            end
        end
        return added
    end

    -- raise every record of the fill groups to at least fill_n units, on the entry that asks for the drop rows
    local function fill_drop_records(header)
        if fill_n <= 0 or not guard_active() or #retag4 ~= 4 then return 0 end
        if not retag_tag_exists() then return 0 end
        local h = mem.read(header, 0xb0)
        if not h then return 0 end
        local raised = 0
        for _, g in ipairs(profile.groups) do
            if fill_group_set[g[1]] then
                local address, count, bytes = group_bytes(h, g[1])
                if bytes then
                    local before = {}
                    for i = 0, count - 1 do
                        local ents = record_entries(bytes, i)
                        if #ents > 0 then
                            local total = 0
                            for _, en in ipairs(ents) do total = total + en.count end
                            before[total] = (before[total] or 0) + 1
                            if total < fill_n then
                                local need = fill_n - total
                                local idx
                                for j, en in ipairs(ents) do
                                    if en.tag == retag4 then idx = j; break end
                                end
                                local base = address + i * 0x118
                                if idx then
                                    if write_tag4(address + ents[idx].o + 4, u32_string(ents[idx].count + need)) then   -- o already includes the record offset
                                        raised = raised + 1
                                    end
                                elseif #ents <= 19 then
                                    if write_tag4(base + #ents * 12, retag4) and write_tag4(base + #ents * 12 + 4, u32_string(need)) then
                                        raised = raised + 1
                                    end
                                end
                            end
                        end
                    end
                    state.fill_reported = state.fill_reported or {}
                    if not state.fill_reported[g[1]] then
                        state.fill_reported[g[1]] = true
                        local sizes = {}
                        for n in pairs(before) do sizes[#sizes + 1] = n end
                        table.sort(sizes)
                        local parts = {}
                        for _, n in ipairs(sizes) do parts[#parts + 1] = n .. 'x' .. before[n] end
                        emit(string.format('drop_fill group +%d records=%d sizes before (units x records): %s -> at least %d',
                            g[1], count, table.concat(parts, ' '), fill_n))
                    end
                end
            end
        end
        return raised
    end

    -- 变体表计数清零:防止目标被难度/星球再映射成别的变体
    local function patch_variant(header)
        local h = mem.read(header, 0xb0)
        if not h then return false end
        local count = u32(h, 0x18)
        if count == 0 then return true end
        if not on('variant_disable') then return false end
        if not mem.writable(header + 0x18, 4) then
            -- 表头在只读镜像页里,写不了;只报一次,别把日志刷满
            if not state.variant_reported then
                state.variant_reported = true
                emit(string.format('variant_field_not_writable 0x%x (只读页;不影响替换)', header))
            end
            return false
        end
        local ok = mem.write(header + 0x18, string.rep('\0', 4))
        if ok then
            record_backup('variant', header + 0x18, h:sub(0x19, 0x1c))
            emit(string.format('variant_mapping_disabled header=0x%x old_count=%d', header, count))
        end
        return ok
    end

    -- 候选缓存:引擎在建好候选之后**不会再回去读名录行**,所以这些已经缓存好的记录
    -- 必须单独改写(v1 就是靠这一路兜住的)。
    -- director 指针不是猜的 —— 它必须**出现在 game.dll 镜像里**(即那个全局变量),
    -- 这比 v1 的"RVA 对得上"更硬。每条候选记录还要 id ∈ 已知实体 才写。
    local function patch_candidates(director)
        if not on('candidates') then return 0, 0 end
        local context = director + profile.candidate_context
        local counts = mem.read(context + profile.candidate_counts, 32)
        if not counts then return 0, 0 end
        local pools, replaced = 0, 0
        for index, group in ipairs(profile.pools) do
            local n = u32(counts, (index - 1) * 4)
            if n and n > 0 and n <= group[2] then
                pools = pools + 1
                local address = context + group[1]
                local bytes = mem.read(address, n * profile.candidate_stride)
                if bytes then
                    for i = 0, n - 1 do
                        local o = i * profile.candidate_stride
                        local id = bytes:sub(o + 0xb1, o + 0xb8)
                        if entityset[id] and not keepset[id] and not target_set[id] then
                            if mem.writable(address + o + 0xb0, 8) then
                                if mem.write(address + o + 0xb0, target_list[(i % #target_list) + 1]) then
                                    record_backup('cached', address + o + 0xb0, id)
                                    replaced = replaced + 1
                                end
                            end
                        end
                    end
                end
            elseif n and n > group[2] then
                state.pool_count_anomaly = (state.pool_count_anomaly or 0) + 1
            end
        end
        if replaced > 0 then
            emit(string.format('cached_entity_replaced total=%d director=0x%x',
                (state.cached_replacements or 0) + replaced, director))
        end
        state.cached_replacements = (state.cached_replacements or 0) + replaced
        return pools, replaced
    end

    --========================================================== TaskUser(任务组)
    -- 类型哈希 = djb2(类型名),自己算,不写死(顺带自证算对了)。
    local function dlsum(name)
        local r = 5381
        for i = 1, #name do r = (r * 33 + name:byte(i)) % 4294967296 end
        return (r - 5381) % 4294967296
    end
    local TU = profile.task_user
    local TU_TYPE = dlsum(TU.type_name)
    local TU_MASK = TU.mask

    local function u32le(n)
        return string.char(n % 256, math.floor(n / 256) % 256,
            math.floor(n / 65536) % 256, math.floor(n / 16777216) % 256)
    end

    -- 该类型的 LDLD 块签名:LDLD + 版本(=1) + 类型哈希
    local function taskuser_needles()
        return {{ pat = 'LDLD' .. u32le(1) .. u32le(TU_TYPE), len = 12, kind = 'taskuser' }}
    end

    -- 认出"任务组表"的块。只登记,真正的解析/写入在 patch_task_user 里。
    local function check_taskuser_block(magic)
        if state.behavior_blocks[magic] then return end
        local hdr = mem.read(magic, TU.data_off)
        if not hdr or hdr:sub(1, 4) ~= 'LDLD' then return end
        if u32(hdr, 4) ~= 1 or u32(hdr, 8) ~= TU_TYPE then return end
        local size = u32(hdr, 12)
        local need = TU.rec_off + TU.rec_elem            -- 至少要放得下第一条记录
        if not size or size < need or size > 8388608 then return end
        state.behavior_blocks[magic] = size
        emit(string.format('taskuser_block_found at=0x%x size=%d', magic, size))
    end

    local function is_task_user_value(v)
        if v == 0 then return false end
        if v > 0x100000 then return false end
        return v % 2 == 0                       -- 全部取值都是 2 的幂(≥2)
    end

    -- ★ 记录定位:内存里这张表**比文件大 616 字节**(实测 size 44192 vs 43576),
    --   按文件偏移算出来的记录位置会整体漂移(实测读到的是 +4 处的冷却字段)。
    --   所以从"文件偏移"出发左右滑动,判据三条:①行为 id 合理 ②+4 位模式像浮点(冷却)
    --   ③**现值 == 离线已知原值**(最强)。而且**只认唯一解** —— 滑到相邻记录上也会
    --   "看起来像一条记录",多解时就宁可不写(避免改写邻居单位)。
    --   返回 (记录地址, 相对文件偏移的漂移量, 当前值)。
    local function find_record(data, rec_index, hint_delta)
        local base = data + TU.rec_off + rec_index * TU.rec_elem
        local span = TU.search_span or 0
        local function probe(delta)
            local b = mem.read(base + delta, TU.rec_elem)
            if not b then return nil end
            local bid = u32(b, 0)
            local cdbits = u32(b, 4)
            local cur = u32(b, TU.task_user_off)
            local cd_ok = cdbits ~= nil and cdbits >= 0x3D000000 and cdbits <= 0x4F000000
            if bid and bid >= 1 and bid <= TU.behavior_id_max and cd_ok
                and cur == TU.expected_original then
                return { base + delta, delta, cur }
            end
            return nil
        end
        -- ① 先试上次测出的漂移量(同一局内不会变)—— 稳态下这里就 1 个读取
        if hint_delta then
            local hit = probe(hint_delta)
            if hit then return hit[1], hit[2], hit[3] end
        end
        -- ② 再试"文件偏移"
        local first = probe(0)
        if first then return first[1], first[2], first[3] end
        -- ③ 都不中才滑动搜索(**整局只做一次**,512 个读取;多解时宁可不写)
        --    注意:布局漂移是全表统一的,不能按 rec_index 记 —— 否则每个不同下标的槽
        --    都会再扫一遍(实测每 2 秒白白多读 512 次)。
        if not state.taskuser_swept then
            state.taskuser_swept = true
            local hits, pick = 0, nil
            for d = 4, span, 4 do
                for _, delta in ipairs({d, -d}) do
                    local hit = probe(delta)
                    if hit then
                        hits = hits + 1
                        if not pick then pick = hit end
                    end
                end
            end
            if hits == 1 then
                return pick[1], pick[2], pick[3]
            elseif hits > 1 and not state.taskuser_ambiguous_reported then
                state.taskuser_ambiguous_reported = true
                emit(string.format('taskuser_layout_ambiguous hits=%d span=%d (宁可不写)', hits, span))
            end
        end
        return nil, nil, nil
    end

    -- 实体表在内存里可能是私有堆,也可能是**映射页**(游戏数据文件映射进来)。
    -- 私有页(PAGE_READWRITE)和映射页(PAGE_READWRITE / PAGE_WRITECOPY)都能写;
    -- 只读页不碰(不做 VirtualProtect)。写不进去就把区域信息写进日志,便于下次定位。
    local function write_u32_checked(addr, value)
        local r = mem.region(addr)
        if not r or r.state ~= 0x1000 then return false, 'unmapped', r end
        if addr + 4 > r.base + r.size then return false, 'out_of_region', r end
        if r.kind ~= 0x20000 and r.kind ~= 0x40000 then return false, 'kind', r end
        if r.protect ~= 0x04 and r.protect ~= 0x08 then return false, 'protect', r end
        if not mem.write_raw(addr, u32le(value)) then return false, 'write_failed', r end
        if mem.read(addr, 4) ~= u32le(value) then return false, 'readback_mismatch', r end
        return true, 'ok', r
    end

    -- 把目标实体的 TaskUser 改成掩码。逐条校验:索引槽对齐、行为 id 合理、
    -- 现值必须是合法的 TaskUser 值(避免把垃圾数据当记录写坏)。
    local function patch_task_user_explicit()
        state.taskuser_mask = TU_MASK
        if not on('task_user') or TU_MASK == 0 then return 0, 0 end
        local blocks, fixed = 0, 0
        for magic in pairs(state.behavior_blocks) do
            local hdr = mem.read(magic, TU.data_off)
            if not hdr or hdr:sub(1, 4) ~= 'LDLD' or u32(hdr, 8) ~= TU_TYPE then
                state.behavior_blocks[magic] = nil
                state.block_scan_rounds = 0            -- 允许重新找(换图后表会被搬到别处)
                state.next_block_scan = 0
                emit(string.format('taskuser_block_lost at=0x%x', magic))
            else
                blocks = blocks + 1
                local data = magic + TU.data_off
                local span = TU.index_elem * TU.max_index_slots
                local idx_bytes = mem.read(data + TU.index_off, span)
                if idx_bytes then
                    local from, n = 1, 0
                    while n < 16 do
                        local at = idx_bytes:find(target, from, true)
                        if not at then break end
                        from = at + 1
                        if (at - 1) % TU.index_elem == 0 then
                            n = n + 1
                            local slot = data + TU.index_off + (at - 1)
                            local rec_index = u32(idx_bytes, (at - 1) + 8)
                            if rec_index and rec_index < TU.max_records then
                                local rec, delta, cur = find_record(data, rec_index, state.taskuser_delta)
                                local orig = rec and mem.read(rec, TU.rec_elem)
                                if orig then
                                    local bid = u32(orig, 0)
                                    if delta ~= 0 and state.taskuser_delta ~= delta then
                                        state.taskuser_delta = delta
                                        emit(string.format(
                                            'taskuser_layout_delta=%+d (memory vs file; size=%d)',
                                            delta, state.behavior_blocks[magic] or 0))
                                    end
                                    if cur ~= TU_MASK then
                                        local ok, why, rinfo = write_u32_checked(rec + TU.task_user_off, TU_MASK)
                                        if ok then
                                            record_backup('taskuser', rec + TU.task_user_off,
                                                orig:sub(TU.task_user_off + 1, TU.task_user_off + 4))
                                            fixed = fixed + 1
                                            emit(string.format(
                                                'taskuser_patched at=0x%x behavior_id=%d 0x%X -> 0x%X (slot=0x%x idx=%d delta=%+d kind=0x%x)',
                                                rec, bid, cur, TU_MASK, slot, rec_index, delta,
                                                rinfo and rinfo.kind or 0))
                                        elseif not state.taskuser_write_reported then
                                            state.taskuser_write_reported = true
                                            emit(string.format(
                                                'taskuser_write_rejected at=0x%x reason=%s kind=%s protect=%s',
                                                rec + TU.task_user_off, tostring(why),
                                                rinfo and string.format('0x%x', rinfo.kind) or '?',
                                                rinfo and string.format('0x%x', rinfo.protect) or '?'))
                                        end
                                    end
                                elseif not state.taskuser_bad_reported then
                                    state.taskuser_bad_reported = true
                                    emit(string.format(
                                        'taskuser_record_rejected at=0x%x idx=%d (搜索 %d 字节内没有合法记录)',
                                        data + TU.rec_off + rec_index * TU.rec_elem, rec_index,
                                        TU.search_span or 0))
                                end
                            end
                        end
                    end
                end
            end
        end
        state.taskuser_fixed = (state.taskuser_fixed or 0) + fixed
        return blocks, fixed
    end

    --========================================================== TaskUser: automatic layout
    -- Nothing about this table is assumed beyond the header: the index (16 byte elements,
    -- entity hash at +0, record index at +8) starts at data+0, the 12 byte records
    -- (behavior id, cooldown, task user) follow after an unknown gap. The record array is the
    -- single position after the index where ALL N records (N = highest record index + 1)
    -- have a plausible behavior id and a task user that is 0 or a power of two. More than one
    -- such position, or none, means the layout is uncertain and nothing is written.
    local bitlib = require('bit')
    local ZERO8 = string.rep('\0', 8)

    local function plausible_record(s, o)
        local bid, tu = u32(s, o), u32(s, o + 8)
        if not bid or not tu then return false end
        if bid < 1 or bid > TU.behavior_id_max then return false end
        if tu == 0 then return true end
        return tu >= 2 and bitlib.band(tu, tu - 1) == 0
    end

    local function read_block(addr, size)
        local parts, off = {}, 0
        while off < size do
            local want = math.min(262144, size - off)
            local part = mem.read(addr + off, want)
            if not part then return nil end
            parts[#parts + 1] = part
            off = off + want
        end
        return table.concat(parts)
    end

    local function infer_layout(magic, size)
        local blk = read_block(magic, size)
        if not blk then return nil, 'block_unreadable' end
        local rel = TU.data_off + TU.index_off
        local index, n, max_ri = {}, 0, -1
        while n < TU.max_index_slots do
            local o = rel + n * TU.index_elem
            if o + TU.index_elem > #blk then break end
            local e, ri = blk:sub(o + 1, o + 8), u32(blk, o + 8)
            if e == ZERO8 or not ri or ri >= TU.max_records then break end
            if index[e] == nil then index[e] = ri end
            if ri > max_ri then max_ri = ri end
            n = n + 1
        end
        if n < 8 then return nil, 'no_index', { index_count = n } end
        local N = max_ri + 1
        local p0 = rel + n * TU.index_elem
        local limit = math.min(#blk - N * TU.rec_elem, p0 + TU.search_bytes)
        local perfect, best_ok, best_p = {}, -1, nil
        local p = p0
        while p <= limit do
            if plausible_record(blk, p) and plausible_record(blk, p + 12) and plausible_record(blk, p + 24) then
                local ok = 0
                for k = 0, N - 1 do
                    if plausible_record(blk, p + k * TU.rec_elem) then ok = ok + 1 end
                end
                if ok == N then perfect[#perfect + 1] = p end
                if ok > best_ok then best_ok, best_p = ok, p end
            end
            p = p + 4
        end
        local info = { index_count = n, records = N, index_end = p0, best_ok = best_ok, best_p = best_p,
                       perfect = #perfect, size = #blk, gap_bytes = #blk >= p0 + 32 and hexof(blk:sub(p0 + 1, p0 + 32)) or '' }
        if #perfect == 0 then return nil, 'no_perfect_record_array', info end
        -- The array starts at the LOWEST position where all N records are plausible. Higher
        -- positions only slide the window over records past the highest referenced index.
        -- The start must be sharp: the record just before it must not look like a record.
        local start = perfect[1]
        if start - TU.rec_elem >= p0 and plausible_record(blk, start - TU.rec_elem) then
            info.rec_start = start
            return nil, 'start_not_sharp', info
        end
        local run = 0
        while plausible_record(blk, start + run * TU.rec_elem) and start + (run + 1) * TU.rec_elem <= #blk do run = run + 1 end
        info.rec_start, info.gap, info.run = start, start - p0, run
        return { index = index, n_records = math.max(N, 0), rec_start = start, info = info }
    end

    local function record_at(magic, layout, ri)
        if ri >= layout.n_records then return nil end
        local address = magic + layout.rec_start + ri * TU.rec_elem
        local bytes = mem.read(address, TU.rec_elem)
        if not bytes then return nil end
        return address, bytes
    end

    local function analyse_block(magic, layout)
        local lines = {}
        local union, counted = 0, 0
        local target_ri = layout.index[target]
        for e in pairs(entityset) do
            local ri = layout.index[e]
            if ri then
                local _, rec = record_at(magic, layout, ri)
                if rec and plausible_record(rec, 0) then
                    local tu = u32(rec, TU.task_user_off)
                    local kept = keepset[e] and 'keep' or (e == target and 'TARGET' or (is_trooper[e] and 'trooper' or 'replaced'))
                    lines[#lines + 1] = string.format('  %-8s %-34s rec=%-5d behavior=%-5d task_user=0x%X',
                        kept, name_of[e] or hexof(e), ri, u32(rec, 0), tu)
                    if not keepset[e] and (not is_trooper[e] or not guard_active()) then
                        union = bitlib.bor(union, tu); counted = counted + 1
                    end
                end
            end
        end
        table.sort(lines)
        return union, counted, lines, target_ri
    end

    local function patch_task_user_auto()
        state.tu_layout = state.tu_layout or {}
        local override = (TU_MASK ~= 0) and TU_MASK or nil
        local blocks, fixed = 0, 0
        for magic, size in pairs(state.behavior_blocks) do
            local hdr = mem.read(magic, TU.data_off)
            if not hdr or hdr:sub(1, 4) ~= 'LDLD' or u32(hdr, 8) ~= TU_TYPE then
                state.behavior_blocks[magic] = nil
                state.tu_layout[magic] = nil
                state.block_scan_rounds = 0
                state.next_block_scan = 0
                emit(string.format('taskuser_block_lost at=0x%x', magic))
            else
                blocks = blocks + 1
                local L = state.tu_layout[magic]
                if L == nil then
                    local layout, why, info = infer_layout(magic, size)
                    if layout then
                        local union, counted, lines, target_ri = analyse_block(magic, layout)
                        L = { layout = layout, union = union, target_ri = target_ri }
                        emit(string.format('taskuser_layout block=0x%x size=%d index=%d records=%d run=%d gap=%d rec_start=%d candidates=%d',
                            magic, size, layout.info.index_count, layout.n_records, layout.info.run, layout.info.gap,
                            layout.rec_start, layout.info.perfect))
                        emit(string.format('taskuser_auto union=0x%X from %d replaced units target_in_block=%s%s',
                            union, counted, tostring(target_ri ~= nil), override and string.format(' override=0x%X', override) or ''))
                        for _, line in ipairs(lines) do emit(line) end
                    else
                        L = { failed = why }
                        local parts = {}
                        for k, v in pairs(info or {}) do parts[#parts + 1] = k .. '=' .. tostring(v) end
                        table.sort(parts)
                        emit(string.format('taskuser_layout_failed block=0x%x size=%d reason=%s %s',
                            magic, size, tostring(why), table.concat(parts, ' ')))
                    end
                    state.tu_layout[magic] = L
                end
                if L.layout and L.target_ri ~= nil then
                    local mask = override or L.union
                    state.taskuser_mask = mask
                    if mask ~= 0 then
                        local address, rec = record_at(magic, L.layout, L.target_ri)
                        if address and rec and plausible_record(rec, 0) then
                            local cur = u32(rec, TU.task_user_off)
                            if cur ~= mask then
                                local ok, why, rinfo = write_u32_checked(address + TU.task_user_off, mask)
                                if ok then
                                    record_backup('taskuser', address + TU.task_user_off, rec:sub(TU.task_user_off + 1, TU.task_user_off + 4))
                                    fixed = fixed + 1
                                    emit(string.format('taskuser_patched at=0x%x behavior=%d 0x%X -> 0x%X (rec=%d kind=0x%x)',
                                        address, u32(rec, 0), cur, mask, L.target_ri, rinfo and rinfo.kind or 0))
                                elseif not state.taskuser_write_reported then
                                    state.taskuser_write_reported = true
                                    emit(string.format('taskuser_write_rejected at=0x%x reason=%s kind=%s protect=%s',
                                        address + TU.task_user_off, tostring(why),
                                        rinfo and string.format('0x%x', rinfo.kind) or '?',
                                        rinfo and string.format('0x%x', rinfo.protect) or '?'))
                                end
                            end
                        end
                    end
                end
            end
        end
        state.taskuser_fixed = (state.taskuser_fixed or 0) + fixed
        return blocks, fixed
    end

    local function patch_task_user()
        state.taskuser_mask = state.taskuser_mask or TU_MASK
        if not on('task_user') then return 0, 0 end
        if TU.auto then return patch_task_user_auto() end
        return patch_task_user_explicit()
    end

    local function dump_roster(addr, snap, label)
        if not on('dump_rows') or type(writefile) ~= 'function' then return end
        state.dumps = state.dumps + 1
        local lines = {
            '# All Automatons Replaced dump: ' .. label,
            string.format('# base=0x%x rows=%d', addr, #snap.tags),
            '# idx  tag               entity',
        }
        for i = 1, #snap.tags do
            lines[#lines+1] = string.format('%-4d %s %s', i - 1, snap.tags[i], snap.entities[i])
        end
        lines[#lines+1] = '# raw rows (16 u64 each, little-endian)'
        for i = 0, #snap.tags - 1 do
            local f = {}
            for k = 0, 15 do
                f[#f+1] = hexof(snap.raw:sub(i*STRIDE + k*8 + 1, i*STRIDE + k*8 + 8))
            end
            lines[#lines+1] = string.format('raw%-3d %s', i, table.concat(f, ' '))
        end
        writefile(string.format('PickYourBots_roster_%d.txt', state.dumps), table.concat(lines, '\n') .. '\n')
    end

    --========================================================== 发现
    local scan = nil

    -- 一趟扫描 = 固定的区域列表 + 全部探针 + 候选收集。
    -- 预算**跨趟累加**,绝不清零 —— 否则一次扫描会把整个地址空间读好几遍。
    local function begin_scan(regions, next_regions, kind, tag, needles)
        scan = {
            regions = regions, next_regions = next_regions or {},
            idx = 1, off = 0, chunk = 131072, needles = needles or scan_needles(),
            budget = 0, max_budget = profile.scan_budget,
            candidates = {}, kind = kind or 'full',
        }
        state.phase = 'scan_rows'
        emit(string.format('scan_start kind=%s tag=%s primary=%d secondary=%d',
            scan.kind, tag or '-', #regions, #(next_regions or {})))
    end

    -- 全量扫描:名录只可能落在"私有堆"或"模块镜像"里,所以 MEM_MAPPED
    -- (映射进来的游戏数据文件,通常是几百 MB)排在最后 —— 前面找到就完全不用扫它。
    local function split_regions()
        local regions = mem.regions(base, 8000)
        local primary, secondary = {}, {}
        for _, r in ipairs(regions) do
            if r.kind == 0x40000 then secondary[#secondary+1] = r
            else primary[#primary+1] = r end
        end
        return primary, secondary
    end

    -- 名录扫描顺带找"任务组表"的块,省一整趟扫描
    local function roster_needles_with_blocks()
        local out = scan_needles()
        if on('task_user') then
            for _, n in ipairs(taskuser_needles()) do out[#out + 1] = n end
        end
        return out
    end

    local function start_full_scan(tag)
        state.scan_attempts = (state.scan_attempts or 0) + 1
        local primary, secondary = split_regions()
        begin_scan(primary, secondary, 'full', tag, roster_needles_with_blocks())
    end

    -- 专找任务组表:只在"名录已经搞定、但还没找到该表"时才起(飞船上表可能还没加载)
    local function start_blocks_scan(tag)
        local primary, secondary = split_regions()
        begin_scan(primary, secondary, 'blocks', tag, taskuser_needles())
    end

    -- 轻量维护扫描:只扫"上一轮名录/表头的已知地址 ± 窗口"(几 MB),
    -- 用来抓"换图后游戏重新加载的一份副本";连续失败才退回全量。
    local function start_light_scan(windows)
        local regions = {}
        for _, w in ipairs(windows) do
            regions[#regions+1] = { base = w.lo, size = w.hi - w.lo, kind = 0 }
        end
        begin_scan(regions, {}, 'light', 'known-windows')
    end

    -- 候选收集:命中点向上回溯 0..63 行(起点可能落在行中间),
    -- 先做一次 8 字节廉价预筛,再算"从第 0 行开始连续命中多长"。
    local function consider_hit(address, s)
        for r = 0, 63 do
            local cand = address - r * STRIDE
            if cand >= 65536 and cand % 16 == 0 then
                local first = mem.read(cand, 8)
                if first and tagset[first] then
                    local hits = leading_run(cand)
                    -- 诊断遥测:全程见过的最大连续命中数。
                    -- 名录在但阈值/结构变了 → 这个值大;内容真变了 → 这个值小。
                    if hits > (state.best_run or 0) then state.best_run = hits end
                    if hits >= LOW_MIN then
                        local start = normalize_start(cand)
                        local h2 = leading_run(start)
                        if h2 >= LOW_MIN then
                            if h2 > (state.best_run or 0) then state.best_run = h2 end
                            local prev = s.candidates[start]
                            if not prev or h2 > prev then s.candidates[start] = h2 end
                        end
                    end
                end
            end
        end
    end

    -- 候选 -> 名录。阈值分层:只要存在"高置信"(≥ MIN_HITS)的就只收高置信的;
    -- 一个都没有时才收"低置信"(≥ LOW_MIN,通常是更新后名录被插了行/改了顺序)。
    local function register_roster(start, hits, conf)
        local rinfo = mem.region(start)
        local is_image = rinfo and rinfo.kind == 0x1000000 and rinfo.allocation == base
        local snap = snapshot(start, WINDOW)
        state.rosters[start] = {
            hits = hits, is_image = is_image and true or false,
            region_kind = rinfo and rinfo.kind or 0, snapshot = snap,
            entities = snap and snap.entities or {},
        }
        emit(string.format('roster_found base=0x%x hits=%d/%d image=%s rva=%s conf=%s',
            start, hits, WINDOW, tostring(is_image and true or false),
            tostring(start >= base and (start - base) or 'n/a'), conf or 'high'))
        if snap then
            dump_roster(start, snap, is_image and 'game.dll image copy' or 'heap copy')
            -- 名录里出现过的实体纳入模板替换范围。
            -- ⚠ 两个坑:①窗口(48 行)比真实行数长,尾巴可能是全零或别人的数据 ——
            --   只认"标签也是我们认识的"那些行,否则空槽/垃圾会被当成已知实体乱写。
            for i = 1, #snap.tags do
                local tag = raw(snap.tags[i])
                local ent = raw(snap.entities[i])
                if tagset[tag] and not keepset[ent] then entityset[ent] = true end
            end
        end
        return is_image and true or false
    end

    local function accept_rosters(s)
        local best = 0
        for _, h in pairs(s.candidates) do if h > best then best = h end end
        local min = best >= MIN_HITS and MIN_HITS or LOW_MIN
        if best < MIN_HITS then state.low_confidence = true end
        local accepted = 0
        for start, hits in pairs(s.candidates) do
            if hits >= min and not state.rosters[start] then
                register_roster(start, hits, best >= MIN_HITS and 'high' or 'low')
                accepted = accepted + 1
            end
        end
        if accepted > 0 then state.absent_rounds = 0 end
        return accepted
    end

    --========================================================== 快路径:已知 RVA 提示
    -- All-Stalker v0.2.2 的作者在新构建(25327279)里做过只读采集,给了三个 RVA。
    -- ★ 只当**提示**,不当闸门:每一步都过内容校验(连续命中 / 指针自洽),
    --   任何一条不符就当没有,退回全量内容扫描 —— RVA 漂了只是慢一点,不会再整个停摆。

    local function scan_step()
        local s = scan
        if not s then return 'scan_ptr' end
        local rounds = 0
        while rounds < 4 do
            rounds = rounds + 1
            if s.budget > s.max_budget then
                emit('scan_budget_exhausted bytes=' .. s.budget)
                return 'scan_ptr'
            end
            if s.idx > #s.regions then
                -- 这一趟扫完:先把候选收成名录,再决定要不要扫下一趟
                if accept_rosters(s) > 0 then return 'scan_ptr' end
                if #s.next_regions > 0 then
                    emit(string.format('scan_pass_2 mapped=%d', #s.next_regions))
                    s.regions, s.next_regions = s.next_regions, {}
                    s.idx, s.off, s.candidates = 1, 0, {}
                else
                    return 'scan_ptr'
                end
            end
            local region = s.regions[s.idx]
            if region.size > 2147483648 then
                s.idx = s.idx + 1; s.off = 0
            else
                local start = region.base + s.off
                local size = math.min(s.chunk, region.size - s.off)
                if size < 4096 then
                    s.idx = s.idx + 1; s.off = 0
                else
                    local bytes = mem.read(start, size)
                    s.off = s.off + size
                    s.budget = s.budget + size
                    if bytes then
                        for _, needle in ipairs(s.needles) do
                            local from, n = 1, 0
                            while n < 6 do
                                local at = bytes:find(needle.pat, from, true)
                                if not at then break end
                                if needle.kind == 'taskuser' then
                                    check_taskuser_block(start + (at - 1))
                                else
                                    consider_hit(start + (at - 1), s)
                                end
                                from = at + 1
                                n = n + 1
                            end
                        end
                    end
                    return
                end
            end
        end
    end

    --========================================================== director 定位
    -- 候选缓存挂在 director 上,必须认准 director。
    -- ★ 表头对象和 director 是**两块**内存:director+0x660 里存的是"指向表头的指针"。
    --   所以"表头地址 - 槽偏移"推不出 director(推出来的三个都是错的)。
    --   正确做法:搜"谁存着这个表头指针",那个地址减槽偏移才是候选 director,
    --   再用内容判据确认:三个槽都要**像表头**、且至少一个指向我们已找到的名录表头。
    local function pairs_count(t)
        local n = 0
        for _ in pairs(t) do n = n + 1 end
        return n
    end

    local function looks_like_header(address)
        local h = mem.read(address, 0x10)
        if not h then return false end
        if not ptr(h, 0) then return false end
        local n = u32(h, 8)
        return n ~= nil and n >= 8 and n <= 512
    end

    local function is_director(d, need_known)
        local known = 0
        for _, off in ipairs(profile.slot_offsets) do
            local h = ptr(mem.read(d + off, 8), 0)
            if not h or not looks_like_header(h) then return false end
            if state.headers[h] then known = known + 1 end
        end
        -- 快路径(hint)在发现表头**之前**就要用这个判据,此时 state.headers 还是空的;
        -- 那条路由后面的"槽指向的行数组要过内容校验"来兜底,所以这里允许放宽。
        if need_known == false then return true end
        return known >= 1
    end

    -- 可选诊断:director 指针存在 game.dll 镜像里的哪个 RVA(给维护用)。
    -- 必须分块读 —— 单次读取上限 256 KB,整块读必然返回 nil(v1 那个
    -- "locate_director_rva 从来不生效"就是这么来的)。
    local function find_pointer_rva(pat)
        if not scan or not scan.regions then return nil end
        local CH = 262144
        for _, r in ipairs(scan.regions) do
            if r.is_image then
                local off = 0
                while off < r.size and off < profile.image_scan_cap do
                    local want = math.min(CH, r.size - off)
                    if want < 8 then break end
                    local bytes = mem.read(r.base + off, want)
                    if bytes then
                        local at = bytes:find(pat, 1, true)
                        if at then return r.base + off + (at - 1) - base end
                    end
                    off = off + want - 7          -- 8 字节重叠:模式可能跨块
                end
            end
        end
        return nil
    end

    local function try_hints()
        local hp = profile.hints
        if not hp then return false end
        -- 失败只报一次:这是"提示不适用",不是错误;但下次排查需要知道卡在哪一步
        local function bail(why)
            if not state.hint_fail then
                state.hint_fail = why
                emit('hint_path_skip reason=' .. why)
            end
            return false
        end
        -- ① director 全局变量(此时表头还没发现,只查"三槽都像表头";
        --    真伪由 ③ 的"槽指向的行数组过内容校验"兜底)
        local g = mem.read(base + hp.director_global_rva, 8)
        if not g then return bail('director_global_unreadable') end
        local d = ptr(g, 0)
        if not d then return bail('director_null_on_ship') end
        if not is_director(d, false) then return bail('director_content_mismatch') end
        -- ② 静态名录(game.dll 镜像里那份,45 行)。
        --    ★ 提示地址可能落在行数组中间(插行/对齐变了),注册前必须归一到数组真起点,
        --      否则会少改最前面几行(和内容扫描里的 normalize_start 同一个道理)。
        local src_rows = nil
        if hp.source_rows_rva then
            src_rows = normalize_start(base + hp.source_rows_rva)
            if leading_run(src_rows) < MIN_HITS then return bail('static_rows_mismatch') end
        end
        -- ③ 表头(director+0x660 槽指向的堆表头)与它指向的堆名录
        local hh = ptr(mem.read(d + 0x660, 8), 0)
        if not hh then return bail('header_slot_unreadable') end
        local hrows = ptr(mem.read(hh, 8), 0)
        if not hrows then return bail('heap_rows_unreadable') end
        hrows = normalize_start(hrows)
        if leading_run(hrows) < MIN_HITS then return bail('heap_rows_mismatch') end
        local hcount = u32(mem.read(hh, 0x10), 8)
        if not hcount or hcount < 8 or hcount > 512 then return bail('header_count_mismatch') end

        state.director_addr = d
        if src_rows and not state.rosters[src_rows] then
            register_roster(src_rows, leading_run(src_rows), 'hint')
        end
        if not state.rosters[hrows] then
            register_roster(hrows, leading_run(hrows), 'hint')
        end
        if not state.headers[hh] then
            state.headers[hh] = { rows = hrows, count = hcount }
            emit(string.format('header_found at=0x%x rows=0x%x count=%d (hint)',
                hh, hrows, hcount))
        end
        state.absent_rounds = 0
        emit(string.format('hint_path_ok director=0x%x static_rva=%s heap_rows=0x%x',
            d, tostring(hp.source_rows_rva), hrows))
        return true
    end

    local function check_header(where, rows_addr)
        local h = mem.read(where, 0xb0)
        if not h then return end
        if ptr(h, 0) ~= rows_addr then return end
        local count = u32(h, 8)
        if not count or count < 8 or count > 512 then return end
        if not state.headers[where] then
            state.headers[where] = { rows = rows_addr, count = count }
            local l = state.header_of[rows_addr] or {}
            l[#l+1] = where
            state.header_of[rows_addr] = l
            emit(string.format('header_found at=0x%x rows=0x%x count=%d variant_count=%s',
                where, rows_addr, count, tostring(u32(h, 0x18))))
        end
    end

    -- ★ director 不能靠"表头地址减去槽偏移"猜 —— 表头对象和 director 是**两块**内存,
    --   director+0x660 里存的是"指向表头的指针",不是表头本身。
    --   所以要么在内存里搜到"谁存着表头指针",再减去槽偏移;要么别动候选缓存那一层。
    local function check_director(where)
        for _, off in ipairs(profile.slot_offsets) do
            local d = where - off
            if d >= 65536 and is_director(d) then
                if not state.director_addr or d < state.director_addr then
                    state.director_addr = d
                    emit(string.format('director_located director=0x%x slot=0x%x off=0x%x',
                        d, where, off))
                end
            end
        end
    end

    -- 通用的"在某块内存里找指针"扫描:对每个命中调用 handler(hit_addr, target_addr)。
    local function start_ptr_scan(targets, handler, phase)
        if #targets == 0 then
            state.phase = phase.next or 'maintain'
            return false
        end
        scan = {
            regions = scan and scan.regions or (mem.regions(base, 8000)),
            idx = 1, off = 0, chunk = 131072,
            targets = targets, handler = handler, ti = 1, budget = 0, max_budget = 805306368,
        }
        state.phase = phase.name
        emit(string.format('ptr_scan_start what=%s targets=%d', phase.what, #targets))
        return true
    end

    local function scan_ptr()
        local s = scan
        if not s or not s.targets then return 'apply' end
        if s.budget > s.max_budget then emit('ptr_scan_budget_exhausted'); return 'apply' end
        local rounds = 0
        while rounds < 4 do
            rounds = rounds + 1
            if s.ti > #s.targets then return 'apply' end
            if s.idx > #s.regions then
                s.ti = s.ti + 1; s.idx = 1; s.off = 0
            else
                local region = s.regions[s.idx]
                if region.size > 2147483648 then
                    s.idx = s.idx + 1; s.off = 0
                else
                    local start = region.base + s.off
                    local size = math.min(s.chunk, region.size - s.off)
                    if size < 4096 then
                        s.idx = s.idx + 1; s.off = 0
                    else
                        local bytes = mem.read(start, size)
                        s.off = s.off + size
                        s.budget = s.budget + size
                        if bytes then
                            local t = s.targets[s.ti]
                            local from, hits = 1, 0
                            while hits < 16 do
                                local at = bytes:find(t.pat, from, true)
                                if not at then break end
                                s.handler(start + (at - 1), t.addr)
                                from = at + 1
                                hits = hits + 1
                            end
                        end
                        return
                    end
                end
            end
        end
    end

    --========================================================== 应用 / 维护
    local function count(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end

    local function apply_all()
        state.guard_rows_kept_pass = 0
        guard_tags = collect_guard_tags(state.headers)
        do
            local n, parts = 0, {}
            for t, c in pairs(guard_tags) do n = n + 1; parts[#parts + 1] = hexof(t) .. '(' .. tag_rows_desc(t) .. ')' end
            table.sort(parts)
            local key = table.concat(parts, ';')
            if state.guard_key ~= key then
                state.guard_key = key
                emit(string.format('guard_tags count=%d %s', n, key))
            end
        end
        local rosters, rows_patched, image_rows = 0, 0, 0
        for addr, info in pairs(state.rosters) do
            if on('rows') and (info.is_image == false or on('source_rows')) then
                local seen, patched = patch_rows(addr, info.is_image)
                rows_patched = rows_patched + (patched or 0)
                rosters = rosters + 1
                if info.is_image then image_rows = image_rows + (patched or 0) end
            end
        end
        state.guard_rows_kept = state.guard_rows_kept_pass
        local groups, tpl = 0, 0
        local variants = 0
        for haddr in pairs(state.headers) do
            if on('templates') then
                local g, e = patch_templates(haddr)
                groups = groups + (g or 0)
                tpl = tpl + (e or 0)
            end
            if patch_variant(haddr) then variants = variants + 1 end
            local pt = add_patrol_troopers(haddr)
            if pt > 0 then
                state.patrol_added = (state.patrol_added or 0) + pt
                emit(string.format('patrol_troopers_added records=%d total=%d', pt, state.patrol_added))
            end
            local rt = retag_non_guard(haddr)
            if rt > 0 then
                state.retagged = (state.retagged or 0) + rt
                emit(string.format('guard_retagged entries=%d total=%d', rt, state.retagged))
            end
            local fr = fill_drop_records(haddr)
            if fr > 0 then
                state.filled = (state.filled or 0) + fr
                emit(string.format('drop_fill_raised records=%d total=%d', fr, state.filled))
            end
        end
        local cached = 0
        if state.director_addr then
            local _, c = patch_candidates(state.director_addr)
            cached = c or 0
        end
        local tu_blocks, tu_fixed = patch_task_user()
        local total = rows_patched + tpl + cached + tu_fixed
        if total > 0 then
            flush_backup()
            emit(string.format('applied rosters=%d rows_patched=%d image_rows=%d groups=%d templates_patched=%d headers=%d variant=%d cached=%d taskuser_blocks=%d taskuser_fixed=%d',
                rosters, rows_patched, image_rows, groups, tpl, count(state.headers), variants, cached,
                tu_blocks, tu_fixed))
        end
        state.patched = (state.patched or 0) + total
        return total
    end

    -- 轻量维护窗口:已知名录/表头地址 ± profile.light_window,合并重叠区间
    local function build_light_windows()
        local raw = {}
        local function add(addr)
            local lo = addr - profile.light_window
            if lo < 65536 then lo = 65536 end
            raw[#raw+1] = { lo = lo, hi = addr + profile.light_window }
        end
        for addr in pairs(state.rosters) do add(addr) end
        for addr in pairs(state.headers) do add(addr) end
        if #raw == 0 then return nil end
        table.sort(raw, function(a, b) return a.lo < b.lo end)
        local out = {}
        for _, w in ipairs(raw) do
            local last = out[#out]
            if last and w.lo <= last.hi then
                if w.hi > last.hi then last.hi = w.hi end
            else
                out[#out+1] = { lo = w.lo, hi = w.hi }
            end
        end
        return out
    end

    -- 名录不在内存里(飞船里本来就没有,进任务才有)→ 低频重试。
    -- ★ 绝不"一边找不到一边一直整轮扫":那是最典型的帧率杀手。
    local function enter_absent()
        state.absent_rounds = (state.absent_rounds or 0) + 1
        local sched = profile.rescan_backoff_s
        local wait = sched[math.min(#sched, state.absent_rounds)]
        state.phase = 'roster_absent'
        state.next_rescan = os.clock() + wait
        emit(string.format('roster_absent round=%d next_rescan_in=%ds', state.absent_rounds, wait))
    end

    local function maintain()
        local live = 0
        for addr in pairs(state.rosters) do
            if leading_run(addr) >= math.min(16, MIN_HITS) then live = live + 1
            else
                state.rosters[addr] = nil
                emit(string.format('roster_lost base=0x%x', addr))
            end
        end
        for haddr in pairs(state.headers) do
            local h = mem.read(haddr, 0x10)
            if not h or not ptr(h, 0) then
                state.headers[haddr] = nil
                emit(string.format('header_lost at=0x%x', haddr))
            end
        end
        if live == 0 then
            state.empty_rounds = (state.empty_rounds or 0) + 1
            if state.empty_rounds >= 3 then
                state.empty_rounds = 0
                local windows = build_light_windows()
                state.rosters, state.headers, state.header_of = {}, {}, {}
                state.director_addr = nil
                if windows then
                    state.light_rounds = (state.light_rounds or 0) + 1
                    if state.light_rounds <= profile.max_light_rounds then
                        start_light_scan(windows)
                        return 'rescanning_for_roster_light'
                    end
                end
                start_full_scan('after-loss')
                return 'rescanning_for_roster'
            end
            return 'waiting_for_roster'
        end
        state.empty_rounds = 0
        state.light_rounds = 0
        local n = apply_all()
        return n > 0 and 'patched_automatons_replaced' or 'active_automatons_replaced'
    end

    --========================================================== reload support
    -- Put back what this engine wrote in game.dll's image (rows and template entries), but only where the
    -- bytes still are exactly what we wrote. Heap data (candidate cache, task table) is never touched:
    -- it disappears with the mission, and freed memory must not be written.
    function state.restore_all()
        local list = state.restore_list or {}
        local restored, skipped = 0, 0
        local why = { not_image = 0, changed = 0, write_failed = 0 }
        for i = #list, 1, -1 do
            local e = list[i]
            local r = mem.region(e.addr)
            if r and r.kind == 0x1000000 then
                local cur = mem.read(e.addr, 8)
                if cur ~= e.written then
                    skipped = skipped + 1; why.changed = why.changed + 1
                elseif mem.writable(e.addr, 8) and mem.write(e.addr, e.original) then
                    restored = restored + 1
                else
                    skipped = skipped + 1; why.write_failed = why.write_failed + 1
                end
            else
                skipped = skipped + 1; why.not_image = why.not_image + 1
            end
        end
        state.restore_list = {}
        return restored, skipped, string.format('not_image=%d changed=%d write_failed=%d', why.not_image, why.changed, why.write_failed)
    end

    -- true while a mission is loaded (the director pointer is not null)
    function state.in_mission()
        local hp = profile.hints
        if not base or not hp or not hp.director_global_rva then return false end
        local g = mem.read(base + hp.director_global_rva, 8)
        return g ~= nil and ptr(g, 0) ~= nil
    end

    --========================================================== 对外轮询
    local last_maintain = 0

    function state.poll()
        -- ★ 每 2 秒试一次"提示路径"(几个读取,全部过内容校验):命中就直接进维护,
        --   不再等整轮扫描跑完、也不等退避到点 —— 这正是"第一次进任务那局不生效"的根因。
        --   放在最前面是为了**任何阶段都生效**(包括正在整轮扫描时)。
        local now0 = os.clock()
        if count(state.rosters) == 0 and now0 >= (state.next_hint_try or 0) then
            state.next_hint_try = now0 + 2
            if try_hints() then
                state.absent_rounds = 0
                state.phase = 'maintain'
                last_maintain = now0
                return maintain()
            end
        end
        local phase = state.phase
        if phase == 'init' then
            -- 先试已知 RVA 提示(内容校验过才算数),成了就完全不用扫
            if try_hints() then
                state.phase = 'maintain'
                last_maintain = os.clock()
                return maintain()
            end
            start_full_scan('startup')
            return 'scanning_for_roster'
        end
        if phase == 'scan_rows' then
            local r = scan_step()
            if r == 'scan_ptr' then
                if scan and scan.kind == 'blocks' then
                    -- 任务组表这一趟扫完(找到就登记,没找到稍后再试)
                    state.next_block_scan = os.clock() + 30
                    state.phase = 'maintain'
                    last_maintain = os.clock()
                    return maintain()
                end
                if count(state.rosters) == 0 then
                    enter_absent()
                    return 'roster_not_in_memory'
                end
                local targets = {}
                for addr in pairs(state.rosters) do
                    targets[#targets+1] = { addr = addr, pat = pack(addr) }
                end
                start_ptr_scan(targets, check_header,
                    { name = 'scan_ptr', what = 'header', next = 'maintain' })
                if state.phase == 'maintain' then return 'roster_not_found' end
            end
            return 'scanning_for_roster'
        end
        if phase == 'scan_ptr' then
            if scan_ptr() == 'apply' then
                -- 表头找齐了。候选缓存那一路还需要 director,而 director 只能靠
                -- "谁存着表头指针"再减槽偏移推出来 —— 所以再来一趟指针扫描。
                local targets = {}
                for h in pairs(state.headers) do targets[#targets+1] = { addr = h, pat = pack(h) } end
                if on('candidates') and #targets > 0 then
                    start_ptr_scan(targets, check_director,
                        { name = 'scan_director', what = 'director', next = 'maintain' })
                    if state.phase == 'scan_director' then return 'scanning_for_director' end
                end
                state.phase = 'maintain'
                last_maintain = os.clock()
                return maintain()
            end
            return 'scanning_for_header'
        end
        if phase == 'scan_director' then
            if scan_ptr() == 'apply' then
                if not state.director_addr then
                    emit('director_not_located headers=' .. count(state.headers))
                else
                    local ok, rva = pcall(find_pointer_rva, pack(state.director_addr))
                    if ok and rva then
                        state.director_rva = rva
                        emit('director_pointer_rva=' .. rva)
                    end
                end
                state.phase = 'maintain'
                last_maintain = os.clock()
                return maintain()
            end
            return 'scanning_for_director'
        end
        if phase == 'roster_absent' then
            if os.clock() < (state.next_rescan or 0) then return 'roster_not_in_memory' end
            -- 每次重扫前先试提示路径(几微秒),成了就免扫
            if try_hints() then
                state.phase = 'maintain'
                last_maintain = os.clock()
                return maintain()
            end
            start_full_scan('retry')
            return 'scanning_for_roster'
        end
        -- maintain:别每帧都重扫,最多每 2 秒一次
        local now = os.clock()
        if now - last_maintain < 2 then return state.status or 'active_automatons_replaced' end
        last_maintain = now
        -- 还没找到"任务组表"就再起一趟专扫(最多几轮;飞船上表可能还没加载)
        -- (名录本身的"提示路径"重试在 poll 最前面,每 2 秒一次)
        if on('task_user') and count(state.behavior_blocks) == 0
            and (state.block_scan_rounds or 0) < 6 and now >= (state.next_block_scan or 0) then
            state.block_scan_rounds = (state.block_scan_rounds or 0) + 1
            start_blocks_scan('taskuser#' .. state.block_scan_rounds)
            return 'scanning_for_taskuser'
        end
        return maintain()
    end

    return state
end

end)()

local function build_profile()
local profile = (function()
-- Spawn profile: rows = (spawn tag, entity) pairs captured from a live
-- Automaton mission; the tag is the content key, the entity is only a reference.
return {
    version = '1.8.1-no-preview',
    hulk_calls = true,
    target_le = "ea8f4306d637053e",
    target_name = 'cha_lieutenant_assault',
    -- Default: Hulk Scorchers and Bruisers. targets=a,b in the config replaces the list; target=a (one name)
    -- replaces it with that single unit.
    targets = {'cha_lieutenant_assault', 'cha_lieutenant_suppressor'},
    squad_container_le = "d8f320f5e82b25f5",
    keep_entities_le = {},
    -- left alone by default: bot drop spawners (structures) and gunships (air units)
    keep_names_default = {'cyborg_spawner', 'cyborg_spawner_jammer', 'cyborg_siege_engine', 'cyborg_gunship'},
    names = {
        cha_berserker = "a1f377f18a8da6a6",
        cha_conscript_commander = "92bc6e2cd8af1aa7",
        cha_conscript_flamer = "bab295d5d87aa882",
        cha_conscript_jump_melee = "0f765ee410976e85",
        cha_conscript_melee = "35d0a607a8c4cbd8",
        cha_conscript_scout = "d49b8cecb204cf30",
        cha_conscript_scout_walker_rider = "432c655d033799fb",
        cha_conscript_tier_1 = "b61c354231621940",
        cha_conscript_tier_2 = "c14e110b035fba64",
        cha_conscript_tier_3 = "f356f87d76ba0200",
        cha_cyborg_elite = "0e6563d7fe27889d",
        cha_cyborg_elite_female = "6c39231ae50bfe09",
        cha_cyborg_elite_rusher = "9926a3ed3b7f6a74",
        cha_cyborg_elite_rusher_female = "3a9c006633bab1cb",
        cha_lieutenant_artillery = "0ed07f6f1fee661e",
        cha_lieutenant_assault = "ea8f4306d637053e",
        cha_lieutenant_suppressor = "f75864a1ce887913",
        cha_soldier = "44703d8525e563ae",
        cha_soldier_jumppack = "266e3aaa2f3b74be",
        cha_soldier_mg = "48070ff6fb3524b9",
        cha_soldier_mg_assassinate = "ebd4d5861aa8b5f8",
        cha_soldier_rpg = "6fd3a9c30cb04796",
        cha_soldier_rpg_assassinate = "9a779386ad0b6df6",
        cha_soldier_shotgun_ivory_legion = "739532f1773135e0",
        cyborg_assault_walker = "c2175a24930257ef",
        cyborg_gunship = "a1a6ffc166b72e28",
        cyborg_siege_engine = "e7b746fb022724bc",
        cyborg_spawner = "e336280d128d7ed3",
        cyborg_spawner_jammer = "7a223f33e2def230",
        cyborg_tank_autocannons = "9c77a39efd9f44c6",
        cyborg_tank_heavycannon = "67bd8a7b9d91d853",
        cyborg_tank_rocketlauncher = "884542b7073ddf63",
        cyborg_walker_scout = "077186aa321613f8",
        cyborg_walker_scout_reinforced = "35eefc17edee7690"
    },
    -- Task mask fix: the layout of the BehaviorComponentData table is inferred from the live data and
    -- the target gets the union of the task bits of the units it replaces (basic troopers excluded,
    -- they keep their own duties, e.g. manning emplaced guns). task_user=false switches it off;
    -- task_user_mask=0x... overrides the computed mask.
    task_user = {
        auto = true,          -- layout and mask are read from the live table (no offline constants)
        mask = 0,             -- 0 = automatic: union of the replaced units' own task bits
        expected_original = 0,
        type_name = 'BehaviorComponentData',
        data_off = 24, index_off = 0, index_elem = 16,
        rec_off = 0, rec_elem = 12, task_user_off = 8,
        behavior_id_max = 100000,
        max_index_slots = 20000, max_records = 65536,
        search_span = 1024,
        search_bytes = 16384,
    },
    -- Guard posts keep the vanilla trooper rows: the tags used by the guard template group(s) are
    -- left unreplaced, and every OTHER template group that references those tags is pointed at
    -- the retag row instead (a single row that is replaced by the target like all the others).
    -- group 64 is the group whose records ask for 'any number of light units' (count 999).
    guard = { enabled = true, groups = {64}, retag = '9c73d530',
              -- 'target': troopers stay vanilla, every other guard unit becomes the target (needs the
              -- task mask fix); 'trooper': every other guard unit becomes a basic trooper instead
              others = 'target',
              -- optional: what the redirected (drop) rows become, in turn, and their spawn cost.
              -- Empty = the retag rows become the target like every other row.
              retag_units = {'cha_lieutenant_assault', 'cha_lieutenant_suppressor'}, retag_cost = 10,
              -- what the guard rows become (assigned to the rows in turn)
              units = {'cha_conscript_tier_1', 'cha_conscript_tier_2', 'cha_conscript_tier_3', 'cha_conscript_melee'} },
    -- rows that are already basic troopers are never touched (light class conscripts)
    trooper_names = {'cha_conscript_tier_1', 'cha_conscript_tier_2', 'cha_conscript_tier_3', 'cha_conscript_melee',
                     'cha_conscript_jump_melee', 'cha_conscript_flamer', 'cha_conscript_scout', 'cha_conscript_commander'},
    trooper_le = {'7b45f5399b31edb4', '16ae53284f10122a'},
    -- every Automaton unit name known to the community name list (little endian hash -> name),
    -- only used to label the variant table dump
    -- every known Automaton unit name -> little endian hash (used by targets=, drop_units=, keep= ...;
    -- roster units keep their roster hash, duplicates use the cha_family/cha_name path). 16 hex
    -- characters can also be given instead of a name.
    units = {
        ["cha_berserker"] = "a1f377f18a8da6a6",
        ["cha_berserker_iron_fleet"] = "cb2969cfda07e154",
        ["cha_berserker_ivory_legion"] = "ad21c940c2c0dbb5",
        ["cha_berserker_jumppack"] = "a46bb056682f79d5",
        ["cha_conscript"] = "7be528df6b05b3b2",
        ["cha_conscript_albedo"] = "5bed5f63d9b6f132",
        ["cha_conscript_base"] = "b3f668f80453ce7e",
        ["cha_conscript_commander"] = "92bc6e2cd8af1aa7",
        ["cha_conscript_commander_jump"] = "cde47ba160e15c21",
        ["cha_conscript_elite"] = "8138cbbacdca487b",
        ["cha_conscript_flamer"] = "bab295d5d87aa882",
        ["cha_conscript_iron_fleet"] = "62cd99d43b302198",
        ["cha_conscript_ivory_legion"] = "20ede6002f78579f",
        ["cha_conscript_ivory_legion_tier_2"] = "4ad71856cad283e6",
        ["cha_conscript_jump"] = "a58737163a9b0faf",
        ["cha_conscript_jump_melee"] = "0f765ee410976e85",
        ["cha_conscript_melee"] = "35d0a607a8c4cbd8",
        ["cha_conscript_mra"] = "f7db15237fe24cca",
        ["cha_conscript_normal"] = "4153293c0d7a7f5e",
        ["cha_conscript_scout"] = "d49b8cecb204cf30",
        ["cha_conscript_scout_walker_rider"] = "432c655d033799fb",
        ["cha_conscript_shotgun"] = "c0107eaa5c807d25",
        ["cha_conscript_tier_1"] = "b61c354231621940",
        ["cha_conscript_tier_2"] = "c14e110b035fba64",
        ["cha_conscript_tier_3"] = "f356f87d76ba0200",
        ["cha_cyborg_elite"] = "0e6563d7fe27889d",
        ["cha_cyborg_elite_female"] = "6c39231ae50bfe09",
        ["cha_cyborg_elite_rusher"] = "9926a3ed3b7f6a74",
        ["cha_cyborg_elite_rusher_female"] = "3a9c006633bab1cb",
        ["cha_elite_female"] = "89ae4d551c12449f",
        ["cha_illusionist"] = "f10e943cad4733b7",
        ["cha_lieutenant"] = "063a216b6cc06b84",
        ["cha_lieutenant_artillery"] = "0ed07f6f1fee661e",
        ["cha_lieutenant_assault"] = "ea8f4306d637053e",
        ["cha_lieutenant_base"] = "e19cb4ebc914ba96",
        ["cha_lieutenant_ivory_legion"] = "92b6d8f5ad2eab6d",
        ["cha_lieutenant_ivory_legion_assault"] = "dcd20521d3bd9718",
        ["cha_lieutenant_suppressor"] = "f75864a1ce887913",
        ["cha_lieutentant"] = "dd3bad5c6b3c0a0d",
        ["cha_pathfinder"] = "e3127bf68ce9a5a6",
        ["cha_soldier"] = "44703d8525e563ae",
        ["cha_soldier_cfd"] = "87d841c24140266e",
        ["cha_soldier_heavy_weapon"] = "cfc7c003bd959c3d",
        ["cha_soldier_iron_fleet"] = "2d205a49bbd226c6",
        ["cha_soldier_ivory_legion"] = "9dcd46c3ead0ee57",
        ["cha_soldier_jumppack"] = "266e3aaa2f3b74be",
        ["cha_soldier_machinegun"] = "f7b944e8cd3ee7cc",
        ["cha_soldier_mg"] = "48070ff6fb3524b9",
        ["cha_soldier_mg_assassinate"] = "ebd4d5861aa8b5f8",
        ["cha_soldier_mg_ivory_legion"] = "419236116cb8b258",
        ["cha_soldier_rocket"] = "6fae403c323971db",
        ["cha_soldier_rpg"] = "6fd3a9c30cb04796",
        ["cha_soldier_rpg_assassinate"] = "9a779386ad0b6df6",
        ["cha_soldier_rpg_ivory_legion"] = "a4824aa5b0ccbcc9",
        ["cha_soldier_ship"] = "0e96af9cc56592cd",
        ["cha_soldier_shotgun_ivory_legion"] = "739532f1773135e0",
        ["cyborg_assault_walker"] = "c2175a24930257ef",
        ["cyborg_big_walker_skeleton"] = "d859defa09d5666f",
        ["cyborg_dropship"] = "25a0fa767e0790db",
        ["cyborg_gunship"] = "a1a6ffc166b72e28",
        ["cyborg_siege_engine"] = "e7b746fb022724bc",
        ["cyborg_siege_engine_sarcophagus"] = "eee1b84e3c3cdcab",
        ["cyborg_siege_engine_sarcophagus_left_door"] = "dbd5c0c3494c058c",
        ["cyborg_siege_engine_sarcophagus_right_door"] = "1dee2cd40a118811",
        ["cyborg_spawner"] = "e336280d128d7ed3",
        ["cyborg_spawner_jammer"] = "7a223f33e2def230",
        ["cyborg_tank"] = "dc4c547a24f8bc00",
        ["cyborg_tank_autocannons"] = "9c77a39efd9f44c6",
        ["cyborg_tank_base"] = "8d4d062f4de7ba31",
        ["cyborg_tank_heavycannon"] = "67bd8a7b9d91d853",
        ["cyborg_tank_rocketlauncher"] = "884542b7073ddf63",
        ["cyborg_tank_turret_base"] = "c04f2132ac0c58b8",
        ["cyborg_trim_mra"] = "0b79b665106d256e",
        ["cyborg_trim_normal"] = "8846d311e7f55e76",
        ["cyborg_turret_base"] = "cad879042a2edbab",
        ["cyborg_walker_scout"] = "077186aa321613f8"
    },
    extra_names = {
        ["a1f377f18a8da6a6"] = "cha_berserker",
        ["cb2969cfda07e154"] = "cha_berserker_iron_fleet",
        ["ad21c940c2c0dbb5"] = "cha_berserker_ivory_legion",
        ["a46bb056682f79d5"] = "cha_berserker_jumppack",
        ["7be528df6b05b3b2"] = "cha_conscript",
        ["5bed5f63d9b6f132"] = "cha_conscript_albedo",
        ["b3f668f80453ce7e"] = "cha_conscript_base",
        ["92bc6e2cd8af1aa7"] = "cha_conscript_commander",
        ["cde47ba160e15c21"] = "cha_conscript_commander_jump",
        ["8138cbbacdca487b"] = "cha_conscript_elite",
        ["bab295d5d87aa882"] = "cha_conscript_flamer",
        ["62cd99d43b302198"] = "cha_conscript_iron_fleet",
        ["20ede6002f78579f"] = "cha_conscript_ivory_legion",
        ["4ad71856cad283e6"] = "cha_conscript_ivory_legion_tier_2",
        ["a58737163a9b0faf"] = "cha_conscript_jump",
        ["0f765ee410976e85"] = "cha_conscript_jump_melee",
        ["35d0a607a8c4cbd8"] = "cha_conscript_melee",
        ["f7db15237fe24cca"] = "cha_conscript_mra",
        ["4153293c0d7a7f5e"] = "cha_conscript_normal",
        ["d49b8cecb204cf30"] = "cha_conscript_scout",
        ["432c655d033799fb"] = "cha_conscript_scout_walker_rider",
        ["c0107eaa5c807d25"] = "cha_conscript_shotgun",
        ["b61c354231621940"] = "cha_conscript_tier_1",
        ["c14e110b035fba64"] = "cha_conscript_tier_2",
        ["b0bb13eca489a40c"] = "cha_conscript_tier_2",
        ["f356f87d76ba0200"] = "cha_conscript_tier_3",
        ["0e6563d7fe27889d"] = "cha_cyborg_elite",
        ["6c39231ae50bfe09"] = "cha_cyborg_elite_female",
        ["9926a3ed3b7f6a74"] = "cha_cyborg_elite_rusher",
        ["3a9c006633bab1cb"] = "cha_cyborg_elite_rusher_female",
        ["89ae4d551c12449f"] = "cha_elite_female",
        ["f10e943cad4733b7"] = "cha_illusionist",
        ["063a216b6cc06b84"] = "cha_lieutenant",
        ["0ed07f6f1fee661e"] = "cha_lieutenant_artillery",
        ["ea8f4306d637053e"] = "cha_lieutenant_assault",
        ["62c7ee09b09364b1"] = "cha_lieutenant_assault",
        ["b0f628c9ef056559"] = "cha_lieutenant_assault",
        ["e19cb4ebc914ba96"] = "cha_lieutenant_base",
        ["92b6d8f5ad2eab6d"] = "cha_lieutenant_ivory_legion",
        ["dcd20521d3bd9718"] = "cha_lieutenant_ivory_legion_assault",
        ["f75864a1ce887913"] = "cha_lieutenant_suppressor",
        ["dd3bad5c6b3c0a0d"] = "cha_lieutentant",
        ["e3127bf68ce9a5a6"] = "cha_pathfinder",
        ["44703d8525e563ae"] = "cha_soldier",
        ["87d841c24140266e"] = "cha_soldier_cfd",
        ["cfc7c003bd959c3d"] = "cha_soldier_heavy_weapon",
        ["1e4acf4ac3f2a773"] = "cha_soldier_heavy_weapon",
        ["2d205a49bbd226c6"] = "cha_soldier_iron_fleet",
        ["9dcd46c3ead0ee57"] = "cha_soldier_ivory_legion",
        ["266e3aaa2f3b74be"] = "cha_soldier_jumppack",
        ["f7b944e8cd3ee7cc"] = "cha_soldier_machinegun",
        ["2f51676563ba342b"] = "cha_soldier_machinegun",
        ["48070ff6fb3524b9"] = "cha_soldier_mg",
        ["ebd4d5861aa8b5f8"] = "cha_soldier_mg_assassinate",
        ["419236116cb8b258"] = "cha_soldier_mg_ivory_legion",
        ["6fae403c323971db"] = "cha_soldier_rocket",
        ["7042ac83ec424109"] = "cha_soldier_rocket",
        ["6fd3a9c30cb04796"] = "cha_soldier_rpg",
        ["9a779386ad0b6df6"] = "cha_soldier_rpg_assassinate",
        ["a4824aa5b0ccbcc9"] = "cha_soldier_rpg_ivory_legion",
        ["0e96af9cc56592cd"] = "cha_soldier_ship",
        ["44d30351e129abe7"] = "cha_soldier_ship",
        ["739532f1773135e0"] = "cha_soldier_shotgun_ivory_legion",
        ["c2175a24930257ef"] = "cyborg_assault_walker",
        ["d859defa09d5666f"] = "cyborg_big_walker_skeleton",
        ["25a0fa767e0790db"] = "cyborg_dropship",
        ["a1a6ffc166b72e28"] = "cyborg_gunship",
        ["e7b746fb022724bc"] = "cyborg_siege_engine",
        ["eee1b84e3c3cdcab"] = "cyborg_siege_engine_sarcophagus",
        ["dbd5c0c3494c058c"] = "cyborg_siege_engine_sarcophagus_left_door",
        ["1dee2cd40a118811"] = "cyborg_siege_engine_sarcophagus_right_door",
        ["e336280d128d7ed3"] = "cyborg_spawner",
        ["7a223f33e2def230"] = "cyborg_spawner_jammer",
        ["dc4c547a24f8bc00"] = "cyborg_tank",
        ["9c77a39efd9f44c6"] = "cyborg_tank_autocannons",
        ["8d4d062f4de7ba31"] = "cyborg_tank_base",
        ["67bd8a7b9d91d853"] = "cyborg_tank_heavycannon",
        ["884542b7073ddf63"] = "cyborg_tank_rocketlauncher",
        ["c04f2132ac0c58b8"] = "cyborg_tank_turret_base",
        ["0b79b665106d256e"] = "cyborg_trim_mra",
        ["8846d311e7f55e76"] = "cyborg_trim_normal",
        ["cad879042a2edbab"] = "cyborg_turret_base",
        ["077186aa321613f8"] = "cyborg_walker_scout"
    },
    -- Troopers added to every record of the patrol template group(s) so that patrols can call bot drops:
    -- counts = {2, 3} adds an entry of that many units of tag `tag` to each record in turn (empty = off).
    -- Group 80 has the smallest squads (about 3 units per record) which fits patrols; the groups with
    -- about 7 units per record (32) are the dropships. tag 8ec043be = the three plain conscript rows.
    patrol = { groups = {32, 112}, counts = {2, 3}, tag = '8ec043be' },
    -- Points of interest and sub objectives: their guards are picked from the roster rows by tag and the
    -- template group behind them is not known, so instead of adding units, every Nth row of the
    -- fortress and outpost rows becomes a basic trooper (poi_every = 0 is off, 4 = one row in four).
    poi = { every = 0, phase = 1 },
    -- Dropship loads: every record of these template groups is raised to at least `fill` units (the extra
    -- units go to the drop row entry, i.e. the Hulks). 0 = off. Group 80 holds the smaller ship loads.
    drop_fill = { groups = {80}, fill = 6 },
    row_stride = 128,
    row_window = 64,
    min_tag_hits = 30,
    min_tag_hits_low = 8,
    scan_budget = 1610612736,
    image_scan_cap = 67108864,
    -- fast path only; the director global is the same one HD2Runtime and Enemy Spawn Multiplier use.
    -- No static roster address for Automatons: the heap roster is patched, content scan is the fallback.
    hints = {
        director_global_rva = 53636368,   -- 0x3326D10
    },
    groups = {{32, 39}, {48, 1}, {64, 27}, {80, 50}, {96, 6}, {112, 8}, {128, 1}, {144, 1}},
    slot_offsets = {0x660, 0x668, 0x670},
    candidate_context = 0x3A538,
    candidate_counts  = 0x17344,
    candidate_stride  = 0xD8,
    pools = {{0, 96}, {20736, 32}, {27648, 32}, {34560, 8}, {36288, 64}, {50112, 32}, {57024, 8}, {58752, 168}},
    max_light_rounds = 2,
    light_window = 49152,
    rescan_backoff_s = {10, 15, 20, 30, 60, 120},
    entities_le = {"077186aa321613f8", "0e6563d7fe27889d", "0ed07f6f1fee661e", "0f765ee410976e85", "16ae53284f10122a", "266e3aaa2f3b74be", "35d0a607a8c4cbd8", "35eefc17edee7690", "3a9c006633bab1cb", "432c655d033799fb", "44703d8525e563ae", "48070ff6fb3524b9", "67bd8a7b9d91d853", "6c39231ae50bfe09", "6fd3a9c30cb04796", "739532f1773135e0", "7a223f33e2def230", "7b45f5399b31edb4", "884542b7073ddf63", "92bc6e2cd8af1aa7", "9926a3ed3b7f6a74", "9a779386ad0b6df6", "9c77a39efd9f44c6", "a1a6ffc166b72e28", "a1f377f18a8da6a6", "b61c354231621940", "bab295d5d87aa882", "c14e110b035fba64", "c2175a24930257ef", "d49b8cecb204cf30", "e336280d128d7ed3", "e7b746fb022724bc", "ea8f4306d637053e", "ebd4d5861aa8b5f8", "f356f87d76ba0200", "f75864a1ce887913"},
    rows = {{"f1ae066400000000", "b61c354231621940"}, {"f1ae066400000000", "c14e110b035fba64"}, {"f1ae066400000000", "f356f87d76ba0200"}, {"f1ae066400000000", "35d0a607a8c4cbd8"}, {"f1ae066400000000", "35d0a607a8c4cbd8"}, {"f1ae066400000000", "0f765ee410976e85"}, {"f1ae066400000000", "7b45f5399b31edb4"}, {"f1ae066400000000", "7b45f5399b31edb4"}, {"f1ae066400000000", "16ae53284f10122a"}, {"f1ae066400000000", "16ae53284f10122a"}, {"8ec043be00000000", "b61c354231621940"}, {"8ec043be00000000", "c14e110b035fba64"}, {"8ec043be00000000", "f356f87d76ba0200"}, {"3604df6000000000", "35d0a607a8c4cbd8"}, {"e5e54d9600000000", "92bc6e2cd8af1aa7"}, {"06ee1b3400000000", "d49b8cecb204cf30"}, {"5bf7d6f600000000", "7b45f5399b31edb4"}, {"63cba8f700000000", "0f765ee410976e85"}, {"68644e6f00000000", "16ae53284f10122a"}, {"7244634b00000000", "a1f377f18a8da6a6"}, {"bf2db62100000000", "44703d8525e563ae"}, {"e7eaba1d00000000", "48070ff6fb3524b9"}, {"09ebd08200000000", "6fd3a9c30cb04796"}, {"91ebd96500000000", "077186aa321613f8"}, {"9c73d53000000000", "ea8f4306d637053e"}, {"9c73d53000000000", "f75864a1ce887913"}, {"9c73d53000000000", "ea8f4306d637053e"}, {"9c73d53000000000", "f75864a1ce887913"}, {"b8e162b100000000", "ea8f4306d637053e"}, {"c339e7e500000000", "f75864a1ce887913"}, {"4a56c57200000000", "67bd8a7b9d91d853"}, {"4a56c57200000000", "9c77a39efd9f44c6"}, {"4a56c57200000000", "884542b7073ddf63"}, {"5ad0d33e00000000", "e336280d128d7ed3"}, {"6140e93200000000", "0ed07f6f1fee661e"}, {"8bd4446c00000000", "ebd4d5861aa8b5f8"}, {"50159a6300000000", "9a779386ad0b6df6"}, {"6879bf8100000000", "44703d8525e563ae"}, {"6879bf8100000000", "48070ff6fb3524b9"}, {"6879bf8100000000", "6fd3a9c30cb04796"}, {"6879bf8100000000", "48070ff6fb3524b9"}, {"6879bf8100000000", "6fd3a9c30cb04796"}, {"06c70e1a00000000", "a1a6ffc166b72e28"}, {"91ebd96500000000", "35eefc17edee7690"}, {"765aacf100000000", "7a223f33e2def230"}, {"e5bd29df00000000", "67bd8a7b9d91d853"}, {"e5bd29df00000000", "ea8f4306d637053e"}, {"e5bd29df00000000", "a1f377f18a8da6a6"}, {"6134b6ba00000000", "739532f1773135e0"}, {"f23606d400000000", "bab295d5d87aa882"}, {"e5d683bf00000000", "bab295d5d87aa882"}, {"e5d683bf00000000", "bab295d5d87aa882"}, {"6879bf8100000000", "266e3aaa2f3b74be"}, {"6879bf8100000000", "266e3aaa2f3b74be"}, {"7b56b1bf00000000", "c2175a24930257ef"}, {"0f5b95c400000000", "432c655d033799fb"}, {"5ad0d33e00000000", "e7b746fb022724bc"}, {"91ebd96500000000", "0e6563d7fe27889d"}, {"91ebd96500000000", "9926a3ed3b7f6a74"}, {"91ebd96500000000", "6c39231ae50bfe09"}, {"91ebd96500000000", "3a9c006633bab1cb"}},
    config = {
        rows            = true,
        templates       = true,
        candidates      = true,
        variant_disable = true,
        source_rows     = true,
        dump_rows       = true,
        dump_variants   = false,  -- diagnostic file, dump_variants=true writes PickYourBots_variants.txt
        task_user       = false,   -- off by default: guard rows keep trooper units, so it is not needed; task_user=true enables it
    },
}

end)()

profile.tags = (function()
    local t = {}
    for i, row in ipairs(profile.rows) do t[i] = row[1] end
    return t
end)()
return profile
end
local profile = build_profile()

-- Per-instance Factory Strider controls, traced against the supplied 214543 image.
-- Production uses the native spawner-disable byte; no executable patches or queue edits.
local aar_strider_controls=(function()
 local M={factory='e336280d128d7ed3'}
 local function u(s,o,n)
  if not s or #s<o+n then return end
  local v=0;for i=n,1,-1 do v=v*256+s:byte(o+i)end;return v
 end
 local function ptr(s,o)local p=u(s,o,8);if p and p>=65536 and p<2^47 and p%8==0 then return p end end
 local function raw(h)return(h:gsub('..',function(x)return string.char(tonumber(x,16))end))end
 M.guards={
  -- Spawner disabled flag: native setter, scheduler reader and creation default.
  {0x7f98d0,'4c8b15f1ccb202'},
  {0x7f995f,'498b425844883450'},
  {0x7f78c3,'488b42584889842480000000'},
  {0x7f7d07,'42803c70000f85b6010000'},
  {0x7f7ec8,'4532f64438b52e020000'},
  {0x7f7f21,'4584f60f8478060000'},
  {0x7fad89,'488b56580fb688a9000000880c13'},
  -- Convoy manager and host member list; leader selection reads the same descriptors.
  {0x86e5aa,'488b3dbf85ab02'},
  {0x86e580,'448b4948'},
  {0x86caf5,'488b84c590000000f6401401'},
  {0x86cb03,'4c69e9180300004c03ed458bb5a8030000'},
  {0x86cb41,'4b8b842ca80100008b4808'},
 }
 function M.new(mem,base,emit)
  local s={summary='initializing',held={},writes=0};local read=mem.read
  for _,g in ipairs(M.guards)do
   if read(base+g[1],#g[2]/2)~=raw(g[2])then
    s.disabled=true;s.summary='unsupported_native_layout';emit('STRIDER_CONTROLS '..s.summary);break
   end
  end
  local function stable(a,n)local b=a and read(a,n);if b and #b==n and read(a,n)==b then return b end end
  function s.convoy_member(desc)
   if s.disabled then return nil,'unsupported_native_layout' end
   local manager=ptr(read(base+0x3326b70,8),0)
   local h=manager and stable(manager,0xa0)
   local capacity,count=u(h,0x48,4),u(h,0x4c,4)
   -- The manager exists before any convoy operation has initialized its
   -- two host slots. The captured regular-Strider mission has 0/0 and no
   -- owner pointers. Permit regular callers only for this stable empty state.
   -- A later convoy activation is rechecked before request submission.
   if capacity==0 and count==0 then
    if h:sub(0x91,0xa0)~=string.rep('\0',16)then return nil,'convoy_empty_owners_nonzero'end
    if read(manager,0xa0)~=h or ptr(read(base+0x3326b70,8),0)~=manager then return nil,'convoy_changed'end
    return false,'convoy_inactive_empty'
   end
   if capacity~=2 or not count or count>2 then return nil,'convoy_header_unavailable' end
   local found=false
   for i=0,count-1 do
    local owner=ptr(h,0x90+i*8);local od=owner and stable(owner,24)
    if not od or u(od,20,4)%2~=1 then return nil,'convoy_authority_unavailable' end
    local a=manager+0xa0+i*0x318;local rec=stable(a,0x318)
    local n=u(rec,0x308,4)
    if not n or n>8 then return nil,'convoy_members_unavailable' end
    for j=0,n-1 do
     local p=ptr(rec,0x108+j*0x40)
     if p then
      local d=stable(p,24);if not d then return nil,'convoy_member_unreadable' end
      if d==desc then found=true end
     end
    end
    if read(a,0x318)~=rec or read(owner,24)~=od then return nil,'convoy_members_changed' end
   end
   if read(manager,0xa0)~=h or ptr(read(base+0x3326b70,8),0)~=manager then return nil,'convoy_changed' end
   return found,found and 'convoy_member' or 'regular_strider'
  end
  function s.allow(hash,desc,any_calls,strider_calls)
   if hash~=M.factory then return any_calls==true,'general_caller_setting' end
   if not strider_calls then return false,'strider_calls_disabled' end
   local member,why=s.convoy_member(desc)
   return member==false,why
  end
  local last_summary,last_log=nil,-100
  local function report(t,summary,lines)
   s.summary=summary
   if summary~=last_summary or t-last_log>=10 then
    emit(string.format('STRIDER_CONTROLS t=%.3f %s',t,summary));last_summary,last_log=summary,t
   end
  end
  local factory_bytes=raw(M.factory)
  -- snap: the frame's shared spawner snapshot (header, owners, descriptors); nil reads them here.
  function s.tick(t,disable_production,mission,authority,snap)
   if s.disabled then return end
   if not mission then s.held={};report(t,'inactive');return end
   if not authority then report(t,'waiting_for_host_authority');return end
   local manager,h
   if snap then manager,h=snap.manager,snap.h else manager=ptr(read(base+0x33265c8,8),0);h=manager and stable(manager,0x60)end
   local cap,n=u(h,0xc,4),u(h,0x14,4)
   local owners,flags=ptr(h,0x40),ptr(h,0x58)
   if cap~=128 or not n or n>cap or(n>0 and(not owners or not flags))then report(t,'spawner_manager_unavailable');return end
   local ob,descs
   if snap then ob,descs=snap.ob,snap.descs else ob=n==0 and ''or stable(owners,n*8)end
   if not ob then report(t,'spawner_owners_unavailable');return end
   if not descs then
    descs={}
    for i=0,n-1 do local owner=ptr(ob,i*8);descs[i+1]=owner and stable(owner,24)end
   end
   -- The disabled flags of the factories, read together.
   local fa,fk={},{}
   for i=0,n-1 do local d=descs[i+1];if d and d:sub(1,8)==factory_bytes then fa[#fa+1]=flags+i*2;fk[i]=#fa end end
   local fv
   if mem.gather then fv=mem.gather(fa,#fa,1,true)else fv={};for k,a in ipairs(fa)do fv[k]=stable(a,1)end end
   local seen={};local factories,disabled,failed,restored=0,0,0,0
   for i=0,n-1 do
    local owner=ptr(ob,i*8);local desc=descs[i+1]
    if desc and desc:sub(1,8)==factory_bytes then
     factories=factories+1;local address=flags+i*2;local value=fv[fk[i]]
     local key=desc;seen[key]=true
     local function identity()
      return ptr(read(base+0x33265c8,8),0)==manager and read(manager,0x60)==h
       and read(owners+i*8,8)==ob:sub(i*8+1,i*8+8)and read(owner,24)==desc
     end
     local function write(v)
      return identity()and read(address,1)==value and mem.writable(address,1)
       and mem.write(address,v)and (function()
        if disable_production and v=='\1'then s.held[key]='\0'end
        return read(address,1)==v
       end)()
     end
     local owned=u(desc,20,4)%2==1
     if not owned or(value~='\0'and value~='\1')then failed=failed+1
     elseif disable_production then
      if value=='\0'then
       if write('\1')then s.held[key]='\0';s.writes=s.writes+1;disabled=disabled+1
       else failed=failed+1 end
      else disabled=disabled+1 end
     elseif s.held[key]then
      if value=='\0'or write(s.held[key])then s.held[key]=nil;restored=restored+1
      else failed=failed+1 end
     end
    end
   end
   -- Never write a saved address after removal, compaction or ID/generation reuse.
   for key in pairs(s.held)do if not seen[key]then s.held[key]=nil end end
   report(t,string.format('production_off=%s factories=%d disabled=%d unresolved=%d restored=%d writes=%d',tostring(disable_production),factories,disabled,failed,restored,s.writes))
  end
  return s
 end
 return M
end)()

-- Bounded, read-only census and hysteresis for Factory Strider pressure.
local aar_factory_population=(function()
 local M={factory='e336280d128d7ed3'}
 local function u(s,o,n)
  if not s or #s<o+n then return nil end
  local v=0;for i=n,1,-1 do v=v*256+s:byte(o+i)end;return v
 end
 local function ptr(s,o)local p=u(s,o,8);if p and p>=65536 and p<2^47 and p%8==0 then return p end end
 local function raw(h)return(h:gsub('..',function(x)return string.char(tonumber(x,16))end))end
 M.guards={{0x4a441a,'4c8b156722e802'},{0x4a44aa,'4869c1b8010000'},
  {0x4a44b1,'49038258100000'},{0x91cf8b,'41899c309c010000'},
  {0x9270f2,'83bc019c01000002'}}
 function M.new(read,base,emit,gather,targets,label,default_limit)
  local wanted={}
  for _,hash in ipairs(targets or {M.factory})do wanted[raw(hash)]=true end
  label=label or 'FACTORY_POPULATION'
  default_limit=default_limit or 15
  local s={paused=false,count=nil,reason='waiting',last=-100,last_log=-100}
  for _,g in ipairs(M.guards)do
   if read(base+g[1],#g[2]/2)~=raw(g[2])then s.unsupported=true;break end
  end
  local function stable(p,n)local a=p and read(p,n);if a and #a==n and read(p,n)==a then return a end end
  -- Stable reads of many items: batched when the loader's gather is available, one by one otherwise.
  local function many(list,count,size)
   if gather then return gather(list,count,size,true)end
   local out={};for i=1,count do local p=list[i];out[i]=p and stable(p,size)end;return out
  end
  local function snapshot()
   if s.unsupported then return nil,'unsupported_health_layout'end
   local m=ptr(read(base+0x3326688,8),0);local h=m and stable(m+0x1010,0x58)
   local cap,n=u(h,0,4),u(h,16,4);local owners=ptr(h,56);local records=ptr(h,72)
   if not cap or cap>4096 or not n or n>cap or(n>0 and(not owners or not records))then return nil,'health_header'end
   local ob=n==0 and ''or stable(owners,n*8);if not ob then return nil,'health_owners'end
   -- Same checks in the same order as one read per owner; the descriptors and the factory life
   -- states are read in batches first. `known` keeps each descriptor for the ability pass below.
   local hp={};for i=0,n-1 do hp[i+1]=ptr(ob,i*8)end
   local hd=many(hp,n,24)
   local known={}
   local count,seen,stop,factories=0,{},nil,{}
   for i=0,n-1 do
    local desc=hd[i+1]
    if not desc then stop='health_owner_unreadable';break end
    known[hp[i+1]]=desc
    if wanted[desc:sub(1,8)] then
     local id=u(desc,8,4)
     if seen[id]then stop='duplicate_target_id';break end
     seen[id]=desc
     factories[#factories+1]=i
    end
   end
   local la={};for k,i in ipairs(factories)do la[k]=records+i*0x1b8+0x19c end
   local lives=many(la,#factories,4)
   for k=1,#factories do
    local status=u(lives[k],0,4)
    if status==0 then count=count+1
    elseif not status or status==1 then return nil,'target_life_unknown'end
   end
   if stop then return nil,stop end
   if ptr(read(base+0x3326688,8),0)~=m or read(m+0x1010,0x58)~=h
    or(n>0 and read(owners,n*8)~=ob)then return nil,'health_changed'end
   -- An ability owner missing from the health array must not silently reduce
   -- the count. A dead health record may still have an ability entry.
   local a=ptr(read(base+0x3326640,8),0);local ah=a and stable(a,64)
   local an=u(ah,12,4);local ao=ptr(ah,48)
   if not an or an>1024 or(an>0 and not ao)then return nil,'ability_header'end
   local ab=an==0 and ''or stable(ao,an*8)
   if not ab then return nil,'ability_owners'end
   -- Owners already read in this snapshot reuse that stable descriptor; the others are read now.
   local ap,miss,ma={},{},{}
   for i=0,an-1 do
    local p=ptr(ab,i*8);ap[i+1]=p
    if p and not known[p]then miss[#miss+1]=i+1;ma[#ma+1]=p end
   end
   local got=many(ma,#ma,24)
   local fresh={};for k,ix in ipairs(miss)do fresh[ix]=got[k]end
   for i=0,an-1 do
    local p=ap[i+1];local desc=p and(known[p]or fresh[i+1])
    if not desc then return nil,'ability_owner_unreadable'end
    if wanted[desc:sub(1,8)] and seen[u(desc,8,4)]~=desc then
     return nil,'target_health_missing_or_changed'
    end
   end
   if ptr(read(base+0x3326640,8),0)~=a or read(a,64)~=ah
    or(an>0 and read(ao,an*8)~=ab)then return nil,'ability_changed'end
   return count,'complete'
  end
  function s.poll(now,mission,limit,resume_below)
   limit=math.floor(tonumber(limit) or default_limit)
   if limit<1 or limit>30 then limit=default_limit end
   resume_below=math.max(1,math.min(limit,math.floor(tonumber(resume_below) or limit)))
   if not mission then s.paused=false;s.count=nil;s.reason='outside_mission';s.last=-100;return false end
   if now-s.last<0.5 then return s.paused end
   s.last=now
   local count,why=snapshot();s.count=count;s.reason=why
   local was=s.paused
   if not count or count>=limit then s.paused=true
   elseif s.paused and count<resume_below then s.paused=false end
   if s.paused~=was or now-s.last_log>=10 then
    s.last_log=now
    emit(string.format('%s t=%.3f alive=%s paused=%s reason=%s pause_at=%d resume_below=%d',label,now,
     tostring(count),tostring(s.paused),tostring(why),limit,resume_below))
   end
   return s.paused
  end
  return s
 end
 return M
end)()

local hulk_request = (function()
 local M={}
 local function u(s,o,n)
  if not s or #s<o+n then return nil end
  local v=0;for i=n,1,-1 do v=v*256+s:byte(o+i)end;return v
 end
 local function ptr(s,o)local v=u(s,o,8);if v and v>=65536 and v<2^47 then return v end end
 local function hex(s)return s and(s:gsub('.',function(c)return string.format('%02x',c:byte())end))end
 local function power(n,max)return n and n>=1 and n<=max and 2^math.floor(math.log(n)/math.log(2)+0.5)==n end
 local function mul(a,b)local lo,hi=a%65536,math.floor(a/65536);local bl,bh=b%65536,math.floor(b/65536)
  return(lo*bl+((hi*bl+lo*bh)%65536)*65536)%4294967296 end
 M.u=u;M.ptr=ptr
 -- PINS are inserted from the captured build by build.py, never learned at runtime.
 M.guards={
  {0x4a441a,'4c8b156722e802','health_manager_global_(record_getter)'},
  {0x4a445a,'498bba30100000','hash_buckets'},
  {0x4a44aa,'4869c1b8010000','record_stride'},
  {0x4a44b1,'49038258100000','record_array'},
  {0x53ddb5,'488b8648100000','descriptor_array'},
  {0x53ddc9,'4c8934f8','descriptor_pointer_store'},
  {0x86f29b,'418944240c','the_corpse_takes_over_the_dead_entity_unit'},
  {0x86f2a7,'8944d13c','corpse_record_+0x3C_=_dead_entity_id'},
  {0x8703c3,'8b4cc83c','corpse_lookup_reads_the_origin'},
  {0x87209a,'488b1d7f48ab02','corpse_manager_global_(add_instance)'},
  {0x8720a4,'8b4318','corpse_live_count'},
  {0x8720cb,'488b4348','corpse_record_array'},
  {0x8720d2,'4b8d0cc0','corpse_record_stride_0x48'},
  {0x8720fa,'488b4340','corpse_descriptor_pointers'},
  {0x91cf8b,'41899c309c010000','record_life_state_store'},
  {0x9270f2,'83bc019c01000002','dead_=_life_state_>=_2'},
  {0x8f6990,'4055535741554157488dac24f0f6ffff4881ec100a0000488b056256d4014833c448898550080000','request_entry'},
  {0x11bc323,'f30f1005e1bc2001f30f11442440f30f11442438c64424300048894424288b0535822c0289442420e840a673ff','native_request_defaults'},
  {0x8f8b48,'488b8568090000895a18897220f20f10008b4008f20f11420c894214418b0424894228418b0689422c8b856009000089421cc74230000080404d85d27411418b82d8','queued_identity'},
  {0x8ba08c,'498b47488b885c040000e855fa7100488b8d7809000089443910488b8578','accepted_identity'},
  {0x8f9280,'48895c2410565741564883ec30488b05ccdaa2028bda4c8bf1837854000f86530100008b91a0','cancel_entry'},
  {0x8f92c9,'42399c35c00000000f859d00','cancel_identity'},
  {0x8b4a90,'48895c240848896c2410488974241848897c242041564883ec204c8b35671ba7','accepted_lookup'},
  {0x9270f2,'83bc019c010000020f93c0ebc3cc4889','dead_predicate_branch'},
 }
 function M.verify(read,base)
  for _,g in ipairs(M.guards)do if hex(read(base+g[1],#g[2]/2))~=g[2]then return nil,'native_layout_'..g[3]end end
  return true
 end
 function M.reader(read,base)
  local R={}
  local function object(rva)return ptr(read(base+rva,8),0)end
  local function stable(p,n)local a=read(p,n);if a and #a==n and read(p,n)==a then return a end end
  function R.life(c)
   local manager=object(0x3326688);local h=manager and read(manager+0x1010,0x58)
   local capacity,live,cap=u(h,0,4),u(h,16,4),u(h,40,4)
   local buckets,owners,records=ptr(h,32),ptr(h,56),ptr(h,72)
   if not capacity or capacity>4096 or not live or live>capacity or not power(cap,65536)or not buckets or not owners or not records then return 'unknown','health_header'end
   local found
   local start=mul(c.id,u(h,48,4))
   for probe=0,cap-1 do
    local address=buckets+((start+probe)%cap)*8;local slot=stable(address,8)
    if not slot then return 'unknown','health_map_unreadable'end
    local key=u(slot,0,4)
    if key==c.id then
     local ix=u(slot,4,4);if ix>=live then return 'unknown','health_index'end
     local op=stable(owners+ix*8,8);local owner=ptr(op,0);local raw=owner and stable(owner,24)
     -- Descriptor identity, including generation/reference, must match selection.
     if not raw or raw~=c.raw then return 'unknown','health_owner_changed'end
     local life_bytes=stable(records+ix*0x1b8+0x19c,4);local life=u(life_bytes,0,4)
     if not life or read(manager+0x1010,0x58)~=h or object(0x3326688)~=manager or read(address,8)~=slot or read(owners+ix*8,8)~=op then return 'unknown','health_changed'end
     found=life
     break
    elseif key==u(h,44,4)then break end
   end
   if found then
    if found>=2 then return 'dead','life_'..found end
    if found==0 then return 'alive','life_0'end
    return 'unknown','life_'..found
   end
   -- Missing health alone is not death. An original-ID corpse link is evidence.
   local cm=object(0x3326920);local ch=cm and stable(cm+0x18,0x38);local n=u(ch,0,4)
   local cr=ptr(ch,0x30)
   if n and n<=512 and(n==0 or cr)then
    local data=n==0 and ''or stable(cr,n*0x48)
    if data and read(cm+0x18,0x38)==ch and object(0x3326920)==cm then
     for i=0,n-1 do if u(data,i*0x48+0x3c,4)==c.id then return 'dead','corpse_origin'end end
    end
   end
   return 'unknown','health_absent_no_corpse'
  end
  function R.snapshot(c,manager)
   if object(0x3326d60)~=manager then return nil,'reinforcement_manager_changed'end
   local h=stable(manager,0xa4);local n=u(h,0xa0,4)
   if not n or n>10 or u(h,0x54,4)==0 then return nil,'reinforcement_header'end
   local queue=n==0 and ''or stable(manager+0xa4,n*0x104)
   if not queue then return nil,'queue_unreadable'end
   local result={pending=0,accepted={},total_pending=n}
   for i=0,n-1 do
    if u(queue,i*0x104+0x1c,4)==c.id then result.pending=result.pending+1 end
   end
   local pm=object(0x3326618);local ph=pm and stable(pm+0x934,0x4c)
   local active,total=u(ph,0,4),u(ph,4,4);local owners,states=ptr(ph,0x2c),ptr(ph,0x44)
   if not active or not total or active>total or total>1024 or(active>0 and(not owners or not states))then return nil,'pacing_header'end
   local ob=active==0 and ''or stable(owners,active*8)
   local sb=active==0 and ''or stable(states,active*0x38)
   if not ob or not sb then return nil,'pacing_arrays'end
   for i=0,active-1 do
    if u(sb,i*0x38+0x10,4)==c.ref then
     local op=ptr(ob,i*8);local raw=op and stable(op,24)
     if not raw then return nil,'pacing_owner'end
     -- Kind zero and the director-created reinforcement resource, not arbitrary waves.
     if hex(raw:sub(1,8))~='15df8a1897dbcf4d'or u(sb,i*0x38+0xc,4)~=0 then return nil,'unexpected_caller_encounter'end
     result.accepted[#result.accepted+1]=u(raw,8,4)
    end
   end
   if read(manager,0xa4)~=h or(n>0 and read(manager+0xa4,n*0x104)~=queue)
    or object(0x3326618)~=pm or read(pm+0x934,0x4c)~=ph
    or(active>0 and(read(owners,active*8)~=ob or read(states,active*0x38)~=sb))then return nil,'request_snapshot_changed'end
   return result
  end
  return R
 end
 function M.controller(io)
  local s={attempt=nil,sequence=0}
  local function event(t,k,v)io.emit(string.format('t=%.3f HULK_REQUEST_%s %s',t,k,v or ''))end
  local function finish(t,why)
   local a=s.attempt;if io.finish then io.finish(a)end;event(t,why,'hulk='..a.caller.id..' attempt='..a.serial);s.attempt=nil
  end
  function s.start(t,c,target,manager)
   if s.attempt then return false,'request_already_tracked'end
   if not c.id or c.id==0 or not c.ref or c.ref==0 or c.ref==0x7fff then return false,'caller_identity_unavailable'end
   local life,why=io.life(c);if life~='alive'then return false,'caller_'..tostring(why)end
   local q,reason=io.snapshot(c,manager)
   if not q then return false,reason end
   if q.total_pending~=0 or #q.accepted>0 then return false,'existing_request_or_caller_encounter'end
   s.sequence=s.sequence+1
   s.attempt={caller=c,target=target,manager=manager,serial=s.sequence,phase='windup',due=t+0.5,started=t}
   if io.windup and not io.windup(s.attempt)then if io.finish then io.finish(s.attempt)end;s.attempt=nil;return false,'windup_visual_unavailable'end
   event(t,'WINDUP','hulk='..c.id..' player='..target.id..' attempt='..s.sequence..' seconds=0.5')
   return true
  end
  function s.tick(t,enabled)
   local a=s.attempt;if not a then return end
   local life,why=io.life(a.caller)
   local q,reason=io.snapshot(a.caller,a.manager)
   local observation=life..':'..tostring(why)..':'..(q and(q.pending..'/'..#q.accepted)or tostring(reason))
   if observation~=a.observation then a.observation=observation;event(t,'OBSERVED','hulk='..a.caller.id..' state='..observation)end
   if a.phase=='windup'then
    if not enabled then finish(t,'DISABLED_BEFORE_SUBMIT');return end
    if life=='dead'then finish(t,'DIED_BEFORE_SUBMIT');return end
    if t<a.due then return end
    if life~='alive'or not q or q.total_pending~=0 or #q.accepted>0 then finish(t,'PRE_SUBMIT_CHECK_FAILED');return end
    local valid,vwhy=io.ready(a)
    if not valid then event(t,'GATE_CHANGED',tostring(vwhy));finish(t,'NOT_SUBMITTED');return end
    a.phase='submitted';a.submitted=t -- set before native call; never automatically retry on an exception
    event(t,'SUBMIT','hulk='..a.caller.id..' player='..a.target.id..' source='..a.caller.id..' attempt='..a.serial)
    local ok,err=pcall(io.submit,a)
    if not ok then a.phase='uncertain';event(t,'SUBMIT_ERROR',tostring(err))end
    return
   end
   -- An explicit death or disabled setting withdraws this attempt. Never cancel source zero.
   if life=='dead'or not enabled or a.withdraw then
    a.withdraw=true
    if q and(q.pending>0 or #q.accepted>0)then
     if not a.cancel_called then
      event(t,'CANCEL','hulk='..a.caller.id..' pending='..q.pending..' accepted='..#q.accepted..' reason='..(enabled and tostring(why)or 'disabled'))
      local ok,result=pcall(io.cancel,a)
      a.cancel_called=not ok or result==true
      if not ok then event(t,'CANCEL_ERROR',tostring(result))end
     end
    elseif q then finish(t,'WITHDRAWN');return end
    -- If cancellation did not clear the request, retain tracking; no false success and no new request.
    return
   end
   if q and #q.accepted==1 and q.pending==0 then
    if life~='alive'then return end
    -- io.flare performs a fresh health and owner check immediately before emission.
    a.phase='flare_committed'
    local ok,result=pcall(io.flare,a,q.accepted[1])
    event(t,'ACCEPTED','hulk='..a.caller.id..' encounter='..q.accepted[1]..' flare='..tostring(ok and result==true))
    if not ok then event(t,'FLARE_ERROR',tostring(result))end
    if ok and result~=true and io.life(a.caller)=='dead'then a.withdraw=true;return end
    finish(t,'COMPLETE');return
   end
   if q and #q.accepted>1 then a.withdraw=true;event(t,'AMBIGUOUS','multiple_caller_encounters');return end
   if q and q.pending>0 then a.seen_pending=true end
   -- No cooldown/count heuristic. Queue departure without matching encounter is unresolved/rejected.
   if q and q.pending==0 and #q.accepted==0 and t-a.submitted>=2 then
    finish(t,a.seen_pending and 'LEFT_QUEUE_WITHOUT_ACCEPTANCE'or 'NO_REQUEST_OBSERVED');return
   end
   if t-a.submitted>30 and not a.withdraw then a.withdraw=true;event(t,'TIMEOUT_WITHDRAW','hulk='..a.caller.id)end
  end
  function s.reset()if s.attempt and io.finish then io.finish(s.attempt)end;s.attempt=nil end -- called only after mission identity changes/mission ends
  return s
 end
 return M
end)()

-- The caller is defined above the seat capture implementation. Share this
-- local binding so occupied_vehicle_targets does not resolve a nil global.
local aar_seat_capture
local hulk_996 = (function()
local G={ability=0x3326640,reinforcement=0x3326d60,pacing=0x3326618,director=0x3326d10}
local function u32(s,o)
    if not s or o < 0 or o+4 > #s then return nil end
    local a,b,c,d=s:byte(o+1,o+4)
    return a+b*256+c*65536+d*16777216
end
local function pointer(s,o)
    local lo,hi=u32(s,o),u32(s,o+4)
    if not hi then return nil end
    local p=lo+hi*4294967296
    if p < 65536 or p >= 140737488355328 then return nil end
    return p
end
local function f32(s,o)
    local n=u32(s,o); if not n then return nil end
    local sign=n>=2147483648 and -1 or 1
    local exp=math.floor(n/8388608)%256; local mant=n%8388608
    if exp==255 then return nil end
    if exp==0 then return sign*mant*2^-149 end
    return sign*(1+mant/8388608)*2^(exp-127)
end
local function hex(s)
    return s and (s:gsub('.',function(c) return string.format('%02x',c:byte()) end)) or 'unreadable'
end
local function addr(p) return p and string.format('0x%x',p) or 'nil' end
local function num(n) return n and string.format('%.5f',n) or 'invalid' end
local GUARDS = {
    {0x11651ac,"19421601"},
    {0x10d4e30,"40534883ec20488bd983fa05752a488b0dfb1425024881c1b075af0780796400754bba12000000c6416401e8a023f3ff32c04883c4205bc383fa1e7538e86e780e0048ba02dc14f5117036e941b8356e6a8d488bcbe886e40d00ba9f3c33c841b8356e6a8d488bcbe813c60c0032c04883c4205bc381fa82000000753048ba02dc14f5117036e941b8bee4a43be84ee40d00ba9f3c33c841b8bee4a43b488bcbe8dbc50c0032c04883c4205bc381fac8000000753048ba02dc14f5117036e941b8adc5ad09e816e40d00ba9f3c33c841b8adc5ad09488bcbe8a3c50c0032c04883c4205bc381fa0e010000753048ba02dc14f5117036e941b81e3a11cbe8dee30d00ba9f3c33c841b81e3a11cb488bcbe86bc50c0032c04883c4205bc381fa2c0100000f8544ffffffb0014883c4205bc3"},
    {0x7caf40,"4c8bdc49895b18555657415541564881ecb0000000488b05b410e7014833c448898424900000003b15b38ccb02458be94d897b108bda410f2973c8458bf84489442430488bf1744d448b4120448b492833c9440fafcb418d78ff4585c074364c8b5618448b5e24660f1f8400000000008bc7428d14094823d0418b04d2413bc30f84ea0000003bc30f84ea000000ffc1413bc872dbb8ffffffff488b6e38f30f10b42400010000448bf04969fee00000004183fd027414488b46304a8b0cf0f6411401741a4183fd0175140f28de458bc78bd348c7c1feffffffe8415d4100807c2f10000f84c4000000f30f10442f08f30f590508c7bf010f5ac0e838de9301488b4e308b142ff24c0f2cc04a8b0cf1e8fb4399003b1dc58bcb020f848d0000004c8b1580bdb50233c94c89a424e0000000458b4250458b4a58440fafcb458d60ff4585c0745f4d8b5a48458b7a5490418bc4428d14094823d0418b04d3413bc7741f3bc3741fffc1413bc872e2eb363bc30f851dffffff418b44d204e918ffffff3bc3752041837cd304ff74184533c944896c242041b857512b868bd3498bcae82ad703004c8ba424e00000008b5c243033c00f57c9f30f11742f0c891c2f4533ed4c896c2f044533c0c7442f14ffffffff8bd3c6442f10014c896c2f18488944244048894424480f104424400f11442f300f114c2f400f114c2f50488b4e304a8b0cf1e8965898000f28b424a00000004c8bbc24e800000084c0747a3b1c2f7575488b4e304533c08bd34a8b0cf1e8db429900488b4e380f57c033c04489ac248000000048898424840000008b8424880000000f11840f9000000044886c0f100f11840fa000000044896c0f140f11840fb00000000f11840fc0000000f20f10842480000000f20f11840fd000000089840fd8000000488b8c24900000004833cce888d58b01488b9c24f00000004881c4b0000000415e415d5f5e5dc3"},
    {0x11a14b0,"48895c24184889742420574881ec80000000488b0547ab49014833c448894424"},
    {0x11b3310,"48895c24084889742410574883ec20488b05e22f1702488bda488bf18b490c48"},
    {0x7caf40,"4c8bdc49895b18555657415541564881ecb0000000488b05b410e7014833c448"},
    {0xfd9c80,"4883ec08448bc181f9ff7f00000f84990000004c8b15fe22490233d248895c24"},
    {0x11bc7fc,"488b8580010000488d1449403874d0147427f20f1044d0048b4cd00ce99d000000"},
    {0x8f6990,"4055535741554157488dac24f0f6ffff4881ec100a0000488b056256d4014833"},
    {0x11bc120,"4c8bdc57415541574881ec800000008b41084d8bf93b05e57a2c02418bf84c8b"},
    {0x11bc34b,"e840a673ff"},
    -- Observed v0.5 timed helper calls: infantry frame 100 and Strider frame 30.
    {0x10c422f,"e82c810f00"},
    {0x10c444f,"e80c7f0f00"},
    {0x10d4e6d,"e86e780e00"},
    -- Observed v0.4 dispatcher cases for abilities 678, 679 and 996.
    {0x1153698,"418bd0e8600af7ff"},
    {0x11536a9,"418bd0e86f0cf7ff"},
    {0x1154b50,"418bd0e8d802f8ff"},
    -- Direct call sites verified in the user's v0.3 loaded-code capture.
    {0x7c89ac,"e82f809800"},
    {0x7c89d0,"e87b6a9900"},
    {0x8f8b9a,"e8510a0000"},
    {0x8f5260,"488bc4488958104889681856574154415641574883ec700f2970c833db488bf90f2978b8f30f103de41aad01440f2940a8440f28c14c896808448beb3959540f86f5030000440f2948980f57f6f3440f100d3a25ad01488b055b13a302458bf54d69fe1c0a00004f8d24b64a8bacf780000000399834090000777af3410f108c3f940000000f2fce761a410f28c0f30f598024090000f30f5cc8f3410f118c3f94000000488bcfe8640e0000f3410f10943f940000000f2ff276050f28ceeb070f28c8f30f5dcaf3410f118c3f940000004c8d87d00a0000488b8780000000ba942697eaf30f5ec8f3410f11088b4810e88b446e00418b8c3f8c000000410f28"},
    {0x8f4f83,"488bcbe8e5110000f30f5984b3d00a0000488b742438f30f11841f94000000"},
    {0x8f5ead,"488b8580000000448b70104181feff7f00007462488b0d4004a302488b4140488bb860010000488b4138ff5008488bc8418bd6ffd74885c0743cf30f1085940000000f2fc6763c32c00f287424504c8d5c2460498b5b30498b6b38498b7348450f2843d00f287c2440498be3415f415e415d415c5fc3f30f1085d00a00000f2fc677c4"},
    {0x8f7e16,"498bcfe852e3fffff3410f11879400000041ff8fa0000000"},
    {0x8f4e8f,"8b42083b05b4edb802488b1dc11ea3027443448b4b7033d2448b5378440fafd0418d71ff4585c9742c4c8b5b688b7b74908bce468d04124c23c1438b0cc33bcf0f84d80000003bc80f84d8000000ffc2413bd172dcb8ffffffff8bd04869fa1c0a00008bc8488d"},
    {0x12f1c6a,"488b1dc7b8170280bb34e32400000f840d010000488b05bb46030283b81cc20a00030f84f900000080bbf0d84600000f84cd000000488d8b68f13e000f29742450c683f2d8460001e859ac5b00"},
    {0x12f1daa,"488b3d87b7170280bf34e32400000f846d010000488b057b45030283b81cc20a00030f845901000080bff0d84600000f842d01000048899c2480000000488d8f68f13e000f29742450c687f2d8460000e8c1ae5b00"},
    {0x18ac92a,"80b99501000000488bf90f853c03000049895b08ba8c1424a6410f2973e8410f297bd8450f2943c8c6819501000001c6819ff2050001c681e801000001"},
    {0x18accda,"80b99501000000488bf90f84d002000049895b08ba726e9b88c6819501000000c681e801000000"},
    {0x7c8840,"40554155488dac2448ffffff4881ecb8010000440f299c24"},
    {0x7cb200,"415641574883ec483b15128acb02458bf9450fb6f04c8bd9"},
    {0x7cbb10,"48895c240848896c2410488974241848897c242041564883"},
}
local function bytes(h) return (h:gsub('%x%x',function(x) return string.char(tonumber(x,16)) end)) end
local function verify(read,base)
    if not base then return false,'game.dll not loaded' end
    local h=read(base,64)
    if not h or h:sub(1,2)~='MZ' then return false,'MZ header unavailable' end
    local pe=u32(h,60)
    if not pe or pe<64 or pe>4096 then return false,'invalid PE offset' end
    local p=read(base+pe,84)
    if not p or p:sub(1,4)~='PE\0\0' then return false,'PE header unavailable' end
    if u32(p,8)~=1790161983 or u32(p,80)~=74727424 then
        return false,'unsupported PE timestamp/image size'
    end
    for i,g in ipairs(GUARDS) do
        local expected=bytes(g[2]);local actual=read(base+g[1],#expected)
        if actual~=expected then return false,string.format('guard %d RVA 0x%x mismatch/unreadable',i,g[1]) end
    end
    return true,string.format('Steam target 25480438; PE fingerprint and %d exact-byte guards matched',#GUARDS)
end
local ENGINE_GUARDS={
 {0x1fe590,"40534883ec208bdae823f3e9ff488bc84c8b0041ff90e800000033c9448b40104585c07417488b50400f1f8000000000391c8a740cffc1413bc872f4b9ffffffff83f9ff0f95c04883c4205bc3"},
 {0x1fe5e0,"40534883ec208bdae8d3f2e9ff488bc84c8b0041ff90e8000000488bd033c0448b42104585c07414488b52400f1f4000391c82740cffc0413bc072f4b8ffffffff4883c4205bc3"},
 {0x1fd220,"40534883ec204863dae89206eaff488bc84c8b0041ff90e8000000488bcb48c1e10648034828488bc14883c4205bc3"},
}
local function verify_engine(read,base,engine,check_api)
 if not engine then return false,'exe_missing' end
 local mz=read(engine,64);local pe=u32(mz,60)
 if not mz or mz:sub(1,2)~='MZ' or not pe or pe<64 or pe>4096 then return false,'exe_header' end
 local p=read(engine+pe,84)
 if not p or p:sub(1,4)~='PE\0\0' or u32(p,8)~=1790149348 or u32(p,80)~=60719104 then return false,'exe_fingerprint' end
 for _,g in ipairs(ENGINE_GUARDS)do
  local expected=bytes(g[2]);if read(engine+g[1],#expected)~=expected then return false,'exe_code_guard' end
 end
 if check_api==false then return true,'exe_fingerprint_and_three_code_guards_matched_API_checked_before_query' end
 local root=pointer(read(base+0x3326308,8),0);local unit=root and pointer(read(root+0x18,8),0)
 if not unit or pointer(read(unit+0x6d0,8),0)~=engine+0x1fe590 or pointer(read(unit+0x6d8,8),0)~=engine+0x1fe5e0
   or pointer(read(unit+0x90,8),0)~=engine+0x1fd220 then return false,'unit_API_binding' end
 return true,'exe_fingerprint_three_code_guards_and_API_slots_matched'
end
local function reinforcement_state(read,base)
 local r=pointer(read(base+G.reinforcement,8),0);local h=r and read(r,0xAD4)
 local cap=u32(h,0x70);local descriptor=pointer(h,0x80);local slots=pointer(h,0x68)
 if not cap or cap<1 or cap>16 or not descriptor or not slots then return {status='UNAVAILABLE'} end
 local dh=read(descriptor,24);local map=read(slots,cap*8)
 if not dh or not map then return {status='UNAVAILABLE'} end
 local found
 for i=0,cap-1 do if u32(map,i*8)==u32(dh,8) and u32(dh,8)~=u32(h,0x74)then found=u32(map,i*8+4);break end end
 if found~=0 or u32(dh,20)%2~=1 then return {status='UNAVAILABLE'} end
 local p=pointer(read(base+G.pacing,8),0);local ph=p and read(p+0x924,20)
 local raw,count,rate,blockers=f32(h,0x94),u32(h,0xA0),f32(ph,0),u32(ph,16)
 -- f32 rejects NaN/infinity. A positive native rate can legitimately exceed
 -- 100 with the supported 90% cooldown reduction (captured: 114.477).
 -- This is a rate, not a percentage; an arbitrary 100 ceiling blocks callers.
 local reason
 if not raw or raw<0 or raw>86400 then reason='cooldown_invalid'
 elseif not count or count>8 then reason='pending_count_invalid'
 elseif not rate or rate<=0 then reason='rate_invalid'
 elseif not blockers then reason='blocker_count_unreadable'end
 if reason then return {status='INVALID',reason=reason,raw=raw,count=count,rate=rate,blockers=blockers}end
 return {authority=true,status=count>0 and 'PENDING' or (blockers>0 and 'PAUSED' or (raw>0 and 'COOLDOWN' or 'READY')),count=count,raw=raw,rate=rate,blockers=blockers}
end
-- Identities and positive live AI abilities from the supplied component dump.
-- Unknown states are observed and reported, never guessed from adjacent ability IDs.
local BOT_PROFILES={
 ['a1f377f18a8da6a6']={name='cha_berserker',family='bot',states={[973]=true,[983]=true,[988]=true,[2642]=true}},
 ['cb2969cfda07e154']={name='cha_berserker_iron_fleet',family='bot',states={[973]=true,[983]=true,[2642]=true}},
 ['0e6563d7fe27889d']={name='cha_cyborg_elite',family='bot',states={[786]=true,[791]=true,[792]=true,[793]=true,[794]=true,[795]=true}},
 ['e19cb4ebc914ba96']={name='cha_lieutenant_base',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['44703d8525e563ae']={name='cha_soldier',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['2d205a49bbd226c6']={name='cha_soldier_iron_fleet',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true}},
 ['c2175a24930257ef']={name='cyborg_assault_walker',family='bot',states={[594]=true,[597]=true,[600]=true,[601]=true,[684]=true}},
 ['a1a6ffc166b72e28']={name='cyborg_gunship',family='bot',states={}},
 ['e7b746fb022724bc']={name='cyborg_siege_engine',family='bot',states={[941]=true,[1016]=true}},
 ['e336280d128d7ed3']={name='cyborg_spawner',family='bot',states={[995]=true,[997]=true,[1007]=true,[1008]=true,[1009]=true,[1010]=true,[1011]=true,[1012]=true,[1013]=true}},
 ['8d4d062f4de7ba31']={name='cyborg_tank_base',family='bot',states={[1016]=true,[1025]=true}},
 ['35eefc17edee7690']={name='cyborg_walker_scout_reinforced',family='bot',states={}},
 ['077186aa321613f8']={name='cyborg_walker_scout',family='bot',states={[684]=true,[686]=true,[1058]=true,[1061]=true}},
 ['ad21c940c2c0dbb5']={name='cha_berserker_ivory_legion',family='bot',states={[973]=true,[983]=true,[988]=true,[2642]=true}},
 ['a46bb056682f79d5']={name='cha_berserker_jumppack',family='bot',states={[973]=true,[983]=true,[988]=true,[2642]=true}},
 ['6c39231ae50bfe09']={name='cha_cyborg_elite_female',family='bot',states={[786]=true,[791]=true,[792]=true,[793]=true,[794]=true,[795]=true}},
 ['9926a3ed3b7f6a74']={name='cha_cyborg_elite_rusher',family='bot',states={[786]=true,[791]=true,[792]=true,[793]=true,[794]=true,[795]=true}},
 ['3a9c006633bab1cb']={name='cha_cyborg_elite_rusher_female',family='bot',states={[786]=true,[791]=true,[792]=true,[793]=true,[794]=true,[795]=true}},
 ['0ed07f6f1fee661e']={name='cha_lieutenant_artillery',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['ea8f4306d637053e']={name='cha_lieutenant_assault',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['92b6d8f5ad2eab6d']={name='cha_lieutenant_ivory_legion',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['dcd20521d3bd9718']={name='cha_lieutenant_ivory_legion_assault',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['f75864a1ce887913']={name='cha_lieutenant_suppressor',family='hulk',states={[829]=true,[847]=true,[848]=true,[849]=true,[850]=true,[851]=true,[852]=true,[860]=true,[861]=true,[863]=true,[864]=true,[985]=true,[2730]=true}},
 ['9dcd46c3ead0ee57']={name='cha_soldier_ivory_legion',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['266e3aaa2f3b74be']={name='cha_soldier_jumppack',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['48070ff6fb3524b9']={name='cha_soldier_mg',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['ebd4d5861aa8b5f8']={name='cha_soldier_mg_assassinate',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['419236116cb8b258']={name='cha_soldier_mg_ivory_legion',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['6fd3a9c30cb04796']={name='cha_soldier_rpg',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['9a779386ad0b6df6']={name='cha_soldier_rpg_assassinate',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['a4824aa5b0ccbcc9']={name='cha_soldier_rpg_ivory_legion',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['739532f1773135e0']={name='cha_soldier_shotgun_ivory_legion',family='bot',states={[958]=true,[973]=true,[975]=true,[976]=true,[977]=true,[978]=true,[979]=true,[982]=true,[983]=true,[984]=true,[985]=true,[986]=true,[987]=true,[989]=true}},
 ['7a223f33e2def230']={name='cyborg_spawner_jammer',family='bot',states={[995]=true,[997]=true,[1007]=true,[1008]=true,[1009]=true,[1010]=true,[1011]=true,[1012]=true,[1013]=true}},
 ['9c77a39efd9f44c6']={name='cyborg_tank_autocannons',family='bot',states={[1016]=true,[1025]=true}},
 ['67bd8a7b9d91d853']={name='cyborg_tank_heavycannon',family='bot',states={[1016]=true,[1025]=true}},
 ['884542b7073ddf63']={name='cyborg_tank_rocketlauncher',family='bot',states={[1016]=true,[1025]=true}},
}
for _,v in ipairs({
 {'b064c698ffcd7f1a','Charger','bug_charger_calls'},
 {'4cacb367ecd15ba0','Behemoth MK2','bug_charger_calls'},
 {'990b45d5d75fff3a','Behemoth','bug_charger_calls'},
 {'5e60abf49223206b','Spore Charger','bug_charger_calls'},
 {'8c221c132bb9b70a','Rupture Charger','bug_charger_calls'},
 {'2e424a9d9dca40f5','Stalker','bug_stalker_calls'},
 {'525a2df2ba90e9d1','Predator Stalker','bug_stalker_calls'},
 {'dd35245088000964','Shrieker','bug_shrieker_calls'},
 {'ddafccccf2172e9e','Bile Titan','bug_titan_calls'},
 {'97a497d084cb04ef','Spore Burst Bile Titan','bug_titan_calls'},
})do BOT_PROFILES[v[1]]={name=v[2],family='terminid',toggle=v[3],states={}}end
-- Watchers already call through their native alarm (live ability 1818).
-- The remaining Illuminate combat roster, except Stingray, can use the
-- validated request path. Stingray's special group 144 remains wholly native.
for _,v in ipairs({
 {'472c01717549e178','Voteless Light'},
 {'1d8ead73919fdc0a','Voteless Medium'},
 {'fb02b0522c8a4544','Voteless Heavy'},
 {'f247747c34bb40da','Overseer'},
 {'20b85bc44e794a60','Elevated Overseer'},
 {'6de458a90a9af1e8','Crescent Overseer'},
 {'332df0a4dc32dc67','Fleshmob'},
 {'4addac515aae5e96','Harvester'},
 {'07f1be377b022df2','Leviathan'},
 {'65adae4d73c7b920','Veracitor'},
 {'0fb34e632ce23f45','Gatekeeper'},
 {'9e2e476533d2df34','Obtruder'},
 {'458a8dc2a4095890','Crusher'},
 {'6c5c50800c8f18cc','Wretch'},
})do BOT_PROFILES[v[1]]={name=v[2],family='illuminate',states={}}end
local function bot_kind(hash) return BOT_PROFILES[hash] end
local function supported_state(hash,ability)
 local p=BOT_PROFILES[hash]
 if not p or not ability then return false end
 if p.toggle=='bug_shrieker_calls' and ability==388 then return false end
 if p.family=='terminid'then return ability>=0 and ability<=65535 and not ((ability>=231 and ability<=234)or(ability>=415 and ability<=418)or(ability>=439 and ability<=441))end
 if p.family=='illuminate'then return ability>=0 and ability<=65535 and ability%1==0 end
 if p.family=='hulk' then return ability>=820 and ability<=866 end
 -- Ground-bot health and target identity are rechecked by the request controller.
 return p.name~='cyborg_gunship' and ability>=0 and ability~=996 and ability<=65535 and ability%1==0
end
local function caller_state(hash,ability,active,paused)
 local p=bot_kind(hash)
 if not p or not supported_state(hash,ability)or paused~=0 or(active~=0 and active~=1)then return false end
 return p.family~='hulk' or active==1
end
-- Batched reads (the loader's gather) when available; set by the caller at start.
local gather_many
local function many(read,list,count,size)
 if gather_many then return gather_many(list,count,size,false)end
 local out={};for i=1,count do local p=list[i];out[i]=p and read(p,size)end;return out
end
local TRACKED={[bytes('97fa4d294d331c4d')]='97fa4d294d331c4d'}
for hash in pairs(BOT_PROFILES)do TRACKED[bytes(hash)]=hash end
local function make_lite_core(read,emit,base)
 local core={last_frame=nil,last_reinforcement=nil,last_status=nil}
 function core.sample(t)
  local rr=reinforcement_state(read,base);core.last_reinforcement=rr;core.last_frame=nil
  if rr.status~=core.last_status then emit(string.format('t=%.3f REINFORCEMENT status=%s cooldown=%s pending=%s rate=%s blockers=%s reason=%s',t,rr.status,num(rr.raw),tostring(rr.count),num(rr.rate),tostring(rr.blockers),rr.reason or 'none'));core.last_status=rr.status end
  if not rr.authority then return end
  local a=pointer(read(base+G.ability,8),0);local ah=a and read(a,64);local count=u32(ah,12)
  if not count or count<1 or count>1024 then return end
  local owners,states=pointer(ah,48),pointer(ah,56);local ob=owners and read(owners,count*8)
  if not ob or not states then return end
  local frame={entries={}}
  -- Descriptors batched; the state array (224 bytes per entry) in one read when it can be read.
  local ptrs={};for i=0,count-1 do ptrs[i+1]=pointer(ob,i*8)end
  local descs=many(read,ptrs,count,24)
  local all=read(states,count*224)
  local seen={}
  for i=0,count-1 do
   local owner=ptrs[i+1];local oh=descs[i+1]
   if owner then seen[owner]=oh or false end
   local hash=oh and TRACKED[oh:sub(1,8)]
   if hash then
    local sh=all and all:sub(i*224+1,i*224+32)or read(states+i*224,32)
    if sh then frame.entries[#frame.entries+1]={id=u32(oh,8),hash=hash,ownerbytes=oh,
        ability=u32(sh,0),active=sh:byte(17),paused=sh:byte(18)} end
   end
  end
  if read(a,64)==ah then
   core.last_frame=frame
   -- Descriptors of this frame, reused by the selection in the same tick (same owners array only).
   core.frame_time,core.frame_ah,core.frame_ob,core.frame_desc=t,ah,ob,seen
  end
 end
 return core
end
-- Resolve a Helldiver's occupied vehicle through both native seat tables.
-- The AI targets the vehicle's reference while the player is seated.
-- The seat layout guards are checked once per mission (cleared by the caller's reset).
local seat_guards_ok={}
local function occupied_vehicle_targets(read,base,players)
    if not aar_seat_capture or not aar_seat_capture.guards then return {} end
    if not seat_guards_ok[base] then
        for _,g in ipairs(aar_seat_capture.guards)do
            if hex(read(base+g[1],#g[2]/2))~=g[2]then return {} end
        end
        seat_guards_ok[base]=true
    end
    local function table_at(rva,stride)
        local root=read(base+rva,8);local manager=pointer(root,0)
        local h=manager and read(manager,0x50)
        local cap,n=u32(h,0),u32(h,8)
        local owners,data=pointer(h,0x38),pointer(h,0x48)
        if not cap or cap>256 or not n or n>cap or not owners or not data then return end
        local ob=read(owners,n*8);local rows=read(data,n*stride)
        if not ob or not rows or read(manager,0x50)~=h or read(owners,n*8)~=ob or read(data,n*stride)~=rows
            or read(base+rva,8)~=root then return end
        return {root=root,manager=manager,h=h,owners=owners,ob=ob,data=data,rows=rows,n=n,stride=stride,rva=rva}
    end
    local a,b=table_at(0x3326d78,0x40),table_at(0x3326d88,0x64)
    if not a or not b then return {} end
    local function valid(t)
        return read(base+t.rva,8)==t.root and read(t.manager,0x50)==t.h
            and read(t.owners,t.n*8)==t.ob and read(t.data,t.n*t.stride)==t.rows
    end
    local by_player={};for _,p in ipairs(players)do by_player[p.id]=p end
    local result,used,used_vehicle={},{},{}
    local ap={};for i=0,a.n-1 do ap[i+1]=pointer(a.ob,i*8)end
    local ad=many(read,ap,a.n,24)
    local bp,bd={},nil
    for i=0,a.n-1 do
        local o=ap[i+1];local desc=ad[i+1]
        local p=desc and by_player[u32(desc,8)]
        if p and desc==(p.raw or p.ownerbytes) then
            local seat=a.rows:sub(i*0x40+1,(i+1)*0x40)
            local vehicle_id,seat_id=u32(seat,0),u32(seat,4)
            if vehicle_id and vehicle_id>0 and seat_id and seat_id~=0xffffffff then
                if not bd then for j=0,b.n-1 do bp[j+1]=pointer(b.ob,j*8)end;bd=many(read,bp,b.n,24)end
                for j=0,b.n-1 do
                    local vo=bp[j+1];local vd=bd[j+1]
                    local vs=b.rows:sub(j*0x64+1,(j+1)*0x64)
                    local ref=vd and u32(vd,16)
                    if vd and u32(vd,8)==vehicle_id and u32(vs,0)==seat_id
                        and ref and ref>0 and ref~=0x7fff and ref~=u32(desc,16)
                        and not used[ref] and not used_vehicle[vehicle_id] then
                        used[ref]=true;used_vehicle[vehicle_id]=true
                        result[#result+1]={id=vehicle_id,hash=hex(vd:sub(1,8)),raw=vd,
                            ownerbytes=vd,owner=vo,ref=ref,seated_player=p.id,
                            seat_valid=function()return valid(a)and valid(b)and read(o,24)==desc and read(vo,24)==vd end}
                    end
                end
            end
        end
    end
    if not valid(a)or not valid(b)then return {} end
    return result
end
local function make_trial(read,emit,request,base,engine,life,policy,core_ref)
    local trial={used=false,down=false,attempts=0,last_attempt=-100,last_block=nil,last_block_at=-100}
    local function event(t,k,v) emit(string.format('t=%.3f %s %s',t,k,v)) end
    local function pos(h,o)
        local v={f32(h,o),f32(h,o+4),f32(h,o+8)}
        for i=1,3 do if not v[i] or math.abs(v[i])>100000 then return nil end end
        return v
    end
    function trial.press(t,rr,eligible)
        local function reject(why)
            if why~=trial.last_block or t-trial.last_block_at>=5 then
                event(t,'TRIAL_BLOCKED',why)
                trial.last_block,trial.last_block_at=why,t
            end
            return false
        end
        if trial.used then return reject('one_attempt_per_launch_already_used') end
        if not life then return reject('life_reader_unavailable')end
        if not rr or not rr.authority or rr.status~='READY' or rr.count~=0 then return reject('host_mission_not_ready status='..tostring(rr and rr.status)..' cooldown='..tostring(rr and rr.raw)) end
        local r=pointer(read(base+G.reinforcement,8),0)
        local rh=r and read(r,0xAD4)
        if not rh or u32(rh,0x54)==0 or u32(rh,0xA0)~=0 or f32(rh,0x94)~=0 then return reject('reinforcement_gate_changed') end
        local p=pointer(read(base+G.pacing,8),0);local ph=p and read(p+0x924,20)
        if not ph or not f32(ph,0) or f32(ph,0)<=0 or u32(ph,16)~=0 then return reject('pacing_gate_changed') end
        local a=pointer(read(base+G.ability,8),0);local ah=a and read(a,64);local count=u32(ah,12)
        if not count or count<1 or count>1024 then return reject('invalid_ability_array') end
        local owners=pointer(ah,48);local states=pointer(ah,56);local ob=owners and read(owners,count*8)
        if not states then return reject('states_unavailable') end
        if not ob then return reject('owner_array_unreadable') end
        local entries,players,hulks,seen={},{},{},{}
        local scorcher_count,bruiser_count=0,0
        -- Descriptors read by this tick's sample are reused when the ability header and owners array
        -- are unchanged; any other owner is read now.
        local reuse=core_ref and core_ref.frame_time==t and core_ref.frame_ah==ah and core_ref.frame_ob==ob and core_ref.frame_desc
        local op,need,na={},{},{}
        for i=0,count-1 do
            local o=pointer(ob,i*8);op[i+1]=o
            if o and not(reuse and reuse[o])then need[#need+1]=i+1;na[#na+1]=o end
        end
        local got=many(read,na,#na,24);local fresh={}
        for k,ix in ipairs(need)do fresh[ix]=got[k]end
        for i=0,count-1 do
            local o=op[i+1];local h=o and(reuse and reuse[o]or fresh[i+1])
            if not h then return reject('owner_unreadable') end
            local hash=hex(h:sub(1,8));local id=u32(h,8)
            if not seen[id] then
                seen[id]=true
                local e={id=id,owner=o,raw=h,hash=hash,index=i,state_address=states+i*224}
                if hash=='97fa4d294d331c4d' then players[#players+1]=e;entries[#entries+1]=e
                elseif bot_kind(hash) and u32(h,20)%2==1 then
                    hulks[#hulks+1]=e;entries[#entries+1]=e
                end
            end
        end
        if #players<1 then return reject('no_observed_helldiver') end
        if #hulks==0 then return reject('no_supported_ground_bot_observed') end
        if not eligible then return reject('automatic_target_evidence_required') end
        local vehicles=occupied_vehicle_targets(read,base,players)
        -- The vehicle can already be in the ability inventory as an untracked
        -- entity. `seen` tracks inventory IDs, not transform entries; always
        -- add its seat-derived descriptor so it receives a position.
        for _,v in ipairs(vehicles)do entries[#entries+1]=v;seen[v.id]=true end
        -- Native helpers resolve entity transforms through this map and data stride.
        local tm=pointer(read(base+0x3326508,8),0);local th=tm and read(tm,0x70)
        local cap=u32(th,0x48);local mp=pointer(th,0x40);local data=pointer(th,0x68)
        if not cap or cap<1 or cap>32768 or 2^math.floor(math.log(cap)/math.log(2)+0.5)~=cap or not mp or not data then return reject('transform_layout_unavailable') end
        local map=read(mp,cap*8);if not map then return reject('transform_map_unreadable') end
        local empty=u32(th,0x4c);local indexes={}
        for i=0,cap-1 do
            local id=u32(map,i*8)
            if id~=empty and seen[id] then
                if indexes[id] then return reject('duplicate_transform_key') end
                indexes[id]=u32(map,i*8+4)
            end
        end
        local pe,pa={},{}
        for _,e in ipairs(entries) do
            local ix=indexes[e.id]
            if ix and ix<cap then pe[#pe+1]=e;pa[#pa+1]=data+ix*0x308+0x2e0 end
        end
        local praw=many(read,pa,#pa,12)
        for k,e in ipairs(pe)do
            local raw=praw[k]
            e.position=raw and pos(raw,0);e.positionraw=raw
            e.transform=pa[k]
        end
        -- Map the AI target handle to exactly one observed Helldiver. Duplicate
        -- refs fail closed: a guessed teammate must never enter the native call.
        local players_by_ref={}
        for _,p in ipairs(players) do
            local ref=u32(p.raw,16)
            if not ref or ref==0x7fff or players_by_ref[ref] then return reject('ambiguous_player_target_reference') end
            players_by_ref[ref]=p
        end
        for _,v in ipairs(vehicles)do
            if players_by_ref[v.ref]then return reject('ambiguous_vehicle_target_reference')end
            players_by_ref[v.ref]=v
        end
        local best,player,distance,nearby,unsupported=nil,nil,nil,0,{}
        for _,h in ipairs(hulks) do
            local e=eligible[h.id]
            local target=e and players_by_ref[e.ref]
            if h.position and target and target.position and e.ownerbytes==h.raw and e.playerbytes==target.raw then
                local sum=0;for j=1,3 do sum=sum+(h.position[j]-target.position[j])^2 end
                local d=math.sqrt(sum)
                local kind=bot_kind(h.hash)
                local minimum=(kind and kind.family=='illuminate') and 1 or 15
                if d>=minimum and d<=100 then
                    nearby=nearby+1
                    if caller_state(e.hash,e.ability,e.active,e.paused) and(not policy or policy(h.hash,h.raw))then
                        if (not distance or d<distance)and life(h)=='alive'then best=h;player=target;distance=d end
                    elseif #unsupported<4 then
                        unsupported[#unsupported+1]=string.format('%d:%s/%s/%s',h.id,
                            tostring(e.ability),tostring(e.active),tostring(e.paused))
                    end
                end
            end
        end
        if not best then
            if nearby>0 then return reject('no_alive_eligible_bot nearby='..nearby..' sample_id_ability_active_paused='..table.concat(unsupported,',')) end
            return reject('no_matching_target_caller_in_range')
        end
        local evidence=eligible[best.id]
        if player.seat_valid and not player.seat_valid()then return reject('seat_changed_before_call')end
        local current_target=read(evidence.address,24)
        if not current_target or u32(current_target,0)~=u32(player.raw,16) or u32(current_target,0)==0x7fff or u32(current_target,16)~=0
            or read(evidence.header_address,56)~=evidence.header or read(evidence.map_address,evidence.map_size)~=evidence.map
            then return reject('target_changed_before_call') end
        -- Recheck snapshots used for selection. No game pointers except the manager
        -- are passed into native code; both vectors are copied into owned FFI arrays.
        if read(a,64)~=ah or read(tm,0x70)~=th or read(mp,cap*8)~=map
            or read(best.owner,24)~=best.raw or read(player.owner,24)~=player.raw
            or read(best.transform,12)~=best.positionraw or read(player.transform,12)~=player.positionraw
            or pointer(read(base+G.reinforcement,8),0)~=r then return reject('selection_changed_during_read') end
        -- The starter performs an unchecked entity-map lookup: validate that exact mapping first.
        local acap,amap=u32(ah,0x20),pointer(ah,0x18)
        if not acap or acap<1 or acap>32768 or 2^math.floor(math.log(acap)/math.log(2)+0.5)~=acap or not amap then return reject('ability_map_invalid') end
        local ab=read(amap,acap*8);if not ab then return reject('ability_map_unreadable') end
        local sentinel=u32(read(base+0x3483c20,4),0)
        if sentinel==nil or best.id==sentinel then return reject('invalid_entity_sentinel') end
        local factor=u32(ah,0x28)
        local lo,hi=best.id%65536,math.floor(best.id/65536)
        local flo,fhi=factor%65536,math.floor(factor/65536)
        local product=(lo*flo+((hi*flo+lo*fhi)%65536)*65536)%4294967296
        local mapped
        for probe=0,acap-1 do
            local ix=(product+probe)%acap;local key=u32(ab,ix*8)
            if key==u32(ah,0x24) then break end
            if key==best.id then mapped=u32(ab,ix*8+4);break end
        end
        if mapped~=best.index then return reject('ability_index_mismatch') end
        local sb=read(best.state_address,32)
        local previous_ability=u32(sb,0)
        if not sb or not caller_state(best.hash,previous_ability,sb:byte(17),sb:byte(18)) then return reject('bot_not_in_active_supported_state') end
        local ok,why=verify(read,base);if not ok then return reject('game_guard_'..why) end
        local ek,ew=verify_engine(read,base,engine);if not ek then return reject('engine_guard_'..ew) end
        if read(a,64)~=ah or read(amap,acap*8)~=ab or read(best.owner,24)~=best.raw
            or read(best.state_address,32)~=sb or read(player.owner,24)~=player.raw or read(evidence.address,24)~=current_target then return reject('ability_or_target_changed_before_start') end
        local rh2=read(r,0xAD4);local ph2=read(p+0x924,20)
        if not rh2 or u32(rh2,0x54)==0 or u32(rh2,0xA0)~=0 or f32(rh2,0x94)~=0
            or rh2:sub(0x69,0x88)~=rh:sub(0x69,0x88) or ph2~=ph then return reject('request_gate_changed_before_call') end
        if policy then local ok,why=policy(best.hash,best.raw);if not ok then return reject('caller_policy_'..tostring(why))end end
        if player.seat_valid and not player.seat_valid()then return reject('seat_changed_before_start')end
        best.ref=u32(best.raw,16);best.target_evidence=evidence
        local started,reason=request.start(t,best,player,r)
        if not started then return reject('request_'..tostring(reason))end
        trial.attempts=trial.attempts+1;trial.last_attempt=t;trial.used=true;trial.selected=best
        event(t,'REQUEST_START_ATTEMPT',string.format('hulk=%d hash=%s player=%d distance=%.2f source_id=%d controlled_windup=0.5 ability_996_invoked=false',best.id,best.hash,player.id,distance,best.id))
        return true
    end
    function trial.key(t,down,foreground,rr)
        local rising=down and not trial.down;trial.down=down
        if rising and foreground then return trial.press(t,rr) end
    end
    return trial
end

local function make_target_watcher(read,emit,base)
    local watcher={last=-100,reason='not_sampled'}
    local function event(t,k,s)emit(string.format('t=%.3f %s %s',t,k,s))end
    function watcher.sample(t,frame,rr)
        if not frame or not rr or not rr.authority then watcher.reason='frame_or_authority_unavailable';return end
        if t-watcher.last<0.5 then watcher.reason='sample_throttled';return end
        watcher.last=t
        local manager=pointer(read(base+0x3326d30,8),0)
        local h=manager and read(manager+0x150,56)
        local cap=u32(h,8);local slots=pointer(h,0);local data=pointer(h,48)
        if not cap or cap<1 or cap>32768 or 2^math.floor(math.log(cap)/math.log(2)+0.5)~=cap or not slots or not data then
            watcher.reason='target_component_header';event(t,'TARGET_UNAVAILABLE','reason=component_header');return {}
        end
        local map=read(slots,cap*8);if not map then watcher.reason='target_component_map';event(t,'TARGET_UNAVAILABLE','reason=component_map');return {} end
        local tm=pointer(read(base+0x3326508,8),0);local th=tm and read(tm,0x70)
        local tc=u32(th,0x48);local ts=pointer(th,0x40);local td=pointer(th,0x68)
        local transforms
        if tc and tc>=1 and tc<=32768 and ts and td then transforms=read(ts,tc*8) end
        local records,positions,addresses={},{},{}
        local selected={}
        for _,e in ipairs(frame.entries)do
            if bot_kind(e.hash) or e.hash=='97fa4d294d331c4d' then selected[e.id]=e end
        end
        local foot={}
        for _,e in pairs(selected)do if e.hash=='97fa4d294d331c4d'then foot[#foot+1]=e end end
        local vehicles=occupied_vehicle_targets(read,base,foot)
        for _,v in ipairs(vehicles)do selected[v.id]=v end
        local ri,ra={},{}
        for i=0,cap-1 do
            local id=u32(map,i*8);local index=u32(map,i*8+4)
            if selected[id] and id~=u32(h,12) and index<cap then ri[#ri+1]=id;ra[#ra+1]=data+index*24 end
        end
        local rv=many(read,ra,#ra,24)
        for k,id in ipairs(ri)do records[id]=rv[k];addresses[id]=ra[k]end
        if transforms then
            local pi,pa={},{}
            for i=0,tc-1 do
                local id=u32(transforms,i*8);local ix=u32(transforms,i*8+4)
                if selected[id] and id~=u32(th,0x4c) and ix<tc then pi[#pi+1]=id;pa[#pa+1]=td+ix*0x308+0x2e0 end
            end
            local pv=many(read,pa,#pa,12)
            for k,id in ipairs(pi)do positions[id]=pv[k]end
        end
        local stable=read(manager+0x150,56)==h and read(slots,cap*8)==map
        local players={}
        for _,e in pairs(selected)do
            if e.hash=='97fa4d294d331c4d' then
                local ref=u32(e.ownerbytes,16)
                if not ref or ref==0x7fff or players[ref] then watcher.reason='ambiguous_player_reference';return {} end
                players[ref]=e
            end
        end
        for _,v in ipairs(vehicles)do
            if players[v.ref]then watcher.reason='ambiguous_vehicle_reference';return {} end
            players[v.ref]=v
        end
        local sightings={}
        -- A vehicle's seat check is done once per sample, not once per bot aiming at it.
        local seat_ok={}
        local function seated(target)
            local v=seat_ok[target]
            if v==nil then v=target.seat_valid()and true or false;seat_ok[target]=v end
            return v
        end
        for id,e in pairs(selected)do
            local pos=positions[id];local rec=records[id]
            local target=rec and players[u32(rec,0)]
            if stable and target and (not target.seat_valid or seated(target)) and e~=target and rec and supported_state(e.hash,e.ability)
                and u32(rec,16)==0 then
                sightings[id]={hash=e.hash,ownerbytes=e.ownerbytes,playerbytes=target.ownerbytes,ref=u32(rec,0),
                    ability=e.ability,active=e.active,paused=e.paused,
                    address=addresses[id],header_address=manager+0x150,header=h,map_address=slots,map_size=cap*8,map=map}
            end
        end
        local n=0;for _ in pairs(sightings)do n=n+1 end
        watcher.reason=not stable and 'target_snapshot_changed' or ('matching_targets_'..n)
        return sightings
    end
    return watcher
end

return function(mem, emit, write_capture)
local ffi = require('ffi')
ffi.cdef[[uint64_t GetTickCount64(void);]]
local win = ffi.load('kernel32')
local read = mem.read
gather_many = mem.gather
local base, engine = mem.module('game.dll'), mem.module('helldivers2.exe')
local striders=aar_strider_controls.new(mem,base,emit)
local options={any_bot_calls=true,factory_strider_calls=true}
local function allowed(hash,desc)
 local p=bot_kind(hash)
 if p and p.family=='terminid'then return options.faction=='terminid' and options.bug_cloud_ready==true and options[p.toggle]==true end
 if p and p.family=='illuminate'then return options.faction=='illuminate' and options.illuminate_calls==true end
 if options.faction=='terminid'then return false end
 if options.faction=='illuminate'then return false end
 return striders.allow(hash,desc,options.any_bot_calls,options.factory_strider_calls)
end
local enabled, why = verify(read, base)
if enabled then enabled, why = verify_engine(read, base, engine, false) end
if not enabled then emit('hulk996_disabled ' .. tostring(why)); return nil end
local has_node = ffi.cast('uint8_t (*)(uint32_t, uint32_t)', engine+0x1fe590)
local cloud=bug_special_controls.cloud(mem,base,bug_mix.binary,has_node,emit)
local emit_resource = ffi.cast('void (*)(void *, uint64_t, uint32_t)', base+0x11b3310)
local flare_resource = ffi.new('uint64_t[1]')
local flare_words = ffi.cast('uint32_t *', flare_resource)
flare_words[0], flare_words[1] = 0xF514DC02, 0xE9367011
-- Watcher NPC effect ID hash('alarm') = 0x15f60942, attached to root.
-- Its authored particle resource was read from the current native definition.
local illuminate_alarm_resource = ffi.new('uint64_t[1]')
ffi.copy(illuminate_alarm_resource, bug_mix.binary.raw('1ed65ffd0818ae98'), 8)
-- The Watcher callback triggers effect 0x10017110 after alarm. Its authored
-- slot 7 particle is the leading candidate for the four launched orbs.
local illuminate_orb_resource = ffi.new('uint64_t[1]')
ffi.copy(illuminate_orb_resource, bug_mix.binary.raw('5711c49f8f098926'), 8)
local illuminate_effects_checked,illuminate_effects_valid=false,false
local function check_illuminate_effects()
 if illuminate_effects_checked then return illuminate_effects_valid end
 local signature=bug_mix.binary.raw('48895c24084889742410574883ec20')
 if read(base+0x11b3310,#signature)~=signature then return false end
 local lib=pointer(read(base+0x346bf98,8),0)
 local tp=lib and pointer(read(lib+0xf127b8,8),0)
 local map=tp and read(tp,1376*16)
 if not map then return false end
 local watcher=bug_mix.binary.raw('9d8c093584e760ac')
 for i=0,1375 do
  if map:sub(i*16+1,i*16+8)==watcher then
   local ix=u32(map,i*16+8)
   if ix and ix<1376 then
    local rows=read(tp+1376*16+ix*0xf48+8,32*80)
    if rows then
     local alarm,orbs=false,false
     for j=0,31 do
      local row=rows:sub(j*80+1,(j+1)*80)
      if row:sub(1,8)==bug_mix.binary.raw('1ed65ffd0818ae98')
       and u32(row,0x30)==0x15f60942 and u32(row,0x20)==0xbccf91e5 then
       alarm=true
      elseif row:sub(1,8)==bug_mix.binary.raw('5711c49f8f098926')
       and u32(row,0x30)==0x10017110 and u32(row,0x20)==0xbccf91e5 then
       orbs=true
      end
     end
     if alarm and orbs then
      illuminate_effects_checked=true;illuminate_effects_valid=true
      return true
     end
    end
   end
   break
  end
 end
 return false
end
-- Inserted inside the existing v1.2 caller, where its helpers are in scope.
local request_ok,request_why=hulk_request.verify(read,base)
if not request_ok then emit('hulk_request_disabled '..tostring(request_why));return nil end
local submit_request=ffi.cast('void (*)(void *, uint32_t, const float *, uint32_t, uint32_t, const float *, uint8_t, float, float)',base+0x8f6990)
local cancel_request=ffi.cast('void (*)(void *, uint32_t)',base+0x8f9280)
local reader=hulk_request.reader(read,base)
local request
request=hulk_request.controller({
 emit=emit,life=reader.life,snapshot=reader.snapshot,
 windup=function(a)
  if bot_kind(a.caller.hash).family~='terminid'then return true end
  -- Test38: the borrowed Hunter calling puff does not expire on non-native callers, so it is optional
  -- (Faction page, default off). The breach call itself does not depend on it.
  if options.bug_call_cloud~=true then return true end
  return cloud.begin(a.caller)
 end,
 finish=function(a)if bot_kind(a.caller.hash).family=='terminid'then cloud.finish()end end,
 ready=function(a)
  local rr=reinforcement_state(read,base)
  if not rr.authority or rr.status~='READY'or rr.count~=0 then return false,'reinforcement_gate'end
  if reader.life(a.caller)~='alive'then return false,'caller_life'end
  local c,p=a.caller,a.target
  local ok,why=allowed(c.hash,c.raw);if not ok then return false,'caller_policy_'..tostring(why)end
  if read(c.owner,24)~=c.raw or read(p.owner,24)~=p.raw then return false,'owner_changed'end
  if p.seat_valid and not p.seat_valid()then return false,'seat_changed'end
  local am=pointer(read(base+G.ability,8),0);local ah=am and read(am,64)
  local owners,states=pointer(ah,48),pointer(ah,56)
  if not owners or not states or c.index>=u32(ah,12)or pointer(read(owners+c.index*8,8),0)~=c.owner then return false,'ability_owner_moved'end
  local ab=read(states+c.index*224,32);local ability=u32(ab,0)
  if not ab or not caller_state(c.hash,ability,ab:byte(17),ab:byte(18)) then return false,'ability_changed'end
  local e=c.target_evidence
  if read(e.header_address,56)~=e.header or read(e.map_address,e.map_size)~=e.map then return false,'target_map_changed'end
  local target=read(e.address,24)
  if not target or u32(target,0)~=u32(p.raw,16)or u32(target,16)~=0 then return false,'target_changed'end
  local pr=read(p.transform,12);local cr=read(c.transform,12)
  if not pr or not cr then return false,'position_unavailable'end
  local d=0;local position={}
  for i=0,2 do
   local x,y=f32(pr,i*4),f32(cr,i*4)
   if not x or not y or x~=x or y~=y or math.abs(x)>100000 or math.abs(y)>100000 then return false,'position_invalid'end
   position[i+1]=x;d=d+(x-y)^2
  end
  local kind=bot_kind(c.hash)
  local minimum_squared=(kind and kind.family=='illuminate') and 1 or 225
  if d<minimum_squared or d>10000 then return false,'distance_changed'end
  a.position=position
  return true
 end,
 submit=function(a)
  local v=ffi.new('float[3]',a.position)
  -- Same kind, target and positions as 996's reinforcement request. Argument 5
  -- is now the caller ID. Both optional scalar overrides remain native defaults.
  submit_request(ffi.cast('void *',a.manager),0,v,a.target.id,a.caller.id,v,0,-1.0,-1.0)
 end,
 cancel=function(a)
  if pointer(read(base+G.reinforcement,8),0)~=a.manager then error('cancel_manager_changed')end
  local q=reader.snapshot(a.caller,a.manager)
  if not q or(q.pending==0 and #q.accepted==0)then return false end
  cancel_request(ffi.cast('void *',a.manager),a.caller.id)
  return true
 end,
 flare=function(a,encounter)
  local c=a.caller
  if reader.life(c)~='alive'or read(c.owner,24)~=c.raw then return false end
  local q=reader.snapshot(c,a.manager)
  if not q or q.pending~=0 or #q.accepted~=1 or q.accepted[1]~=encounter then return false end
  if bot_kind(c.hash).family=='illuminate'then
   if not check_illuminate_effects()then
    emit('illuminate_effects_skipped authored_resources_unavailable')
    return false
   end
   local handle=u32(c.raw,12)
   local node=tonumber(has_node(handle,0xbccf91e5))==1 and 0xbccf91e5 or 0
   if reader.life(c)~='alive'or read(c.owner,24)~=c.raw then return false end
   local ok,err=pcall(emit_resource,ffi.cast('void *',c.owner),illuminate_alarm_resource[0],node)
   if not ok then emit('illuminate_alarm_error '..tostring(err));return false end
   emit('illuminate_alarm_emitted caller='..c.id..' encounter='..encounter..' node='..node)
   if reader.life(c)~='alive'or read(c.owner,24)~=c.raw then return false end
   ok,err=pcall(emit_resource,ffi.cast('void *',c.owner),illuminate_orb_resource[0],node)
   if not ok then emit('illuminate_orbs_error '..tostring(err));return false end
   emit('illuminate_orbs_emitted caller='..c.id..' encounter='..encounter..' node='..node)
   return true
  end
  if bot_kind(c.hash).family=='terminid'then return true end
  local handle=u32(c.raw,12);local node
  if tonumber(has_node(handle,0x9B115563))==1 then node=0x9B115563
  elseif bot_kind(c.hash).family=='hulk' and tonumber(has_node(handle,0xBE6C3963))==1 then node=0xBE6C3963 end
  if not node then emit('hulk_request_flare_skipped node_missing hulk='..c.id);return false end
  if reader.life(c)~='alive'or read(c.owner,24)~=c.raw then return false end
  emit_resource(ffi.cast('void *',c.owner),flare_resource[0],node)
  emit('hulk_request_flare_emitted hulk='..c.id..' encounter='..encounter)
  return true
 end,
})

local core = make_lite_core(read, emit, base)
local watcher = make_target_watcher(read, emit, base)
local trial = make_trial(read, emit, request, base, engine, reader.life, allowed, core)
local last, hold_until, mission, fired, last_state_log = -100, -100, nil, false, -100
local last_error = nil
local gate_key,gate_time=nil,-100
local function gate(now,why)
    if why~=gate_key or now-gate_time>=5 then
        emit(string.format('t=%.3f hulk_request_gate %s',now,why));gate_key,gate_time=why,now
    end
end
local function reset()
    seat_guards_ok = {}
    request.reset()
    gate_key,gate_time=nil,-100
    last, hold_until, fired, last_state_log = -100, -100, false, -100
    trial.used, trial.attempts, trial.last_attempt = false, 0, -100
    trial.last_block, trial.last_block_at = nil, -100
end
-- busy: the population census ran this frame; the 0.5 s selection then waits one frame so that the two
-- bursts of reads never share a frame. Outstanding calls are still serviced every frame.
local function tick(mode, active, settings, busy)
    if settings then options=settings end
    local now = tonumber(win.GetTickCount64())/1000
    mode = mode()
    if mode ~= 4 then
        if mission then mission = nil; reset() end
        return
    end
    local director = pointer(read(base+G.director,8),0)
    if not director then return end
    if mission ~= director then
        mission = director; reset()
        emit('hulk_request_mission_ready')
    end
    -- Service outstanding calls every update, including cooldown and mod disable.
    request.tick(now,active)
    if request.attempt then gate(now,'tracking_'..request.attempt.phase);return end
    if not active then gate(now,'feature_inactive');return end
    if now-last < 0.5 then return end
    if busy then return end
    last=now
    -- While cooldown is active we do not inspect the Hulk, target or transform maps.
    local rr = reinforcement_state(read, base)
    if rr.status ~= 'READY' then
        gate(now,'reinforcement_'..tostring(rr.status)..' pending='..tostring(rr.count)..' blockers='..tostring(rr.blockers))
        if rr.status == 'PENDING' or rr.status == 'COOLDOWN' or rr.status == 'PAUSED' then
            fired = false
            trial.used, trial.attempts = false, 0
        end
        return
    end
    if now < hold_until then gate(now,'retry_backoff');return end
    if fired then
        -- Prior attempt has finished; normal READY polling may select again.
        fired = false
        trial.used, trial.attempts = false, 0
    end
    if trial.used then trial.used, trial.attempts = false, 0 end
    core.sample(now)
    local sightings = watcher.sample(now, core.last_frame, rr)
    if not sightings then gate(now,watcher.reason);return end
    -- A single stable target snapshot is enough. trial.press rechecks the owner,
    -- target, transform, ability slot and reinforcement gate before the native call.
    if not next(sightings) then gate(now,watcher.reason);return end
    local has_supported=false
    local sample={}
    for id,e in pairs(sightings) do
        if caller_state(e.hash,e.ability,e.active,e.paused) and allowed(e.hash,e.ownerbytes)then
            has_supported=true
        elseif #sample<4 then
            sample[#sample+1]=string.format('%d:%s/%s/%s',id,
                tostring(e.ability),tostring(e.active),tostring(e.paused))
        end
    end
    if not has_supported then
        gate(now,'no_supported_active_caller '..watcher.reason)
        if now-last_state_log>=5 then
            emit('hulk996_waiting_hulk_state sample_id_ability_active_paused='..table.concat(sample,','))
            last_state_log=now
        end
        return
    end
    -- Re-evaluate eligibility at the normal 0.5-second selection cadence.
    -- The controller prevents overlap; the native director owns availability.
    gate(now,'attempt_preflight '..watcher.reason)
    local ok, result = pcall(trial.press, now, rr, sightings)
    if not ok then
        if result ~= last_error then emit('hulk996_error ' .. tostring(result)); last_error = result end
        trial.used = true
        hold_until = math.huge -- native invocation might have thrown: disable until mission reset.
    elseif result then
        hold_until = now + 0.5
        fired = true
        emit('hulk_request_windup_started entity=' .. tostring(trial.selected and trial.selected.id))
    elseif trial.attempts>0 then
        hold_until = now + 0.5
    else
        hold_until = now + 0.5
    end
end
return { tick=tick, reset=reset }
end
end)()

-- Optional regular-corpse cleanup. Field evidence: EnemySpawnMultiplier
-- 800af72719f51a9968242948d855b2e16266b317 src/corpse_clear.lua.
-- Independent bounded scanner; no native calls, code patches, or physics writes.
local aar_corpse_cleanup=(function()
 local M={}
 local HEADER=string.char(112,202,193,128,76,68,76,68,1,0,0,0)
 local CHUNK=262120 -- reader maximum minus record overlap
 local function u(s,o)
  if not s or #s<o+4 then return end
  local a,b,c,d=s:byte(o+1,o+4);return a+b*256+c*65536+d*16777216
 end
 local function f(s,o)
  local v=u(s,o);if not v then return end
  local e=math.floor(v/8388608)%256;local m=v%8388608
  if e==255 then return end
  return (v>=2147483648 and -1 or 1)*(e==0 and m*2^-149 or (1+m/8388608)*2^(e-127))
 end
 local function near(v,w)return v and math.abs(v-w)<0.0001 end
 local function oneof(v,vs)for _,w in ipairs(vs)do if near(v,w)then return true end end;return false end
 function M.new(mem,codec,emit)
  local s={status='disabled',cursor=65536,offset=0,records={},order={},check=1,halted=false,last=-100}
  local function status(v)if s.status~=v then s.status=v;emit('CORPSE_CLEANUP '..v)end end
  local function writable(p,n)
   local r=mem.region(p)
   return r and r.state==0x1000 and r.kind==0x20000 and r.protect==4
    and p>=r.base and p+n<=r.base+r.size
  end
  local function same_table()
   if not s.table then return false end
   local r=mem.region(s.table)
   return r and r.base==s.table and r.size==s.size and r.allocation==s.allocation
    and r.state==0x1000 and r.kind==0x20000 and r.protect==4
    and mem.read(s.table,#HEADER)==HEADER
  end
  local function put(p,bytes)return writable(p,#bytes)and mem.write(p,bytes)and mem.read(p,#bytes)==bytes end
  function s.stop()
   local restored,skipped=0,0
   local valid=same_table()
   for _,p in ipairs(s.order)do
    local r=s.records[p]
    -- Restore only our exact complete record, including untouched identity.
    if valid and mem.read(p,#r.after)==r.after then
     if put(p+r.off,r.before:sub(r.off+1,r.off+r.len))then restored=restored+1 else skipped=skipped+1 end
    else skipped=skipped+1 end
   end
   if #s.order>0 then emit(string.format('CORPSE_CLEANUP_RESTORE restored=%d skipped=%d',restored,skipped))end
   s.records={};s.order={};s.table=nil;s.size=nil;s.offset=0;s.cursor=65536;s.check=1;s.done=false
   status('disabled');return skipped==0
  end
  local function apply(p,before,off,replacement,valid)
   if s.records[p]or not same_table()or not valid()or mem.read(p,#before)~=before then return true end
   local after=before:sub(1,off)..replacement..before:sub(off+#replacement+1)
   if after==before then return true end
   if not writable(p,#before)then return true end
   local r={before=before,after=after,off=off,len=#replacement}
   s.records[p]=r;s.order[#s.order+1]=p
   if put(p+off,replacement)then return true end
   -- A failed API write can be partial. Restore only bytes still equal to
   -- either our before or after values, and never after an identity change.
   local live=mem.read(p,#before);local owned=live and #live==#before
   if owned then for i=1,#before do
    local c=live:sub(i,i)
    if c~=before:sub(i,i)and c~=after:sub(i,i)then owned=false;break end
   end end
   if owned and same_table()then put(p+off,before:sub(off+1,off+#replacement))end
   s.stop();s.halted=true;status('halted_after_write_failure');return false
  end
  local patterns={}
  for _,pair in ipairs({{3,3710897668},{1,1243096897}})do
   local n=pair[2];local b={}
   for i=1,4 do b[i]=string.char(n%256);n=math.floor(n/256)end
   patterns[#patterns+1]=codec.float(pair[1])..table.concat(b)
  end
  local function scan_chunk(valid)
   local count=math.min(CHUNK,s.size-s.offset)
   local raw=mem.read(s.table+s.offset,math.min(count+23,s.size-s.offset))
   if not raw then status('table_read_failed');return false end
   local at=1
   while true do
    local hit=raw:find('\1\0\0\0',at,true);if not hit or hit>count then break end
    local b=raw:sub(hit,hit+23)
    if #b==24 and oneof(f(b,4),{.2,.5})and oneof(f(b,8),{5,7,10,30,60})
     and oneof(f(b,12),{90,120})and oneof(f(b,16),{0,8,10})
     and b:byte(21)<=1 and b:sub(22,24)=='\0\0\0' then
     if not apply(s.table+s.offset+hit-1,b,8,codec.float(5)..codec.float(5)..codec.float(10),valid)then return false end
    end
    at=hit+1
   end
   for _,pattern in ipairs(patterns)do
    at=1
    while true do
     local hit=raw:find(pattern,at,true);if not hit or hit>count then break end
     if not apply(s.table+s.offset+hit-1,pattern,0,codec.float(300),valid)then return false end
     at=hit+1
    end
   end
   s.offset=s.offset+count
   if s.offset>=s.size then
    s.done=true;status('active records='..#s.order..' initial_scan_complete')
   end
   return true
  end
  function s.poll(enabled,now,valid)
   if not enabled then if s.table or s.status~='disabled'then s.stop()end;return end
   if s.halted then return end
   if now-s.last<1 then return end;s.last=now
   if not valid()then s.stop();status('waiting_for_host_mission');return end
   if s.table and not same_table()then s.stop();status('table_changed_rescanning')end
   if not s.table then
    -- At most 128 queries and 32 tiny header reads per second.
    local reads=0
    for _=1,128 do
     local r=mem.region(s.cursor)
     if not r or r.size<=0 then s.cursor=65536;status('entities_not_found');return end
     s.cursor=math.max(s.cursor+4096,r.base+r.size)
     if r.state==0x1000 and r.kind==0x20000 and r.protect==4 and r.size>=24 then
      reads=reads+1
      if mem.read(r.base,#HEADER)==HEADER then
       s.table=r.base;s.size=r.size;s.allocation=r.allocation;s.offset=0;s.done=false
       status('scanning_regular_corpse_settings');break
      end
     end
     if s.cursor>=140737488355328 then s.cursor=65536;break end
     if reads>=32 then break end
    end
    if not s.table then status('locating_entity_table');return end
   end
   if not s.done then
    -- One bounded initial sweep, <= 1 MiB/second. No recurring full scans.
    for _=1,4 do if s.done or not scan_chunk(valid)then break end end
   else
    -- Refresh at most 32 known records; exact identity and original values
    -- required. Other mods' or the game's changed records are left alone.
    for _=1,math.min(32,#s.order)do
     local p=s.order[s.check];local r=s.records[p]
     if same_table()and valid()and mem.read(p,#r.before)==r.before then
      if not put(p+r.off,r.after:sub(r.off+1,r.off+r.len))then
       local live=mem.read(p,#r.before);local owned=live and #live==#r.before
       if owned then for i=1,#live do
        if live:sub(i,i)~=r.before:sub(i,i)and live:sub(i,i)~=r.after:sub(i,i)then owned=false;break end
       end end
       if owned and same_table()then put(p+r.off,r.before:sub(r.off+1,r.off+r.len))end
       s.stop();s.halted=true;status('halted_after_refresh_failure');return
      end
     end
     s.check=s.check%#s.order+1
    end
   end
  end
  return s
 end
 return M
end)()


-- Read only the active HiveMindComponent faction. A failed or changing lookup returns nil,
-- so no faction-specific work runs on an unverified mission. The director and resource
-- lookup paths match the guarded spawn-curve resolver below, but never clone or write.
local function make_faction_probe(mem)
    local base = mem.module('game.dll')
    local function u32(s,o)
        if not s or o+4>#s then return nil end
        local a,b,c,d=s:byte(o+1,o+4);return a+b*256+c*65536+d*16777216
    end
    local function ptr(s,o)
        local lo,hi=u32(s,o),u32(s,o+4)
        if not hi then return nil end
        local n=lo+hi*4294967296
        return n>=65536 and n<140737488355328 and n%8==0 and n or nil
    end
    local function ptr4(s,o)
        local lo,hi=u32(s,o),u32(s,o+4)
        if not hi then return nil end
        local n=lo+hi*4294967296
        return n>=65536 and n<140737488355328 and n%4==0 and n or nil
    end
    local function resource_row(key)
        if not key or key==string.rep('\0',8) then return nil end
        local root=ptr(mem.read(base+0x346bf98,8),0)
        local slot=root and root+0xf12b18
        local tableptr=slot and ptr4(mem.read(slot,8),0)
        local header=tableptr and mem.read(tableptr,0x260)
        if not header then return nil end
        local index
        for i=0,37 do
            if header:sub(i*16+1,i*16+8)==key then
                if index then return nil end
                index=u32(header,i*16+8)
            end
        end
        if not index or index>=38 then return nil end
        return tableptr+0x260+index*0x43c
    end
    local function probe()
        if not base then return nil end
        local director=ptr(mem.read(base+0x3326d10,8),0)
        local handleptr=director and ptr(mem.read(director+0x6b0,8),0)
        local handle=handleptr and mem.read(handleptr,16)
        local generation=u32(handle,8)
        local invalid=u32(mem.read(base+0x3483c24,4),0)
        if not generation or not invalid then return nil end
        local row
        if generation~=invalid then
            local h=mem.read(director+0x51968,24)
            local tableptr,count,sentinel=ptr(h,0),u32(h,8),u32(h,12)
            if tableptr and count and count<=4096 then
                local map=mem.read(tableptr,count*8)
                if map then
                    for i=0,count-1 do
                        if u32(map,i*8)==generation and generation~=sentinel then
                            if row then return nil end
                            local index=u32(map,i*8+4)
                            if index and index<1024 then row=director+0x519ac+index*0x43c end
                        end
                    end
                end
            end
        end
        if not row then row=resource_row(handle:sub(1,8)) end
        local faction=u32(mem.read(row,4),0)
        if faction~=2 and faction~=4 and faction~=8 then return nil end
        if ptr(mem.read(base+0x3326d10,8),0)~=director
            or ptr(mem.read(director+0x6b0,8),0)~=handleptr
            or mem.read(handleptr,16)~=handle then return nil end
        return faction==8 and 'automaton' or faction==2 and 'terminid' or 'illuminate'
    end
    local last,known=-100,nil
    return function(mode,now)
        if mode~=4 then last=-100;known=nil;return nil end
        if now-last>=0.5 then
            last=now
            local ok,value=pcall(probe)
            known=ok and value or nil
        end
        return known
    end
end

local function make_spawn_tuning(mem, emit, save, codec)
    local base = mem.module('game.dll')
    local function u32(s,o)
        if not s or o+4>#s then return nil end
        local a,b,c,d=s:byte(o+1,o+4);return a+b*256+c*65536+d*16777216
    end
    local function ptr(s,o)
        local a,b=u32(s,o),u32(s,o+4)
        if not b then return nil end
        local n=a+b*4294967296
        return n>=65536 and n<140737488355328 and n or nil
    end
    local function f32(s,o)
        local n=u32(s,o);if not n then return nil end
        local e=math.floor(n/8388608)%256;local m=n%8388608
        if e==255 then return nil end
        local sign=n>=2147483648 and -1 or 1
        return e==0 and sign*m*2^-149 or sign*(1+m/8388608)*2^(e-127)
    end
    local function hex(s) return s and (s:gsub('.',function(c)return string.format('%02x',c:byte())end)) or 'unreadable' end
    local function bytes(s)return (s:gsub('%x%x',function(c)return string.char(tonumber(c,16))end))end
    if not codec then
        local ffi=require('ffi')
        codec={float=function(v)return ffi.string(ffi.new('float[1]',v),4)end,
            pointer=function(v)return ffi.string(ffi.new('uint64_t[1]',v),8)end,
            clone=function(raw)
                return mem.publish_blob(raw)
            end}
    end
    local cleanup=aar_corpse_cleanup.new(mem,codec,emit)
    local function private(p,n)
        local r=p and mem.region(p)
        return r and r.state==0x1000 and r.kind==0x20000 and r.protect==4
            and p>=r.base and p+n<=r.base+r.size
    end
    local function write(p,raw)
        return private(p,#raw) and mem.write(p,raw) and mem.read(p,#raw)==raw
    end
    local function director()return base and ptr(mem.read(base+0x3326d10,8),0)end
    local function host()
        local r=ptr(mem.read(base+0x3326d60,8),0)
        local h=r and mem.read(r+0x68,32)
        local slots=ptr(h,0);local n=u32(h,8);local descriptor=ptr(h,24)
        if not slots or not n or n<1 or n>16 or not descriptor then return false end
        local entry=mem.read(descriptor,24);local map=mem.read(slots,n*8)
        if not entry or not map or u32(entry,20)%2~=1 or u32(entry,8)==u32(h,12) then return false end
        for i=0,n-1 do
            if u32(map,i*8)==u32(entry,8) then
                return u32(map,i*8+4)==0 and mem.read(r+0x68,32)==h
                    and mem.read(descriptor,24)==entry and mem.read(slots,n*8)==map
                    and ptr(mem.read(base+0x3326d60,8),0)==r
            end
        end
        return false
    end
    -- Exact READ-ONLY fingerprints of resolver, resource fallback and budget override.
    local guards = {
        {0x9593b1,'f30f59b48b64010000'},
        {0x9593c9,'f30f59b4838c010000'},
        {0x9593e5,'f30f59b48378010000'},
        {0x9595b8,'f30f59b48ba0010000'},
        {0x95979d,'f30f59b48bdc010000'},
        {0x9597b9,'f30f59b48304020000'},
        {0x9597d5,'f30f59b483f0010000'},
        {0x94e969,'f30f10bc8bf8030000'},
        {0x94e98e,'f30f59bc8320040000'},
        {0x94e9b3,'f30f59bc830c040000'},
        {0x95604f,'488b99b0060000488bf9488bcb488bf2e81c05bbff0f57c9f30f104078'},
        {0x506593,'8b41083b0588d6f7020f84a60000004c8b1d6707e202'},
        {0x506632,'4869c83c040000498d83ac1905004803c1'},
        {0x505fb9,'8b48084869c13c0400004805600200004903c2c3'},
    }
    local function build_ok()
        if not base then return false end
        for _,g in ipairs(guards)do
            local raw=bytes(g[2]);if mem.read(base+g[1],#raw)~=raw then return false end
        end
        return true
    end
    local function valid_row(raw)
        local faction=u32(raw,0)
        if faction~=2 and faction~=4 and faction~=8 then return false end
        local override=f32(raw,0x78)
        if not override or override < -1 or override>1000000 then return false end
        for _,o in ipairs({0x164,0x1a0,0x1dc,0x3f8})do
            local positive=false
            for j=0,14 do
                local v=f32(raw,o+j*4)
                if not v or v<0 or v>10000 then return false end
                if v>0 then positive=true end
            end
            if not positive then return false end
        end
        return true
    end
    local function resolve(d)
        local handleptr=ptr(mem.read(d+0x6b0,8),0)
        local handle=handleptr and mem.read(handleptr,16)
        local function handle_stable()
            return director()==d and ptr(mem.read(d+0x6b0,8),0)==handleptr and mem.read(handleptr,16)==handle
        end
        local h=mem.read(d+0x51968,24)
        local generation=u32(handle,8);local invalid=u32(mem.read(base+0x3483c24,4),0)
        if not handle or not h or not invalid then return nil,'config_handle_unreadable' end
        if generation~=invalid then
            local tableptr=ptr(h,0);local count=u32(h,8);local sentinel=u32(h,12)
            if not count or count>4096 then return nil,'config_hash_count_invalid' end
            if count>0 then
                if not tableptr then return nil,'config_hash_pointer_invalid' end
                local map=mem.read(tableptr,count*8)
                if not map then return nil,'config_hash_unreadable' end
                local slot,index
                for i=0,count-1 do
                    if u32(map,i*8)==generation and generation~=sentinel then
                        if slot then return nil,'config_generation_duplicate' end
                        slot=tableptr+i*8;index=u32(map,i*8+4)
                    end
                end
                if index and index~=4294967295 then
                    if index>1023 then return nil,'config_index_invalid' end
                    local row=d+0x519ac+index*0x43c
                    local raw=mem.read(row,0x43c);local slotraw=mem.read(slot,8)
                    if not valid_row(raw) then return nil,'config_row_invalid' end
                    local function stable()
                        return handle_stable()
                            and mem.read(d+0x51968,24)==h and mem.read(slot,8)==slotraw
                    end
                    if not stable() then return nil,'config_changed_during_read' end
                    return {row=row,raw=raw,path='director',valid=stable,active=handle_stable,d=d}
                end
            end
        end
        local root=ptr(mem.read(base+0x346bf98,8),0)
        local slot=root and root+0xf12b18
        local tableptr=slot and ptr(mem.read(slot,8),0)
        local header=tableptr and mem.read(tableptr,0x260)
        if not header then return nil,'resource_config_unreadable' end
        local key=handle:sub(1,8);local index;local maxindex=-1
        if key==string.rep('\0',8) then return nil,'resource_key_zero' end
        for i=0,37 do
            local k=header:sub(i*16+1,i*16+8)
            if k~=string.rep('\0',8) then
                local ix=u32(header,i*16+8)
                if ix>=38 then return nil,'resource_config_index_invalid' end
                maxindex=math.max(maxindex,ix)
                if k==key then
                    if index then return nil,'resource_key_duplicate' end
                    index=ix
                end
            end
        end
        if not index then return nil,'resource_key_missing' end
        local row=tableptr+0x260+index*0x43c;local raw=mem.read(row,0x43c)
        if not valid_row(raw) then return nil,'resource_row_invalid' end
        local function stable()
            return ptr(mem.read(base+0x346bf98,8),0)==root
                and ptr(mem.read(slot,8),0)==tableptr and mem.read(tableptr,0x260)==header
        end
        if not stable() or not handle_stable() then return nil,'resource_changed_during_read' end
        if not private(row,0x43c) then
            local size=0x260+(maxindex+1)*0x43c
            local original=mem.read(tableptr,size)
            if not original or not private(slot,8) then return nil,'resource_clone_unavailable' end
            local copy=codec.clone(original)
            if not private(copy,size) or mem.read(copy,size)~=original or not stable()
                or mem.read(tableptr,size)~=original or not handle_stable() then
                return nil,'resource_clone_check_failed'
            end
            if not write(slot,codec.pointer(copy)) then return nil,'resource_clone_pointer_write_failed' end
            emit(string.format('SPAWN_TUNING_RESOURCE_CLONED bytes=%d original=0x%x copy=0x%x',size,tableptr,copy))
            return resolve(d)
        end
        return {row=row,raw=raw,path='resource',valid=stable,active=handle_stable,d=d}
    end
    local state={status='waiting',records={},last=-1,ctx=nil,halted=false}
    local function status(s)
        if state.status~=s then emit('SPAWN_TUNING_STATUS '..s);state.status=s end
    end
    local function restore()
        cleanup.stop();state.cleanup_status=cleanup.status
        local restored,skipped=0,0
        for p,r in pairs(state.records)do
            if r.valid() and mem.read(p,#r.last)==r.last then
                if write(p,r.original) then restored=restored+1 else skipped=skipped+1 end
            else skipped=skipped+1 end
        end
        state.records={};state.ctx=nil
        if restored+skipped>0 then emit(string.format('SPAWN_TUNING_RESTORE restored=%d skipped=%d',restored,skipped)) end
        return skipped==0
    end
    function state.stop()
        local ok=restore();return ok
    end
    function state.poll(mode,active,options,now,faction)
        if now-state.last<1 then return end
        state.last=now
        if state.halted then status('stopped_after_write_failure');return end
        if mode~=4 or not active or not (options.spawn_tuning or options.fast_corpses) then
            restore();status(options.spawn_tuning and 'waiting_for_active_mission' or 'disabled');return
        end
        if not build_ok() then restore();status('resolver_build_guard_mismatch');return end
        if not host() then restore();status('host_authority_unavailable');return end
        local d=director()
        if not d then restore();status('director_unavailable');return end
        if state.ctx and (state.ctx.d~=d or not state.ctx.valid()) then restore() end
        local ctx,why=resolve(d)
        if not ctx then restore();status(why);return end
        if state.ctx and state.ctx.row~=ctx.row then restore() end
        local plan={}
        local function add(p,count,scale,name,valid,optional_override)
            local live=mem.read(p,count*4);local old=state.records[p];local original,out={},{}
            if not live or not private(p,#live) then return false,name..'_not_private_writable' end
            for j=0,count-1 do
                local slice=live:sub(j*4+1,j*4+4)
                local native=old and slice==old.last:sub(j*4+1,j*4+4) and old.original:sub(j*4+1,j*4+4) or slice
                local v=f32(native,0)
                if not v or v>(count==1 and 1000000 or 10000) or v<(optional_override and -1 or 0) then return false,name..'_invalid_value' end
                local target=(optional_override and v<=0) and v or v*scale
                original[#original+1]=native;out[#out+1]=codec.float(target)
            end
            plan[#plan+1]={p=p,live=live,original=table.concat(original),last=table.concat(out),name=name,valid=valid}
            return true
        end
        local function active_valid()
            return ctx.active() and ctx.valid()
        end
        local budget_scale=options.factory_cap_paused and 0 or options.reinforce_budget_multiplier
        local patrol_scale=options.factory_cap_paused and 0.000001 or options.patrol_count_multiplier
        local entries={
            {d+0x518b0,1,budget_scale,'reinforcement_budget',active_valid},
            {ctx.row+0x78,1,budget_scale,'mission_budget_override',ctx.valid,true},
            {ctx.row+0x164,15,options.reinforce_cooldown_rate,'reinforcement_cooldown_curve',ctx.valid},
            -- Native config requires at least one positive patrol value. Keep
            -- its validated layout while effectively stopping new scheduling.
            {ctx.row+0x1a0,15,patrol_scale,'patrol_count_curve',ctx.valid},
            {ctx.row+0x3f8,15,options.patrol_size_multiplier,'patrol_size_curve',ctx.valid},
            {ctx.row+0x1dc,15,options.patrol_cooldown_rate or 1,'patrol_cooldown_curve',ctx.valid},
        }
        for _,e in ipairs(entries)do
            local ok,reason=add(e[1],e[2],e[3],e[4],e[5],e[6])
            if not ok then restore();status(reason);return end
        end
        if not active_valid() or not host() then restore();status('context_changed_before_write');return end
        for _,r in ipairs(plan)do
            if mem.read(r.p,#r.live)~=r.live then status('data_changed_before_write');return end
        end
        local changed=0
        for _,r in ipairs(plan)do
            if r.live~=r.last then
                if not active_valid() or mem.read(r.p,#r.live)~=r.live then
                    restore();status('context_changed_during_write');return
                end
                state.records[r.p]=r -- retain ownership before attempting a potentially partial write
                if not write(r.p,r.last) then
                    restore();state.halted=true;status('write_failed_'..r.name);return
                end
                changed=changed+1
            end
            state.records[r.p]=r
        end
        -- The corpse table has only been validated for the Automaton feature set.
        cleanup.poll(options.fast_corpses==true and faction~=nil,now,
            function()return active_valid()and host()end)
        state.cleanup_status=cleanup.status
        local first=not state.ctx;state.ctx=ctx;status('active')
        if changed>0 or first then
            emit(string.format('SPAWN_TUNING_APPLIED t=%.3f path=%s changed=%d cooldown_curve_scale=%.3f budget_scale=%.3f patrol_count_scale=%.3f patrol_size_scale=%.3f patrol_cooldown_scale=%.3f native_limits=unchanged',
                now,ctx.path,changed,options.reinforce_cooldown_rate,budget_scale,patrol_scale,options.patrol_size_multiplier,options.patrol_cooldown_rate or 1))
        end
    end
    return state
end



-- The vehicle target resolver keeps the same native seat layout pins.
aar_seat_capture = {guards={
  {0x56915a,'488d8330f7ee0048890520dcdb02488d8388f7ee0048890502dcdb02'},
  {0x637fb6,'4c8b4138448bf248895c241048896c24184b8b04d84b8904f04c8b49404d6bc35c496bce5c43'},
  {0x638027,'488b5748496bcb644d6bc6640f100411'},
  {0x63b1ad,'448bff49c1e7064d037d48418b2f3b2d73'},
  {0x63b1c7,'8bcde872eb99004885c00f842f0100'},
  {0x638fbd,'4c8d05cce8c001'},
  {0x63faed,'4c8d055c81c001'},
 }}

-- Factory-only selection override. Never changes shared roster rows or spawn counts.
local aar_factory_production=(function()
 local M={guards={{0x568baa,'488d8320ea750048890510dadb02'},{0x7fb9e0,'448b4910488bc2418bd0488bc84c8d0534f5a401'},{0x7f75ba,'4c69f0380200004c037148488b4940488b0cc1e84eb9d0ff488bd8498d7640'},{0x7f769c,'4589be80000000'},{0x7f90b0,'8b91800000004803465048894424788b81080100004c8b44d140ffc28991800000004c8984c188000000ff8108010000488b46484183bc01800000000872118bd3488bcee8'},{0x7f88b0,'418bc7488b84c7880000004889442478'},{0x7f8c57,'488b542478488b0dade0b202'},{0x95374c,'488b8eb0000000'}}}
 -- Preserve a 256-byte source window: 128-byte row plus adjacent context read by native spawn.
 -- Only the entity hash at +8 differs; this is not a second roster entry registered with the game.
 local function u(s,o,n)
  if not s or #s<o+n then return nil end
  local v=0;for i=n,1,-1 do v=v*256+s:byte(o+i)end;return v
 end
 local function ptr(s,o)local v=u(s,o,8);if v and v>=65536 and v<140737488355328 and v%8==0 then return v end end
 local function raw(h)return (h:gsub('..',function(c)return string.char(tonumber(c,16))end))end
 local function pack(v)local a={};for i=1,8 do a[i]=string.char(v%256);v=math.floor(v/256)end;return table.concat(a)end
 M.factory=raw('e336280d128d7ed3');M.tag=raw('bf2db62100000000');M.devastator=raw('44703d8525e563ae')
 -- Keep the native output, three infantry identities, and two Hulk identities
 -- from the reference Factory Strider production variants. Walkers and spawners
 -- remain excluded. The Firebomber variant is faction limited in that mod.
 M.choices={
  {'Native Devastator','44703d8525e563ae'},
  {'Berserker','a1f377f18a8da6a6'},
  {'Rocket Devastator','6fd3a9c30cb04796'},
  {'Heavy Devastator','ebd4d5861aa8b5f8'},
  {'Hulk Bruiser','f75864a1ce887913'},
  {'Hulk Firebomber (IC only)','92b6d8f5ad2eab6d'},
 }
 function M.new(mem,base,allocate,emit)
  local read=mem.read
  local s={summary='initializing',changed=0,clones=0,sequence=0}
  local copies,ours={},{};local last_key,last_log=nil,-100
  local function report(t,key,detail)
   s.summary=key..(detail and (' '..detail)or '')
   if s.summary~=last_key or t-last_log>=10 then
    emit(string.format('FACTORY_PRODUCTION t=%.3f %s',t,s.summary));last_key=s.summary;last_log=t
   end
  end
  for _,g in ipairs(M.guards)do
   if read(base+g[1],#g[2]/2)~=raw(g[2])then s.disabled=true;s.summary='unsupported_native_layout';emit('FACTORY_PRODUCTION '..s.summary);break end
  end
  local function stable(a,n)local b=a and read(a,n);if b and #b==n and read(a,n)==b then return b end end
  local gather=mem.gather
  local function many(list,count,size,steady)
   if gather then return gather(list,count,size,steady)end
   local out={};for i=1,count do local p=list[i];out[i]=p and(steady and stable(p,size)or read(p,size))end;return out
  end
  -- snap: the spawner manager header, owners and owner descriptors read once per frame and shared
  -- with the strider controls (see start_factory_production). Without it, the core reads them itself.
  function s.tick(t,enabled,mission,authority,choice,snap)
   if s.disabled then return end
   if not enabled or not mission or not authority then report(t,'inactive');return end
   choice=tonumber(choice)or 1
   if choice%1~=0 or not M.choices[choice]then report(t,'invalid_choice');return end
   local selected=M.choices[choice];local wanted=raw(selected[2])
   s.sequence=s.sequence+1
   local manager,h
   if snap then manager,h=snap.manager,snap.h else manager=ptr(read(base+0x33265c8,8),0);h=manager and stable(manager,0x60)end
   local cap,n=u(h,0xc,4),u(h,0x14,4)
   local owners,data=ptr(h,0x40),ptr(h,0x48)
   if not cap or cap~=128 or not n or n>cap or(n>0 and(not owners or not data))then report(t,'manager_unavailable');return end
   local ob,descs
   if snap then ob,descs=snap.ob,snap.descs else ob=n==0 and ''or stable(owners,n*8)end
   if not ob then report(t,'owners_unavailable');return end
   if not descs then
    local p={};for i=0,n-1 do p[i+1]=ptr(ob,i*8)end
    descs=many(p,n,24,true)
   end
   -- The factory records, read together.
   local fx,ra={},{}
   for i=0,n-1 do
    local d=descs[i+1]
    if d and d:sub(1,8)==M.factory then fx[#fx+1]=i;ra[#ra+1]=data+i*0x238 end
   end
   local recs=many(ra,#fx,0x238,true)
   -- The identity check before processing, done for all factories at once: manager, its header,
   -- each owner slot, each owner descriptor and each queue count must still be what was read.
   -- Every write below still runs the full per factory identity check right before writing.
   local gate={}
   if #fx>0 then
    local current=read(manager,0x60)
    local head=ptr(read(base+0x33265c8,8),0)==manager and current
     and u(current,0xc,4)==cap and u(current,0x14,4)==n
     and ptr(current,0x40)==owners and ptr(current,0x48)==data
    if head then
     local slots=read(owners,n*8)
     local oa,ca={},{}
     for k,i in ipairs(fx)do oa[k]=ptr(ob,i*8);ca[k]=ra[k]+0x108 end
     local d2=many(oa,#fx,24,false);local c2=many(ca,#fx,4,false)
     for k,i in ipairs(fx)do
      local count=u(recs[k],0x108,4)
      gate[k]=slots~=nil and ptr(slots,i*8)==oa[k] and d2[k]==descs[i+1] and u(c2[k],0,4)==count
     end
    end
   end
   -- Every selection row the factories point to, read together.
   local sa,sk={},{}
   for k=1,#fx do
    local b=recs[k];local count,cursor=u(b,0x108,4),u(b,0x80,4)
    if count and count<=16 and cursor and cursor<=8 and gate[k] then
     local function add(o)local src=ptr(b:sub(o+1,o+8),0);if src and not sk[src]then sk[src]=#sa+1;sa[#sa+1]=src end end
     for o=0x40,0x78,8 do add(o)end
     for j=0,count-1 do add(0x88+j*8)end
    end
   end
   local rows=many(sa,#sa,256,true)
   local factories,protected,failed=0,0,0
   for k,i in ipairs(fx)do
    local owner=ptr(ob,i*8);local desc=descs[i+1]
    do
     factories=factories+1
     local rec=ra[k];local b=recs[k]
     local count,cursor=u(b,0x108,4),u(b,0x80,4)
     local function identity()
      local current=read(manager,0x60)
      return ptr(read(base+0x33265c8,8),0)==manager and current
       and u(current,0xc,4)==cap and u(current,0x14,4)==n
       and ptr(current,0x40)==owners and ptr(current,0x48)==data
       and ptr(read(owners+i*8,8),0)==owner and read(owner,24)==desc
       and u(read(rec+0x108,4),0,4)==count
     end
     if not count or count>16 or not cursor or cursor>8 or not gate[k]then failed=failed+1
     else
      local offsets={};for o=0x40,0x78,8 do offsets[#offsets+1]=o end
      for j=0,count-1 do offsets[#offsets+1]=0x88+j*8 end
      local changed,bad,checked=0,0,0
      for _,o in ipairs(offsets)do
       local old=b:sub(o+1,o+8);local source=ptr(old,0)
       if source then
        local row=rows[sk[source]]
        local native=s.original
        if native and (#native~=256 or native:sub(1,16)~=M.tag..M.devastator or u(native,0x10,4)~=1 or u(native,0x14,4)~=1)then native=nil end
        if not row or row:sub(1,8)~=M.tag or (not native and (choice~=1 or u(row,0x10,4)~=1 or u(row,0x14,4)~=1)) then bad=bad+1
        else
         checked=checked+1
         local preserved=native and (native:sub(1,8)..wanted..native:sub(17))
             or (row:sub(1,8)..wanted..row:sub(17))
         if row~=preserved then
          local replacement=copies[preserved]
          if not replacement then
           if s.clones>=32 then bad=bad+1
           else
            replacement=allocate(preserved)
            if replacement and stable(replacement,256)==preserved then
             copies[preserved]=replacement;ours[replacement]=preserved;s.clones=s.clones+1
            else replacement=nil;bad=bad+1 end
           end
          end
          if replacement then
           if identity() and read(rec+o,8)==old and read(source,256)==row
             and read(replacement,256)==preserved and mem.writable(rec+o,8)
             and mem.write(rec+o,pack(replacement)) then changed=changed+1
           else bad=bad+1 end
          end
         elseif ours[source] and ours[source]~=row then bad=bad+1 end
        end
       elseif old~=string.rep('\0',8)then bad=bad+1 end
      end
      s.changed=s.changed+changed
      if bad==0 and checked>0 then protected=protected+1 else failed=failed+1 end
      if changed>0 or bad>0 then
       local key=string.format('%d:%d:%d',u(desc,8,4),changed,bad)
       if changed>0 or s.last_issue~=key then
        emit(string.format('FACTORY_PRODUCTION t=%.3f entity=%d selection_pointers_changed=%d queued=%d checked=%d unresolved=%d',t,u(desc,8,4),changed,count,checked,bad))
       end
       s.last_issue=key
      end
     end
    end
   end
   report(t,'active',string.format('choice=%s factories=%d protected=%d unresolved=%d total_pointer_changes=%d preserved_rows=%d',selected[1],factories,protected,failed,s.changed,s.clones))
  end
  return s
 end
 return M
end)()

local function start_factory_production(mem,emit)
 local ffi=require('ffi');local base=mem.module('game.dll')
 if not base then return nil end
 pcall(ffi.cdef,'void *VirtualAlloc(void *, size_t, uint32_t, uint32_t);')
 pcall(ffi.cdef,'uint64_t GetTickCount64(void);')
 local win=ffi.load('kernel32');local page,used=nil,0
 local function allocate(bytes)
  if not page then
   local p=win.VirtualAlloc(nil,8192,0x3000,0x04)
   if p==nil then return nil end
   page=tonumber(ffi.cast('uintptr_t',p))
  end
  if #bytes~=256 or used+256>8192 then return nil end
  local a=page+used;used=used+256
  if not mem.write(a,bytes)then return nil end
  -- Process-lifetime allocation: native queues may retain these row pointers.
  -- It must not be freed by Lua GC, mission changes, or a config reload.
  return a
 end
 local core=aar_factory_production.new(mem,base,allocate,emit)
 local striders=aar_strider_controls.new(mem,base,emit)
 local function u(s,o,n)
  if not s or #s<o+n then return nil end
  local v=0;for i=n,1,-1 do v=v*256+s:byte(o+i)end;return v
 end
 local function ptr(s,o)local v=u(s,o,8);if v and v>=65536 and v<140737488355328 and v%8==0 then return v end end
 local function authority()
  -- Same owner/map authority evidence used by the existing reinforcement reader.
  -- No readiness, cooldown, squad-size or lobby-privacy requirement.
  local r=ptr(mem.read(base+0x3326d60,8),0);local h=r and mem.read(r,0x88)
  local cap=u(h,0x70,4);local descriptor,slots=ptr(h,0x80),ptr(h,0x68)
  if not cap or cap<1 or cap>16 or not descriptor or not slots then return false end
  local d=mem.read(descriptor,24);local map=mem.read(slots,cap*8)
  if not d or not map or u(d,20,4)%2~=1 or u(d,8,4)==u(h,0x74,4)then return false end
  for i=0,cap-1 do
   if u(map,i*8,4)==u(d,8,4)then return u(map,i*8+4,4)==0 end
  end
  return false
 end
 -- One read of the spawner manager per frame for both users: header and owners (each read twice,
 -- as before) and every owner descriptor (batched). Both modules apply their own checks to it.
 local function spawner_snapshot()
  local manager=ptr(mem.read(base+0x33265c8,8),0)
  local function stable(a,n)local b=a and mem.read(a,n);if b and #b==n and mem.read(a,n)==b then return b end end
  local h=manager and stable(manager,0x60)
  local snap={manager=manager,h=h}
  local cap,n,owners=u(h,0xc,4),u(h,0x14,4),ptr(h,0x40)
  if cap==128 and n and n<=cap and(n==0 or owners)then
   snap.ob=n==0 and ''or stable(owners,n*8)
   if snap.ob then
    local p={};for i=0,n-1 do p[i+1]=ptr(snap.ob,i*8)end
    if mem.gather then snap.descs=mem.gather(p,n,24,true)
    else snap.descs={};for i=1,n do snap.descs[i]=p[i]and stable(p[i],24)end end
   end
  end
  return snap
 end
 return {core=core,striders=striders,tick=function(enabled,mission,disable_production,production_choice)
  local now=tonumber(win.GetTickCount64())/1000;local auth=mission and authority()
  local core_on=enabled and not disable_production
  local snap=mission and auth and((core_on and not core.disabled)or not striders.disabled)and spawner_snapshot()or nil
  core.tick(now,core_on,mission,auth,production_choice,snap)
  striders.tick(now,disable_production,mission,auth,snap)
 end}
end

-- Pure settings model. No game writes; Save Tab delegates to the existing ship reload.
local aar_panel_model=(function()
 local M={}
 M.master={
  {key='enabled',label='Enable whole mod',kind='toggle'},
  {key='reinforce_budget_multiplier',label='Reinforcement budget multiplier',min=1,max=6,step=.05},
  {key='reinforce_cooldown_reduction',label='Reinforcement cooldown reduction %',min=0,max=90,step=1},
  {key='patrol_count_multiplier',label='Patrol count multiplier',min=1,max=6,step=.05},
  {key='patrol_size_multiplier',label='Patrol size multiplier',min=1,max=2,step=.05},
  {key='patrol_cooldown_rate',label='Patrol cooldown rate (higher = faster)',min=1,max=6,step=.05},
  {key='fast_corpses',label='Fast corpse cleanup (keep ragdolls)',kind='toggle'},
 }
 M.faction={
  {key='any_bot_calls',label='Other ground bots can call reinforcements',kind='toggle'},
  {key='factory_strider_calls',label='Regular Factory Striders can call',kind='toggle'},
  {key='factory_strider_cap',label='Factory Strider population limit',min=1,max=30,step=1},
  {key='disable_factory_production',label='Disable Factory Strider production',kind='toggle'},
  {key='factory_production_unit',label='Factory Strider output (experimental)',kind='production'},
  {key='drop_cost_divisor',label='Bot drop cost reduction (divide by)',min=1,max=20,step=1},
  {key='patrol_extra_troopers',label='Extra troopers per patrol',choices={0,2,3,4}},
 }
 M.terminid={
  {key='bug_alpha_summon',label='Alpha Commander can summon',kind='toggle',default=true},
  {key='bug_alpha_unit',label='Alpha Commander summoned unit',kind='enum',options={'Random (per mission)','Hunter MK3','Charger','Charger Behemoth MK2','Stalker','Nursing Spewer MK2','Shrieker','Alpha Commander','Alpha Warrior','Spore Charger','Bile Titan','Impaler'},default=9},
  {key='bug_breach_cost',label='Bug breach unit cost multiplier',min=0.25,max=1.5,step=0.05,default=1},
  {key='bug_breach_equalize_costs',label='Equalize breach unit costs (experimental)',kind='toggle',default=false},
  {key='bug_titan_replacement',label='Bile Titan replacement',kind='enum',options={'Mission default','Keep Bile Titans','Dragonroach (native missions)'},default=1},
  {key='bug_titan_cap',label='Titan / Dragonroach population limit',min=1,max=30,step=1,default=27},
  {key='bug_titan_resume_below',label='Resume Titan-class spawns below',min=1,max=30,step=1,default=20},
  {key='bug_charger_calls',label='Chargers and variants can call breaches',kind='toggle',default=false},
  {key='bug_shrieker_calls',label='Shriekers can call breaches',kind='toggle',default=false},
  {key='bug_stalker_calls',label='Stalkers can call breaches',kind='toggle',default=false},
  {key='bug_titan_calls',label='Bile Titans can call breaches',kind='toggle',default=false},
  {key='bug_call_cloud',label='Calling cloud on non-native callers',kind='toggle',default=false},
 }
 M.illuminate={
  {key='illuminate_calls',label='Other Illuminate units can call reinforcements',kind='toggle',default=true},
  {key='illuminate_keep_native_watcher_patrols',label='Keep native solo Watcher patrols',kind='toggle',default=true},
  {key='illuminate_drop_cost_divisor',label='Warp Ship reinforcement cost reduction (divide by)',min=1,max=20,step=1,default=1},
  {key='disable_leviathans',label='Disable Leviathan roster spawns (experimental)',kind='toggle',default=false},
 }
 function M.faction_rows(faction)return faction=='automaton' and M.faction or faction=='terminid' and M.terminid or M.illuminate end
 local function clone(t)local o={};for k,v in pairs(t)do o[k]=type(v)=='table'and clone(v)or v end;return o end
 function M.new(mix,profile,commit,faction)
  local patrol_rows=mix.units
  local s={page=0,selected=1,revision=0,dirty=false,message='Settings apply on the ship.',faction=faction or 'automaton'}
  local function copy_page(dst,src,page)
   if page==0 then for _,r in ipairs(M.master)do dst[r.key]=src[r.key]end
    elseif page==5 then for _,r in ipairs(M.faction_rows(s.faction))do dst[r.key]=src[r.key]end
    else
    local key=mix.sources[page].key
    dst.mixes[key]=clone(src.mixes[key]);dst.vanilla[key]=src.vanilla[key];dst.initialized[key]=src.initialized[key]
    
   end
  end
  function s.page_dirty(page)
   page=page or s.page
   if page==0 then for _,r in ipairs(M.master)do if s.draft[r.key]~=s.saved[r.key]then return true end end
    elseif page==5 then
     for _,r in ipairs(M.faction_rows(s.faction))do if s.draft[r.key]~=s.saved[r.key]then return true end end
    else
    local key=mix.sources[page].key
    if s.draft.vanilla[key]~=s.saved.vanilla[key]or s.draft.initialized[key]~=s.saved.initialized[key]then return true end
    for _,u in ipairs(mix.units)do if s.draft.mixes[key][u[1]]~=s.saved.mixes[key][u[1]]then return true end end
    
   end
   return false
  end
   local function dirty()s.revision=s.revision+1;s.dirty=false;for page=0,5 do if s.page_dirty(page)then s.dirty=true end end end
   function s.refresh_dirty()dirty()end
  function s.load(p,force)
   local incoming={enabled=not p.disabled_by_menu,any_bot_calls=p.hulk_calls,
    factory_strider_cap=p.factory_strider_cap or 15,disable_factory_production=p.disable_factory_production==true,factory_production_unit=p.factory_production_unit or 1,factory_strider_calls=p.factory_strider_calls~=false,
    reinforce_budget_multiplier=p.reinforce_budget_multiplier,reinforce_cooldown_reduction=p.reinforce_cooldown_reduction,
    patrol_count_multiplier=p.patrol_count_multiplier or p.spawn_multiplier or 1.15,
    patrol_size_multiplier=p.patrol_size_multiplier or p.spawn_multiplier or 1.15,
    patrol_cooldown_rate=p.patrol_cooldown_rate or 1,fast_corpses=p.fast_corpses==true,drop_cost_divisor=p.drop_cost_divisor or 1,patrol_extra_troopers=p.patrol_extra_troopers or 0,mixes=clone(p.mixes),vanilla=clone(p.mix_vanilla),initialized=clone(p.mix_initialized or {})}
   for _,r in ipairs(M.terminid)do local v=p[r.key];if v==nil then v=r.default end;incoming[r.key]=v end
   for _,r in ipairs(M.illuminate)do local v=p[r.key];if v==nil then v=r.default end;incoming[r.key]=v end
   s.active=clone(incoming);s.revision=s.revision+1
   if s.dirty and not force then return end
   s.saved=incoming;s.draft=clone(s.saved);s.dirty=false

  end
  function s.active_enabled(page)
   page=page or s.page
   if page==4 then return false end
   return s.active.enabled and (page==0 or page==5 or (page>=1 and page<=3 and not s.active.vanilla[mix.sources[page].key]))
  end
  function s.pending(page)
   page=page or s.page
   if page==0 then
     for _,row in ipairs(M.master)do if s.saved[row.key]~=s.active[row.key]then return true end end
    elseif page==5 then
     for _,row in ipairs(M.faction_rows(s.faction))do if s.saved[row.key]~=s.active[row.key]then return true end end
    else
    local key=mix.sources[page].key
    if s.saved.vanilla[key]~=s.active.vanilla[key]then return true end
    for _,u in ipairs(mix.units)do if s.saved.mixes[key][u[1]]~=s.active.mixes[key][u[1]]then return true end end
    
   end
   return false
  end
  function s.slider_range(i)
   local row=s.rows()[i]
   if not row or row.kind=='toggle'or row.kind=='production'or row.kind=='enum'or row.choices then return end
   if s.page==0 or s.page==5 then return row.min,row.max,row.step end
   return 0,100,1
  end
  function s.slide(i,ratio)
   local lo,hi,step=s.slider_range(i)
   if not lo or not s.tab_enabled()then return false end
   ratio=math.max(0,math.min(1,ratio))
   local value=lo+math.floor((hi-lo)*ratio/step+.5)*step
   value=math.max(lo,math.min(hi,math.floor(value*10000+.5)/10000))
   if value==s.value(i)then return true end
   return s.set(i,value)
  end
  local no_rows={}
  -- Test38: page 4 is the read-only Rules page (it replaced POIs / Nests).
  function s.rows()return s.page==0 and M.master or s.page==5 and M.faction_rows(s.faction) or s.page==4 and no_rows or mix.rows_for_source(s.source()) end
  function s.source()return s.page>=1 and s.page<=3 and mix.sources[s.page].key end
  function s.tab_enabled()
   if s.page==0 then return true end
   if s.page==5 then return true end
   if s.page==4 then return false end
   return not s.draft.vanilla[s.source()]
  end
  function s.value(i)
   local row=s.rows()[i];if not row then return end
   if s.page==0 or s.page==5 or row.choices then return s.draft[row.key]end
   return s.draft.mixes[s.source()][row[1]]
  end
  function s.set(i,value)
   local row=s.rows()[i];if not row then return false end
   if not s.tab_enabled()then s.message='Enable this tab before changing its custom settings.';return false end
   if row.choices then
    value=tonumber(value);local valid=false
    for _,choice in ipairs(row.choices)do if choice==value then valid=true end end
    if not valid then s.message='Choose 0, 2, 3 or 4 extra troopers.';return false end
    s.draft[row.key]=value
       elseif s.page==0 or s.page==5 then
    if row.kind=='toggle'then if type(value)~='boolean'then return false end
    elseif row.kind=='enum'then
     value=tonumber(value);if not value or value%1~=0 or not row.options[value]then return false end
    elseif row.kind=='production'then
     value=tonumber(value)
     if not value or value%1~=0 or not aar_factory_production.choices[value]then
      s.message='Choose a listed Factory Strider output.';return false
     end
    else
     value=tonumber(value)
     if not value or value~=value or value<row.min or value>row.max then s.message='Value is outside the allowed range.';return false end
     value=math.floor((value-row.min)/row.step+.5)*row.step+row.min
     value=math.floor(value*10000+.5)/10000
    end
    s.draft[row.key]=value
    if row.key=='bug_titan_cap' then
     s.draft.bug_titan_resume_below=math.min(s.draft.bug_titan_resume_below or 20,value)
    elseif row.key=='bug_titan_resume_below' then
     s.draft.bug_titan_resume_below=math.min(value,s.draft.bug_titan_cap or 27)
    end
   else
    value=tonumber(value)
    if not value or value~=value or value<0 or value>100 then s.message='Enter a percentage from 0 to 100.';return false end
    s.draft.mixes[s.source()][row[1]]=value;s.draft.initialized[s.source()]=true
   end
   s.selected=i;dirty();s.message='Unsaved tab changes. Save Tab balances to 100%; mission changes wait for the ship.';return true
  end
  function s.adjust(i,direction,fast)
   local row=s.rows()[i];if not row then return false end
   if row.choices then
    for n,value in ipairs(row.choices)do if value==s.value(i)then return s.set(i,row.choices[math.max(1,math.min(#row.choices,n+direction))])end end
   end
   if row.kind=='enum'then return s.set(i,math.max(1,math.min(#row.options,s.value(i)+direction)))end
   if (s.page==0 or s.page==5) and row.kind=='production'then
    return s.set(i,math.max(1,math.min(#aar_factory_production.choices,s.value(i)+direction*(fast and 5 or 1))))
   end
   if (s.page==0 or s.page==5) and row.kind=='toggle'then return s.set(i,not s.value(i))end
   local lo,hi,step=0,100,1
   if s.page==0 or s.page==5 then lo,hi,step=row.min,row.max,row.step end
   return s.set(i,math.max(lo,math.min(hi,s.value(i)+direction*step*(fast and 10 or 1))))
  end
  function s.set_tab_enabled(enabled)
   local source=s.source();if not source then return false end
   if type(enabled)~='boolean'then return false end
   if enabled and not s.draft.initialized[source]then
    local values={};for i,u in ipairs(mix.units)do values[u[1]]=i==1 and 100 or 0 end
    s.draft.mixes[source]=values;s.draft.initialized[source]=true
   end
   s.draft.vanilla[source]=not enabled;dirty()
   s.message=enabled and 'Tab enabled. Save Tab to use the custom settings.'or 'Tab disabled. Save Tab to use game weights; custom settings are remembered.';return true
  end
  function s.cost_text()
   local source=s.source();if not source then return ''end
   local divisor=source=='drops' and (mix.is_illuminate and s.draft.illuminate_drop_cost_divisor or s.draft.drop_cost_divisor) or nil
   local before,after=mix.weighted_cost(s.draft.mixes[source],divisor)
    if not before then return mix.is_bug and 'Cost preview available after a live Terminid roster is loaded.' or 'Cost preview pending: Save Tab balances weights to 100%.'end
   if mix.is_bug and source=='drops'then after=before*(s.draft.bug_breach_cost or 1)end
   local function fmt(n)return string.format('%.2f',n):gsub('%.?0+$','')end
   if mix.is_bug and source=='drops' and s.draft.bug_breach_equalize_costs then
    return 'Equalized unit cost preview: '..fmt(before)..' -> '..fmt(math.max(0.01,after))..' (eligible mix may differ)'
   end
   return (s.tab_enabled()and 'Weighted base cost: 'or 'Saved mix cost preview: ')..fmt(before)..(source=='drops'and(' -> '..fmt(after))or '')
  end
  function s.total()
   if not s.source()then return end
   local total=0;for _,u in ipairs(mix.units)do total=total+(s.draft.mixes[s.source()][u[1]]or 0)end;return total
  end
  function s.change_page(n)
   n=math.max(0,math.min(5,n))
   s.page=n
   s.selected=1
  end
    function s.copy_shared(other)
   for _,r in ipairs(M.master)do
    local k=r.key
    other.draft[k]=s.draft[k];other.saved[k]=s.saved[k];other.active[k]=s.active[k]
   end
   other.refresh_dirty()
  end
  function s.discard()
   if s.page==4 then return end
   copy_page(s.draft,s.saved,s.page);dirty();s.message='Unapplied changes on this tab discarded.'
  end
  function s.apply()
   if s.page==4 then s.message='Rules is a read-only page.';return false end
   local source=s.source();local candidate=clone(s.saved);copy_page(candidate,s.draft,s.page)
   local equalized=false
      if source then
    local values=candidate.mixes[source];local selected={};local total=0
    for key in pairs(values)do if not mix.allowed(source,key)then values[key]=0 end end
    for _,u in ipairs(mix.units)do
     local v=values[u[1]]or 0
     if type(v)~='number'or v~=v or v<0 or v>100 then s.message='Enter percentages from 0 to 100.';return false end
     total=total+v;if v>0 then selected[#selected+1]=u[1]end
    end
    if total>0 and math.abs(total-100)>1e-7 then
     local each=math.floor(100/#selected);local remainder=100-each*#selected
     for i,key in ipairs(selected)do values[key]=each+(i<=remainder and 1 or 0)end
     equalized=true
    elseif not mix.normalize(values)then
     s.message=string.format('%s totals %.2f%%. Select at least one unit before saving. Nothing saved.',mix.sources[s.page].label,total);return false
    end
   end
   local ok,message=commit(candidate,s.page,mix,s.faction)
   if not ok then s.message=message or 'Could not save this tab.';return false end
   copy_page(s.saved,candidate,s.page);copy_page(s.draft,candidate,s.page);dirty()
   s.message=(source and mix.sources[s.page].label or s.page==5 and 'Faction' or 'Master')..(equalized and ' saved: weights split equally to 100% across selected units.'or ' saved.')..' Other tabs keep their drafts. Applies on ship.';return true
  end
  s.load(profile,true)
  return s
 end
 return M
end)()

-- Callback-free Windows input ownership for the in-game panel.
-- No game-code patch and no Lua callback on the window thread. The native
-- procedure forwards unrelated messages and cleans up consumed WM_INPUT.
local function new_panel_input(ffi,U,K,trace)
 local function bind(lib,name,signature)
  local module=K.GetModuleHandleA(lib)
  local address=module~=nil and K.GetProcAddress(module,name)or nil
  assert(address~=nil,'Missing Windows input function '..name)
  return ffi.cast(signature,address)
 end
 for _,decl in ipairs({
  'void* GetModuleHandleA(const char*);','void* GetProcAddress(void*,const char*);'
 })do pcall(ffi.cdef,decl)end
 local get=bind('user32.dll','GetWindowLongPtrW','intptr_t(*)(void*,int)')
 local set=bind('user32.dll','SetWindowLongPtrW','intptr_t(*)(void*,int,intptr_t)')
 local alloc=bind('kernel32.dll','VirtualAlloc','void*(*)(void*,size_t,uint32_t,uint32_t)')
 local protect=bind('kernel32.dll','VirtualProtect','int(*)(void*,size_t,uint32_t,void*)')
 local free=bind('kernel32.dll','VirtualFree','int(*)(void*,size_t,uint32_t)')
 local flush=bind('kernel32.dll','FlushInstructionCache','int(*)(void*,const void*,size_t)')
 local clip=bind('user32.dll','ClipCursor','int(*)(const void*)')
 local getclip=bind('user32.dll','GetClipCursor','int(*)(void*)')
 local call=K.GetProcAddress(K.GetModuleHandleA('user32.dll'),'CallWindowProcW')
 local def=K.GetProcAddress(K.GetModuleHandleA('user32.dll'),'DefWindowProcW')
 assert(call~=nil and def~=nil,'Window forwarding API unavailable')
 local filters={};local active;local saved_clip=ffi.new('int32_t[4]');local clipped=false
 -- Generated from Development/panel_input_filter.s. Data and code occupy
 -- separate pages: data stays RW; code becomes RX before Windows sees it.
 local bytes={0x83,0xfa,0x08,0x74,0x0a,0x83,0xfa,0x1c,0x75,0x11,0x4d,0x85,0xc0,0x75,0x0c,0x41,0xc7,0x02,0x00,0x00,0x00,0x00,0xe9,0xa9,0x00,0x00,0x00,0x81,0xfa,0x00,0x01,0x00,0x00,0x74,0x08,0x81,0xfa,0x01,0x01,0x00,0x00,0x75,0x1c,0x41,0x83,0xf8,0x76,0x0f,0x84,0x8f,0x00,0x00,0x00,0x41,0x83,0xf8,0x37,0x74,0x06,0x41,0x83,0xf8,0x67,0x75,0x06,0x41,0x83,0x3a,0x02,0x74,0x7d,0x8d,0x82,0xff,0xfd,0xff,0xff,0x83,0xf8,0x08,0x77,0x34,0x45,0x31,0xdb,0x83,0xf8,0x03,0x72,0x11,0x41,0xff,0xc3,0x83,0xe8,0x03,0x83,0xf8,0x03,0x72,0x06,0x41,0xff,0xc3,0x83,0xe8,0x03,0x83,0xf8,0x01,0x74,0x0d,0x41,0x83,0x3a,0x00,0x75,0x71,0x45,0x0f,0xab,0x5a,0x04,0xeb,0x47,0x45,0x0f,0xb3,0x5a,0x04,0x72,0x40,0xeb,0x61,0x41,0x83,0x3a,0x00,0x74,0x38,0x81,0xfa,0xff,0x00,0x00,0x00,0x74,0x4f,0x81,0xfa,0x00,0x01,0x00,0x00,0x74,0x4b,0x81,0xfa,0x02,0x01,0x00,0x00,0x74,0x43,0x81,0xfa,0x03,0x01,0x00,0x00,0x74,0x3b,0x81,0xfa,0x09,0x01,0x00,0x00,0x74,0x33,0x81,0xfa,0x00,0x02,0x00,0x00,0x72,0x08,0x81,0xfa,0x0e,0x02,0x00,0x00,0x76,0x23,0x48,0x83,0xec,0x38,0x4c,0x89,0x4c,0x24,0x20,0x4d,0x89,0xc1,0x41,0x89,0xd0,0x48,0x89,0xca,0x49,0x8b,0x4a,0x08,0x41,0xff,0x52,0x10,0x48,0x83,0xc4,0x38,0xc3,0x41,0xff,0x62,0x18,0x31,0xc0,0xc3}
 local s={}
 local function install(window)
  local key=tostring(window) -- FFI pointer table keys otherwise compare by identity.
  if filters[key]then return filters[key]end
  local previous=get(window,-4);assert(previous~=0,'Game window has no procedure')
  local block=alloc(nil,8192,0x3000,0x04);assert(block~=nil,'Input filter allocation failed')
  local b=ffi.cast('uint8_t*',block);local q=ffi.cast('uint64_t*',block)
  local u=ffi.cast('volatile uint32_t*',block)
  q[1]=ffi.cast('uint64_t',previous);q[2]=ffi.cast('uint64_t',call);q[3]=ffi.cast('uint64_t',def)
  local held=0;for i,vk in ipairs({1,2,4})do if U.GetAsyncKeyState(vk)<0 then held=held+2^(i-1)end end;u[1]=held
  local code=b+4096;code[0]=0x49;code[1]=0xBA
  ffi.cast('uint64_t*',code+2)[0]=ffi.cast('uint64_t',block)
  for i,v in ipairs(bytes)do code[i+9]=v end
  local old=ffi.new('uint32_t[1]')
  if protect(code,4096,0x20,old)==0 or flush(ffi.cast('void*',-1),code,#bytes+10)==0 then
   free(block,0,0x8000);error('Input filter protection failed')
  end
  local entry=ffi.cast('intptr_t',code);local replaced=set(window,-4,entry)
  if replaced==0 then free(block,0,0x8000);error('Windows refused game input capture')end
  q[1]=ffi.cast('uint64_t',replaced)
  local f={flag=u,block=block,window=window};filters[key]=f
  -- Keep this forwarding procedure until process exit: another addon may
  -- subclass after us. Never free code that could remain in its chain.
  trace('input_filter_installed callback_free=true');return f
 end
 function s.hold(window,now,allow_reroller_digit)
  local f=active and active.window==window and active or install(window)
  if active and active~=f then active.flag[0]=0 end
  local changed=active~=f;active=f
  if not clipped then clipped=getclip(saved_clip)~=0 end
  if changed or not now or now>=(f.next_clip or 0)then clip(nil);f.next_clip=(now or 0)+250 end
  local target=allow_reroller_digit and 2 or 1
  if f.flag[0]~=target then f.flag[0]=target end
 end
 function s.set_digit_passthrough(allow)
  if active then active.flag[0]=allow and 2 or 1 end
 end
 function s.release(restore_clip)
  if active then active.flag[0]=0;active=nil end
  if clipped then if restore_clip==false then clip(nil)else clip(saved_clip)end;clipped=false end
 end
 return s
end

-- In-game Stingray screen GUI. UI approach adapted from the user-supplied
-- HD2 Custom Mission Creator v1.0.1 by cheese; no native window or callbacks.
-- Bingus Mod Bindings Menu v2+: automatic native action, saved by the game.
local function new_panel_binding(emit)
 local id='feroz.pick_your_bots.open_settings'
 local seen,down=nil,false
 local M={registered=false}
 function M.poll()
  local menu=rawget(_G,'ModBindingsMenu')
  if menu==seen then return end
  seen=menu;down=false;M.registered=false
  if type(menu)~='table' or menu.api~=1 or type(menu.version)~='number'
    or menu.version<2 or type(menu.register_binding)~='function' then return end
  local called,ok,reason=pcall(menu.register_binding,id,'Open settings',nil,
    {category='Pick Your Bots / Bugs / Squids'})
  M.registered=called and ok==true
  emit(M.registered and 'binding_registered open_settings unassigned_by_default=true'
    or 'binding_unavailable '..tostring(called and reason or ok))
 end
 function M.pressed()
  if not M.registered or rawget(_G,'ModBindingsMenu')~=seen then down=false;return false end
  if type(seen.is_down)~='function' then down=false;return false end
  local ok,value=pcall(seen.is_down,id)
  if not ok or type(value)~='boolean' then down=false;return false end
  local hit=value and not down;down=value;return hit
 end
 return M
end

local function start_aar_panel(models,mixes,emit,mem)
 local model,mix=models.automaton,mixes.automaton
-- Automaton emblem geometry, adapted from KaijuLover1954 / Arrowhead.
-- CC BY-SA 4.0 for this emblem asset. See Assets/ATTRIBUTION.txt.
-- BEGIN GENERATED FACTION EMBLEMS
local helldiver_emblem={
 {28,0,4,1,1},
 {25,1,10,1,1},
 {22,2,16,1,1},
 {19,3,22,1,1},
 {16,4,28,1,1},
 {13,5,34,1,1},
 {10,6,40,1,1},
 {7,7,46,1,1},
 {6,8,48,1,1},
 {7,9,46,15,1},
 {8,24,44,5,1},
 {8,29,7,1,1},
 {20,29,20,1,1},
 {45,29,7,1,1},
 {8,30,5,1,1},
 {21,30,18,1,1},
 {47,30,5,1,1},
 {7,31,5,1,1},
 {22,31,16,1,1},
 {48,31,5,1,1},
 {6,32,6,1,1},
 {23,32,14,6,1},
 {48,32,6,1,1},
 {5,33,6,1,1},
 {48,33,7,1,1},
 {4,34,7,2,1},
 {49,34,6,1,1},
 {49,35,7,1,1},
 {3,36,9,1,1},
 {48,36,9,1,1},
 {1,37,11,1,1},
 {48,37,10,1,1},
 {1,38,12,1,1},
 {22,38,16,1,1},
 {47,38,12,1,1},
 {1,39,13,1,1},
 {21,39,18,1,1},
 {46,39,12,1,1},
 {2,40,14,1,1},
 {19,40,22,1,1},
 {44,40,14,1,1},
 {3,41,54,1,1},
 {4,42,25,1,1},
 {31,42,25,1,1},
 {5,43,23,1,1},
 {32,43,23,1,1},
 {6,44,22,1,1},
 {32,44,22,1,1},
 {7,45,20,1,1},
 {33,45,20,1,1},
 {7,46,19,1,1},
 {29,46,2,2,1},
 {34,46,19,1,1},
 {8,47,19,1,1},
 {33,47,19,1,1},
 {9,48,6,1,1},
 {17,48,26,1,1},
 {45,48,6,1,1},
 {10,49,2,1,1},
 {18,49,24,4,1},
 {48,49,2,1,1},
 {19,53,22,3,1},
 {20,56,20,1,1},
 {22,57,16,1,1},
 {25,58,10,1,1},
 {29,59,2,1,1},
}
local terminid_emblem={
 {47,1,1,1,1},
 {48,2,1,1,1},
 {48,3,2,1,1},
 {48,4,3,1,1},
 {48,5,4,1,1},
 {49,6,4,2,1},
 {49,8,5,1,1},
 {49,9,6,2,1},
 {27,11,3,1,1},
 {49,11,7,2,1},
 {25,12,4,1,1},
 {23,13,5,1,1},
 {49,13,8,2,1},
 {22,14,6,1,1},
 {20,15,7,1,1},
 {49,15,9,3,1},
 {19,16,8,1,1},
 {18,17,8,1,1},
 {17,18,9,1,1},
 {48,18,11,3,1},
 {16,19,10,1,1},
 {15,20,11,2,1},
 {47,21,12,1,1},
 {14,22,12,1,1},
 {47,22,13,1,1},
 {13,23,13,2,1},
 {46,23,14,1,1},
 {45,24,15,2,1},
 {12,25,14,2,1},
 {44,26,16,1,1},
 {12,27,15,1,1},
 {43,27,17,1,1},
 {11,28,16,1,1},
 {42,28,18,1,1},
 {11,29,17,2,1},
 {41,29,19,1,1},
 {40,30,20,1,1},
 {10,31,19,2,1},
 {39,31,21,1,1},
 {38,32,22,1,1},
 {10,33,16,1,1},
 {36,33,23,1,1},
 {10,34,13,1,1},
 {34,34,25,1,1},
 {10,35,10,1,1},
 {32,35,27,1,1},
 {10,36,8,1,1},
 {28,36,30,1,1},
 {10,37,6,1,1},
 {24,37,34,1,1},
 {10,38,5,1,1},
 {22,38,36,1,1},
 {10,39,3,1,1},
 {20,39,37,1,1},
 {10,40,2,1,1},
 {18,40,39,1,1},
 {16,41,40,1,1},
 {15,42,41,1,1},
 {13,43,42,1,1},
 {12,44,42,1,1},
 {11,45,43,1,1},
 {9,46,44,1,1},
 {8,47,44,1,1},
 {7,48,44,1,1},
 {6,49,44,1,1},
 {5,50,44,2,1},
 {4,52,43,1,1},
 {3,53,9,1,1},
 {2,54,6,1,1},
 {2,55,4,1,1},
 {1,56,3,1,1},
 {1,57,1,1,1},
}
local illuminate_emblem={
 {26,0,8,1,1},
 {23,1,14,1,1},
 {22,2,16,1,1},
 {20,3,19,1,1},
 {19,4,22,2,1},
 {18,6,24,1,1},
 {17,7,26,2,1},
 {16,9,28,10,1},
 {8,10,1,1,1},
 {51,10,1,1,1},
 {7,11,2,1,1},
 {51,11,2,1,1},
 {6,12,3,1,1},
 {51,12,3,1,1},
 {5,13,4,2,1},
 {51,13,4,2,1},
 {4,15,5,2,1},
 {51,15,5,2,1},
 {3,17,6,2,1},
 {51,17,6,2,1},
 {2,19,8,2,1},
 {17,19,26,2,1},
 {50,19,8,2,1},
 {1,21,9,1,1},
 {18,21,24,1,1},
 {50,21,9,1,1},
 {1,22,10,2,1},
 {19,22,22,2,1},
 {49,22,10,2,1},
 {1,24,11,1,1},
 {20,24,20,1,1},
 {48,24,11,1,1},
 {0,25,13,2,1},
 {22,25,16,1,1},
 {47,25,13,2,1},
 {23,26,14,1,1},
 {0,27,14,1,1},
 {26,27,8,1,1},
 {46,27,14,1,1},
 {0,28,15,1,1},
 {45,28,15,1,1},
 {0,29,16,1,1},
 {44,29,16,1,1},
 {0,30,17,1,1},
 {43,30,17,1,1},
 {0,31,19,1,1},
 {41,31,19,1,1},
 {0,32,21,1,1},
 {39,32,21,1,1},
 {0,33,24,1,1},
 {36,33,24,1,1},
 {0,34,60,3,1},
 {1,37,58,3,1},
 {2,40,56,3,1},
 {3,43,54,2,1},
 {4,45,52,1,1},
 {5,46,50,2,1},
 {6,48,48,1,1},
 {7,49,46,1,1},
 {8,50,44,1,1},
 {9,51,42,1,1},
 {10,52,40,1,1},
 {11,53,38,1,1},
 {12,54,36,1,1},
 {14,55,32,1,1},
 {15,56,30,1,1},
 {17,57,26,1,1},
 {20,58,20,1,1},
 {23,59,14,1,1},
}
-- END GENERATED FACTION EMBLEMS
local automaton_emblem={
 {29,0,6,5,1},
 {20,2,3,1,1},
 {41,2,3,1,1},
 {17,3,6,1,1},
 {40,3,7,2,1},
 {17,4,7,1,1},
 {18,5,28,2,1},
 {18,7,27,1,1},
 {10,8,3,1,1},
 {18,8,28,1,1},
 {51,8,3,1,1},
 {9,9,5,1,1},
 {16,9,31,1,1},
 {50,9,5,1,1},
 {8,10,19,1,1},
 {28,10,8,1,2},
 {37,10,19,1,1},
 {8,11,16,1,1},
 {24,11,16,1,2},
 {40,11,16,1,1},
 {8,12,14,1,1},
 {22,12,20,1,2},
 {42,12,14,1,1},
 {9,13,11,1,1},
 {20,13,24,1,2},
 {44,13,11,1,1},
 {10,14,9,1,1},
 {19,14,26,1,2},
 {45,14,9,1,1},
 {10,15,7,1,1},
 {18,15,28,1,2},
 {47,15,7,1,1},
 {9,16,7,1,1},
 {17,16,13,1,2},
 {31,16,2,24,2},
 {33,16,1,3,1},
 {34,16,13,1,2},
 {48,16,6,1,1},
 {3,17,2,1,1},
 {9,17,6,1,1},
 {16,17,13,1,2},
 {30,17,1,1,1},
 {34,17,14,1,2},
 {49,17,6,1,1},
 {59,17,1,1,1},
 {3,18,12,1,1},
 {15,18,14,1,2},
 {29,18,2,3,1},
 {35,18,14,1,2},
 {49,18,12,1,1},
 {3,19,11,1,1},
 {14,19,15,1,2},
 {33,19,2,3,1},
 {35,19,15,1,2},
 {50,19,11,1,1},
 {2,20,11,2,1},
 {13,20,16,1,2},
 {35,20,16,2,2},
 {51,20,11,2,1},
 {13,21,15,1,2},
 {28,21,3,3,1},
 {2,22,10,1,1},
 {12,22,16,2,2},
 {33,22,3,3,1},
 {36,22,16,3,2},
 {52,22,10,1,1},
 {4,23,8,1,1},
 {52,23,8,1,1},
 {5,24,6,3,1},
 {11,24,16,1,2},
 {27,24,4,3,1},
 {53,24,6,1,1},
 {11,25,2,1,2},
 {13,25,11,1,1},
 {24,25,3,2,2},
 {33,25,4,3,1},
 {37,25,2,1,2},
 {39,25,11,1,1},
 {50,25,3,1,2},
 {53,25,5,1,1},
 {11,26,4,1,2},
 {15,26,9,1,1},
 {37,26,3,2,2},
 {40,26,9,1,1},
 {49,26,4,1,2},
 {53,26,6,1,1},
 {5,27,5,2,1},
 {11,27,5,1,2},
 {16,27,8,1,1},
 {24,27,2,1,2},
 {26,27,5,3,1},
 {40,27,7,1,1},
 {48,27,5,1,2},
 {54,27,5,2,1},
 {10,28,7,1,2},
 {18,28,5,1,1},
 {23,28,3,2,2},
 {33,28,5,3,1},
 {38,28,2,1,2},
 {40,28,6,1,1},
 {46,28,8,1,2},
 {0,29,10,6,1},
 {10,29,9,1,2},
 {19,29,4,1,1},
 {38,29,3,2,2},
 {41,29,4,1,1},
 {45,29,9,1,2},
 {54,29,10,6,1},
 {10,30,10,1,2},
 {20,30,3,1,1},
 {23,30,2,1,2},
 {25,30,6,3,1},
 {41,30,2,1,1},
 {44,30,10,1,2},
 {10,31,15,2,2},
 {33,31,6,3,1},
 {39,31,2,1,2},
 {42,31,12,1,2},
 {39,32,15,2,2},
 {10,33,14,3,2},
 {24,33,7,4,1},
 {33,34,7,3,1},
 {40,34,14,2,2},
 {5,35,5,2,1},
 {54,35,5,2,1},
 {11,36,12,3,2},
 {40,36,13,1,2},
 {5,37,6,3,1},
 {23,37,8,2,1},
 {33,37,8,3,1},
 {41,37,12,2,2},
 {53,37,6,1,1},
 {53,38,5,1,1},
 {11,39,11,1,2},
 {23,39,7,1,1},
 {41,39,11,1,2},
 {53,39,6,1,1},
 {3,40,9,1,1},
 {12,40,10,2,2},
 {22,40,8,1,1},
 {30,40,4,1,2},
 {34,40,8,1,1},
 {42,40,10,2,2},
 {52,40,8,1,1},
 {2,41,10,1,1},
 {22,41,6,1,1},
 {28,41,7,1,2},
 {36,41,6,1,1},
 {52,41,10,1,1},
 {2,42,11,2,1},
 {13,42,8,2,2},
 {22,42,5,1,1},
 {27,42,10,1,2},
 {37,42,5,1,1},
 {42,42,9,1,2},
 {51,42,11,2,1},
 {21,43,4,1,1},
 {26,43,12,1,2},
 {38,43,5,1,1},
 {43,43,8,1,2},
 {3,44,11,1,1},
 {14,44,7,1,2},
 {21,44,3,1,1},
 {24,44,15,1,2},
 {40,44,3,1,1},
 {43,44,7,1,2},
 {50,44,11,1,1},
 {3,45,4,1,1},
 {8,45,7,1,1},
 {15,45,5,1,2},
 {21,45,2,1,1},
 {23,45,18,1,2},
 {41,45,2,1,1},
 {43,45,6,1,2},
 {49,45,12,1,1},
 {3,46,2,1,1},
 {9,46,6,1,1},
 {16,46,4,1,2},
 {20,46,1,1,1},
 {22,46,20,1,2},
 {42,46,2,1,1},
 {44,46,4,1,2},
 {49,46,6,1,1},
 {59,46,1,1,1},
 {10,47,6,1,1},
 {17,47,30,1,2},
 {48,47,6,1,1},
 {10,48,7,1,1},
 {18,48,28,1,2},
 {47,48,7,1,1},
 {10,49,9,1,1},
 {19,49,26,1,2},
 {45,49,9,1,1},
 {9,50,11,1,1},
 {20,50,24,1,2},
 {44,50,11,1,1},
 {8,51,14,1,1},
 {22,51,20,1,2},
 {42,51,14,1,1},
 {8,52,16,1,1},
 {25,52,14,1,2},
 {40,52,16,1,1},
 {8,53,19,1,1},
 {28,53,8,1,2},
 {37,53,19,1,1},
 {9,54,5,1,1},
 {17,54,30,1,1},
 {50,54,5,1,1},
 {10,55,3,1,1},
 {18,55,28,3,1},
 {51,55,3,1,1},
 {18,58,7,1,1},
 {26,58,12,1,1},
 {39,58,7,1,1},
 {17,59,7,1,1},
 {29,59,6,5,1},
 {40,59,7,1,1},
 {18,60,5,1,1},
 {40,60,6,1,1},
 {20,61,3,1,1},
 {41,61,3,1,1},
}
 local E=rawget(_G,'stingray');assert(E and E.Application and E.World and E.Gui,'Stingray screen GUI unavailable')
 local ffi=require('ffi')
 pcall(ffi.cdef,'typedef struct {long x;long y;} PYB_UI_POINT; typedef struct {long left;long top;long right;long bottom;} PYB_UI_RECT;')
 for _,decl in ipairs({'void* GetForegroundWindow(void);','unsigned long GetWindowThreadProcessId(void*,unsigned long*);',
  'unsigned long GetCurrentProcessId(void);','short GetAsyncKeyState(int);','uint64_t GetTickCount64(void);',
  'int GetCursorPos(void*);','int ScreenToClient(void*,void*);','int GetClientRect(void*,void*);'})do pcall(ffi.cdef,decl)end
 local U,K=ffi.load('user32'),ffi.load('kernel32');local own=K.GetCurrentProcessId()
 local focus_pid=ffi.new('unsigned long[1]');local focus_pp=ffi.cast('void*',focus_pid)
 local mouse_point,mouse_rect=ffi.new('PYB_UI_POINT[1]'),ffi.new('PYB_UI_RECT[1]')
 local mouse_pp,mouse_rp=ffi.cast('void*',mouse_point),ffi.cast('void*',mouse_rect)
 local input_guard
 local stats={gui_created=0,gui_destroyed=0,paints=0,primitive_writes=0}
 local s={open=false,model=model,keys={},repeat_at={},regions={},position=1}
 local positions={'Center','Lower','Upper'};local position_ratio={.5,.88,.12};local pages={'Master','Patrols','Reinforcements','Guards','Rules','Faction specific'}
 local page_order={0,5,1,2,3,4}
 local bot_page_order={0,5,1,2,3,4}
 local function visible_pages()return model.faction=='automaton' and bot_page_order or page_order end

 -- Test38 read-only Rules page: what replaces each subfaction unit, per faction. h=heading, t=text, b=bullet, n=note.
 local replacement_rules={
  automaton={
   {'h','AUTOMATON: WHAT TO PICK FOR SUBFACTION UNITS'},
   {'t','On a subfaction planet the game turns some picked units into their subfaction version. Pick the base unit to get it. Not every picked unit converts; the game rolls its own odds.'},
   {'h','JET BRIGADE'},
   {'b','Trooper tier 3 -> Jump Pack Trooper.  Brawler -> Jump Pack Brawler.  Commissar -> Jump Pack Commissar.'},
   {'b','Hulk Scorcher and Hulk Bruiser -> their Jet Brigade variants.'},
   {'b','Jet Pack Devastator (Jet Brigade Planet): pick it directly; no other pick turns into it. Skipped on other planets.'},
   {'h','INCINERATION CORPS'},
   {'b','Trooper tier 3 -> Incineration trooper.  Brawler -> Flamer Trooper.  Commissar -> Incineration Commissar.  Berserker -> Incineration shotgun Devastator.'},
   {'b','Hulk Scorcher, Hulk Bruiser, Heavy Devastator, Rocket Devastator -> their Incineration Corps versions.'},
   {'h','CYBORG LEGION'},
   {'b','Cyborg and Cyborg Rusher (Cyborg Legion Planet): pick them directly. Skipped on other planets.'},
   {'b','Factory Strider -> Siege Engine (difficulty 7+).'},
   {'h','TANKS'},
   {'b','On Jet Brigade and some other planets the game turns tanks into War Striders (difficulty 6+). Picked tanks stay tanks: the mod switches that rule off for them.'},
   {'n','Factory Strider, Jammer and Siege Engine rows and Gunships keep their native rows. A picked unit the planet does not load is skipped.'},
  },
  terminid={
   {'h','TERMINID: WHAT TO PICK FOR SUBFACTION UNITS'},
   {'t','On a strain planet the game turns some picked units into their strain version. Pick the base unit to get it. Not every picked unit converts; the game rolls its own odds.'},
   {'h','PREDATOR STRAIN'},
   {'b','Hunter MK3 -> Predator Hunter (difficulty 2+).'},
   {'b','Predator Stalker (Pred Strain Planet): pick it directly in any tab; no other pick turns into it. It only spawns on Predator Strain planets; on other planets it is skipped and its share goes to the tab\'s other units.'},
   {'h','SPORE BURST STRAIN'},
   {'b','Scavenger MK3 -> Spore Burst Scavenger.  Hunter MK3 -> Spore Burst Hunter.  Warrior MK3 -> Spore Burst Warrior (difficulty 2+).'},
   {'b','Bile Titan -> Spore Burst Bile Titan (difficulty 5+).'},
   {'h','RUPTURE STRAIN (DIFFICULTY 6+)'},
   {'b','Warrior MK3 -> Rupture Warrior.  Charger or Charger Behemoth MK2 -> Rupture Charger.  Nursing Spewer MK2 -> Rupture Spewer.'},
   {'h','OTHER PLANET CONVERSIONS'},
   {'b','Bile Bugs: Scavenger MK3 -> Bile Spitter; Warrior MK3 -> Bile Warrior (difficulty 3+).  Hunter Swarms: Scavenger MK3 -> Pouncer.'},
   {'b','Hive World: Bile Titan -> Charger, controlled by Titan replacement on the Faction page.'},
   {'n','Nests follow your Guards mix: nest guard forces and nest holes (holes only take units that fit them).'},
   {'n','Spore Charger is a common spawn: pick it directly on any tab.'},
   {'n','A picked unit the planet does not load is skipped (no ? models). Seen so far: Pouncer needs Hunter Swarms; Bile Spitter, Bile Warrior and Bile Spewer MK2 need Bile Bugs.'},
  },
  illuminate={
   {'h','ILLUMINATE: FIRST ROSTER TEST'},
   {'t','Patrols, Warp Ship reinforcements and placed Guards use separate mixes. Other scripted and special routes retain their native entries.'},
   {'b','Watcher is the native reinforcement caller. Its call launches four orbs; its charged arc attack is a separate action.'},
   {'b','Worker and civilian/SEAF roster slots stay untouched.'},
   {'b','Units gated off on this planet are skipped and the remaining selected weights are renormalized. An entirely unavailable tab stays native.'},
   {'n','Large Illuminate units are experimental. Test them in small shares first, especially in Warp Ship reinforcements.'},
  },
 }
 local factions={'automaton','terminid','illuminate'};local faction_labels={'AUTOMATONS','TERMINIDS','ILLUMINATE'};s.unit_offset=0
 local function trace(t)emit('PICK_YOUR_BOTS_PANEL '..t)end
 local binding=new_panel_binding(trace)
 local function fmt(n)return type(n)=='number'and string.format('%.2f',n):gsub('%.?0+$','')or tostring(n)end
 local function focused()
  local w=U.GetForegroundWindow();if w==nil then return end
  local p=focus_pid;if U.GetWindowThreadProcessId(w,focus_pp)~=0 and p[0]==own then return w end
 end
 local function release_input(restore_clip)if input_guard then input_guard.release(restore_clip)end end
 local function cursor(show)
  local W=E.Window;if not W or type(W.set_show_cursor)~='function'then return end
  if show and not s.cursor then
   s.cursor_before=type(W.show_cursor)=='function'and W.show_cursor()or false
   W.set_show_cursor(true);s.cursor=true
  elseif show and s.cursor and (s.now or 0)>=(s.cursor_check or 0)then
   s.cursor_check=(s.now or 0)+250
   if type(W.show_cursor)=='function'and not W.show_cursor()then W.set_show_cursor(true)end
  elseif not show and s.cursor then W.set_show_cursor(s.cursor_before);s.cursor=false end
 end
 local toast_tick
 local function destroy(worlds)
  if s.gui then
   -- A loading transition can have already destroyed the old world and GUI.
   for _,w in ipairs(worlds or {})do if w==s.world then pcall(E.World.destroy_gui,s.world,s.gui);stats.gui_destroyed=stats.gui_destroyed+1;break end end
  end
  s.gui=nil;s.world=nil;s.primitives={rect={},text={}};s.regions={};s.paint_stamp=nil;s.paint_state=nil;s.next_font_check=nil;s.font=nil;s.material=nil;s.font_hashed=nil;s.drag=nil;s.held_button=nil
 end
 local function close(worlds)
  release_input();s.open=false;s.edit=nil;s.drag=nil;s.held_button=nil;destroy(worlds);cursor(false);trace('closed draft_retained='..tostring(model.dirty)..' gui_created='..stats.gui_created..' gui_destroyed='..stats.gui_destroyed..' paints='..stats.paints..' primitive_writes='..stats.primitive_writes)
 end
 -- Resolve the same loaded HUD assets as the reference, only on its exact PE
 -- build. ReadProcessMemory-backed reader; no font or renderer memory writes.
 local function read(at,n)return mem and mem.read(at,n)end
 local function u32(at)local b=read(at,4);if not b or #b~=4 then return end;local a,c,d,e=b:byte(1,4);return a+c*256+d*65536+e*16777216 end
 local function ptr(at)local lo,hi=u32(at),u32(at+4);if not lo or not hi then return end;local v=lo+hi*4294967296;if v>=65536 and v<140737488355328 then return v end end
 local function hash(at)local lo,hi=u32(at),u32(at+4);if lo and hi and(lo~=0 or hi~=0)then return string.format('%08X%08X',hi,lo)end end
 local function font_for(gui)
  local I=E.IdString64;local game=mem and mem.module('game.dll')
  if game and I and E.Material then
   local pe=u32(game+0x3c)
   if pe and pe<=0x1000 and u32(game+pe)==0x4550 and u32(game+pe+8)==0x6AB3B43F and u32(game+pe+80)==0x4744000 and u32(game+pe+88)==0xECDA6F then
    local owner=ptr(game+0x37C5478);local f,t,m=hash(game+0x3772268),hash(game+0x3772EE8),owner and hash(owner+24)
    if f and t and m then
     local fi,ti,mi=I.from_hex(f),I.from_hex(t),I.from_hex(m)
     if E.Application.can_get('font',fi)and E.Application.can_get('texture',ti)and E.Application.can_get('material',mi)then
      local material=E.Gui.material(gui,mi)
      if material then E.Material.set_texture(material,I.from_hex('88BAC99B00000000'),ti);return f,m,true end
     end
    end
   end
  end
  local f='core/performance_hud/debug'
  if E.Application.can_get('font',f)and E.Application.can_get('material',f)then return f,f,false end
 end
 -- Returned temporary IDs are consumed only by the calling update.
 local function resources()
  local font=s.font_hashed and E.IdString64.from_hex(s.font)or s.font
  local material=s.font_hashed and E.IdString64.from_hex(s.material)or s.material
  if E.Application.can_get('font',font)and E.Application.can_get('material',material)then return font,material end
 end
 local function finish(cancel)
  if not s.edit then return true end
  if cancel then s.edit=nil;return true end
  if model.set(s.edit.row,s.edit.text)then trace('value page='..model.page..' row='..s.edit.row..' value='..s.edit.text);s.edit=nil;return true end
  return false
 end
 local function change_page(page)if finish(false)then s.drag=nil;s.held_button=nil;s.unit_offset=0;model.change_page(page);trace('page='..model.page)end end
 local function change_faction(faction)
  if not finish(false)then return end
  local next_model=models[faction];if not next_model or next_model==model then return end
  local page=model.page
  model.copy_shared(next_model);model,mix=next_model,mixes[faction];model.change_page(page)
  s.model=model;s.unit_offset=0;s.drag=nil;s.held_button=nil;s.invalidate=true
  trace('faction='..faction)
 end
 local function action(id,worlds,fast)
  if id=='close'then close(worlds);return end
  if id=='discard'then s.edit=nil;model.discard();trace('discard');return end
  if not finish(false)then return end
  if id=='apply'then local ok=model.apply();trace('save_tab page='..model.page..' ok='..tostring(ok));return end
     if id=='position'then s.position=s.position%3+1;return end
   local faction=id:match('^faction:(%a+)$');if faction then change_faction(faction);return end
   if id=='units_prev'then s.unit_offset=math.max(0,s.unit_offset-16);s.invalidate=true;return end
   if id=='units_next'then s.unit_offset=math.min(math.floor(math.max(0,#model.rows()-1)/16)*16,s.unit_offset+16);s.invalidate=true;return end
  if id=='enable'then s.drag=nil;s.held_button=nil;model.set_tab_enabled(not model.tab_enabled());trace('tab_enabled='..tostring(model.tab_enabled())..' page='..model.page);return end
  local page=id:match('^page:(%d+)$');if page then change_page(tonumber(page));return end
  local kind,row=id:match('^(%a+):(%d+)$');row=tonumber(row);if not row then return end
  model.selected=row
  if kind=='slider'then return end
  if kind=='select'then return end
  if kind=='minus'or kind=='plus'then model.adjust(row,kind=='plus'and 1 or -1,fast)
  elseif kind=='value'then
   if not model.tab_enabled()then return end
   local r=model.rows()[row]
   if r.kind=='toggle'or r.kind=='production'or r.kind=='enum'then model.adjust(row,1)
   else s.edit={row=row,text=fmt(model.value(row)),replace=true};model.message='Type a value; Enter confirms it, Escape cancels. Save Tab saves only this page.'end
  end
 end
 local navigation_keys={1,9,13,16,27,32,33,34,37,38,39,40,0x75,0x74}
 local edit_keys={8,17,46,65,110,190}
 for k=48,57 do edit_keys[#edit_keys+1]=k end;for k=96,105 do edit_keys[#edit_keys+1]=k end
 local hits={};local was_editing=false
 local function sample_key(k,focus,suppress)
  local now=s.now;local down,hit=s.keys,hits
  local held=U.GetAsyncKeyState(k)<0
  hit[k]=focus and not suppress and held and not down[k]or false
  if focus and not suppress and ((k>=37 and k<=40)or k==8)then
   if hit[k]then s.repeat_at[k]=now+350
   elseif held and s.repeat_at[k]and now>=s.repeat_at[k]then hit[k]=true;s.repeat_at[k]=now+80 end
  end
  if not held or not focus then s.repeat_at[k]=nil end
  down[k]=held
 end
 local function snapshot(focus)
  local down,hit=s.keys,hits;local editing=s.edit~=nil
  for _,k in ipairs(navigation_keys)do sample_key(k,focus,false)end
  if editing then
   -- Seed held typing keys on entry so a key pressed outside the edit does
   -- not become a new character merely because the field gained focus.
   for _,k in ipairs(edit_keys)do sample_key(k,focus,not was_editing)end
  elseif was_editing then
   for _,k in ipairs(edit_keys)do hit[k]=false;down[k]=nil;s.repeat_at[k]=nil end
  end
  was_editing=editing;return down,hit
 end
 local function keyboard(d,h,worlds)
  if s.edit then
   if h[27]then finish(true);return end
   if h[13]then finish(false);return end
   local edit=s.edit
   if h[65]and d[17]then edit.replace=true end
   if h[8]or h[46]then edit.text=edit.replace and ''or edit.text:sub(1,-2);edit.replace=false end
   for k=48,105 do if h[k]and(k<=57 or k>=96)then
    if edit.replace then edit.text='';edit.replace=false end
    if #edit.text<8 then edit.text=edit.text..tostring(k>=96 and k-96 or k-48)end
   end end
   if h[110]or h[190]then
    if edit.replace then edit.text='';edit.replace=false end
    if not edit.text:find('.',1,true)then edit.text=edit.text..'.'end
   end
   return
  end
  if h[27]then close(worlds);return end
  if h[33]or h[34]then
   local order=visible_pages()
   local index=1;for i,page in ipairs(order)do if page==model.page then index=i;break end end
   local next_index=math.max(1,math.min(#order,index+(h[33] and -1 or 1)))
   change_page(order[next_index])
  end
   if h[0x75]and model.page>=1 and model.page<=3 then action('enable',worlds)end
   if #model.rows()>0 then
    if h[38]or(h[9]and d[16])then model.selected=(model.selected-2)%#model.rows()+1
    elseif h[40]or h[9]then model.selected=model.selected%#model.rows()+1 end
   end
  if h[37]then model.adjust(model.selected,-1,d[16])elseif h[39]then model.adjust(model.selected,1,d[16])end
  if h[32]then action('value:'..model.selected,worlds)end
  if h[13]then action('apply',worlds)end
 end
 local function mouse(window)
  local p,r=mouse_point,mouse_rect
  -- Generic pointers coexist with other mods' POINT/RECT declarations.
  local pp,rp=mouse_pp,mouse_rp
  if U.GetCursorPos(pp)==0 or U.ScreenToClient(window,pp)==0 then return end
  if window~=s.mouse_window or s.width~=s.mouse_width or s.height~=s.mouse_height or s.now>=(s.bounds_until or 0)then
   if U.GetClientRect(window,rp)==0 then return end
   s.client_width,s.client_height=r[0].right-r[0].left,r[0].bottom-r[0].top
   s.mouse_window,s.mouse_width,s.mouse_height=window,s.width,s.height;s.bounds_until=s.now+250
  end
  local cw,ch=s.client_width,s.client_height
  if cw<=0 or ch<=0 then return end
  return(p[0].x*s.width/cw-s.ox)/s.scale,(p[0].y*s.height/ch-s.oy)/s.scale
 end
 local themes={
  helldiver={255,218,42,72,61,16,43,38,20,52,45,24,76,66,34,29,26,17},
  automaton={238,59,69,93,23,32,47,31,37,43,23,29,74,48,53,26,18,22},
  terminid={255,174,40,89,58,19,48,39,25,47,34,20,80,61,35,29,25,18},
  illuminate={178,119,255,65,36,88,43,33,54,39,27,50,66,49,82,25,20,31}
 }
 local function draw(font,material)
  local G=E.Gui;local function C(...)return{...}end;local sc,ox,oy,H=s.scale,s.ox,s.oy,s.height
  local t=themes[model.page==0 and 'helldiver' or model.faction] or themes.helldiver
  local white,red,muted=C(255,241,234,235),C(255,t[1],t[2],t[3]),C(255,167,154,157)
  local bg,panel,rowbg,line,dim=C(255,10,9,11),C(255,19,17,20),C(255,25,22,25),C(255,t[13],t[14],t[15]),C(255,104,91,95)
  local accent_fill,accent_hover,selected_fill,soft_border,footer_fill=C(255,t[4],t[5],t[6]),C(255,t[7],t[8],t[9]),C(255,t[10],t[11],t[12]),C(255,t[13]-20,t[14]-16,t[15]-17),C(255,t[16],t[17],t[18])
  -- Few stable depth groups let the renderer batch geometry. Never assign
  -- a fresh layer per primitive: the Test6.15 regression had hundreds.
  local counts={rect=0,text=0};local layers={}
  local function px(v)return math.floor(v+.5)end
  s.primitives=s.primitives or {rect={},text={}}
  local function primitive(kind,args,paint)
   counts[kind]=counts[kind]+1;local pool=s.primitives[kind];local old=pool[counts[kind]]
   local same=old and #old.args==#args
   if same then for i,v in ipairs(args)do if old.args[i]~=v then same=false;break end end end
   if same then return end
   -- Keep the GUI and all unchanged primitives. Never reset/destroy the GUI
   -- for a hover, edited number, slider movement, or page change.
   stats.primitive_writes=stats.primitive_writes+1
   local id=paint();assert(id~=nil,'Retained GUI primitive ID unavailable')
   if old then G['destroy_'..kind](s.gui,old.id)end
   pool[counts[kind]]={id=id,args=args}
  end
  local function rect(x,y,w,h,c,z)
   z=z or 946;layers[z]=true
   primitive('rect',{x,y,w,h,c[1],c[2],c[3],c[4],z,sc,ox,oy,H},function()
    local x0,x1=px(ox+x*sc),px(ox+(x+w)*sc)
    local y0,y1=px(H-oy-(y+h)*sc),px(H-oy-y*sc)
    return G.rect(s.gui,E.Vector3(x0,y0,z),E.Vector2(math.max(1,x1-x0),math.max(1,y1-y0)),E.Color((unpack or table.unpack)(c)))
   end)
  end
  local function text(t,x,y,n,c)
   c=c or white;t=tostring(t);local z=952;layers[z]=true
   primitive('text',{t,x,y,n,c[1],c[2],c[3],c[4],z,sc,ox,oy,H},function()
    return G.text(s.gui,t,font,math.max(7,px(n*sc)),material,E.Vector3(px(ox+x*sc),px(H-oy-y*sc-n*sc*.8),z),E.Color((unpack or table.unpack)(c)))
   end)
  end
  local function trim()
   for kind,n in pairs(counts)do local pool=s.primitives[kind]
    for i=#pool,n+1,-1 do G['destroy_'..kind](s.gui,pool[i].id);pool[i]=nil end
   end
  end
  local function border(x,y,w,h,c)
   rect(x,y,w,1,c,950);rect(x,y+h-1,w,1,c,950);rect(x,y,1,h,c,950);rect(x+w-1,y,1,h,c,950)
  end
  local function wrap(t,x,y,limit,n,c)
   local line_,row='',0
   for word in tostring(t):gmatch('%S+')do
    if #line_+#word+1>limit and line_~=''then text(line_,x,y+row*(n+5),n,c);line_='';row=row+1 end
    line_=line_==''and word or line_..' '..word
   end
   text(line_,x,y+row*(n+5),n,c)
  end
  local regions={}
  local function region(id,x,y,w,h)local v={id=id,x=x,y=y,w=w,h=h};regions[#regions+1]=v;return v end
  local function button(id,label,x,y,w,h,on,enabled)
   enabled=enabled~=false
   local hover=enabled and s.hover==id
   rect(x,y,w,h,not enabled and C(255,16,15,17)or on and accent_fill or hover and accent_hover or rowbg)
   border(x,y,w,h,not enabled and C(255,47,40,44)or hover and white or on and red or line)
   if on then rect(x+1,y+1,3,h-2,red,948)end
   text(label,x+10,y+(h-16)/2,16,not enabled and dim or white)
   if enabled then region(id,x,y,w,h)end
  end
  local function indicator(label,x,y,on)
   rect(x,y+3,8,8,on and red or C(255,19,17,20));border(x,y+3,8,8,on and red or dim)
   text(label,x+16,y,13,on and white or muted)
  end
  rect(0,0,1400,900,bg,940);border(0,0,1400,900,line);rect(0,0,1400,3,red,951)
  local emblem=model.page==0 and helldiver_emblem or model.faction=='automaton' and automaton_emblem or model.faction=='terminid' and terminid_emblem or illuminate_emblem
  for _,v in ipairs(emblem)do rect(27+v[1],19+v[2],v[3],v[4],v[5]==1 and red or white)end
  local title=model.page==0 and 'PICK YOUR BOTS / BUGS / SQUIDS' or model.faction=='automaton' and 'PICK YOUR BOTS' or model.faction=='terminid' and 'PICK YOUR BUGS' or 'PICK YOUR SQUIDS'
  text(title,112,25,29,white)
  text('FACTION SPAWN CONTROL  /  v1.5',114,65,13,red)
  if model.page==0 then
   text('SHARED SETTINGS  /  ALL FACTIONS',280,82,15,red)
  else
   for i,faction in ipairs(factions)do button('faction:'..faction,faction_labels[i],280+(i-1)*212,78,200,31,model.faction==faction)end
  end
  local pending=false;for page=0,5 do pending=pending or model.pending(page)end
  local runtime_state=rawget(_G,'PickYourBots')
  local unavailable=runtime_state and type(runtime_state.status)=='string' and runtime_state.status:match('unit_not_available=([%w_]+)')
  indicator(unavailable and 'CUSTOM MIX INACTIVE' or model.dirty and 'UNSAVED DRAFT' or pending and 'SAVED / WAITING FOR SHIP' or 'SETTINGS IN SYNC',744,35,unavailable or model.dirty or pending)
  button('position','Position: '..positions[s.position],1070,22,240,42);button('close','X',1330,22,46,42)
  rect(24,112,216,616,panel,942);border(24,112,216,616,line)
  text('SPAWN CONTROL',40,133,15,red)
  for i,page in ipairs(visible_pages())do
   local y=148+(i-1)*91
   local label=pages[page+1]
   button('page:'..page,label,36,y,192,39,model.page==page)
   if model.page~=0 or page==0 then
    local on=page==0 and model.draft.enabled or page==5 or (page>=1 and page<=3 and not model.draft.vanilla[mix.sources[page].key])
    if page==4 then indicator('REFERENCE',47,y+46,false);text('READ ONLY',47,y+66,11,muted) else
    indicator(page==5 and (model.faction=='automaton' and 'BOT CONTROLS' or model.faction=='terminid' and 'BUG CONTROLS' or 'ILLUMINATE CONTROLS') or ('DRAFT: '..(on and 'ON' or 'OFF')..(model.page_dirty(page)and ' *'or '')),47,y+46,on)
    text(page==5 and (model.faction=='automaton' and 'AUTOMATON ONLY' or model.faction=='terminid' and 'TERMINID ONLY' or 'ILLUMINATE ONLY') or model.active_enabled(page)and (page==0 and 'ACTIVE: MOD ON'or 'ACTIVE: CUSTOM')or(page==0 and 'ACTIVE: MOD OFF'or(model.active.enabled and 'ACTIVE: GAME' or 'ACTIVE: MOD OFF')),47,y+66,11,muted)
    end
   end
  end
  rect(260,112,1116,616,panel,942);border(260,112,1116,616,line)
  text(pages[model.page+1],280,131,25,white)
  if s.fault then
   text('MENU ERROR',280,210,22,red);wrap(s.fault,280,255,100,16,white)
   text('Close with Escape and reopen to retry. See panel trace for details.',280,682,16,muted)
   s.regions={{id='close',x=1330,y=22,w=46,h=42}};trim();return
  end
  if model.page==4 then
   text('SUBFACTION REPLACEMENT RULES  /  READ ONLY',280,173,13,red)
  elseif model.page>=1 and model.page<=3 then
    local enabled=model.tab_enabled()
   button('enable',enabled and '[ON]  CUSTOM WEIGHTS' or '[OFF]  GAME WEIGHTS',1096,126,260,38,enabled)
   text(enabled and 'EDIT WEIGHTS  /  F6 TO DISABLE' or 'CONTROLS DISABLED  /  F6 TO ENABLE',280,173,13,enabled and red or muted)
    if model.page==2 then text(model.faction=='automaton' and 'BOT DROPS' or model.faction=='terminid' and 'BUG BREACHES' or 'WARP SHIP REINFORCEMENTS',795,173,13,red)end
   text(model.cost_text(),280,198,14,muted)
   text('TOTAL '..fmt(model.total())..'% '..(model.total()==100 and '/ READY' or '/ SAVE TO BALANCE'),1070,198,14,model.total()==100 and white or red)
     else
    text(model.page==5 and 'FACTION SETTINGS' or 'DRAG SLIDERS  /  TYPE EXACT VALUES  /  ARROWS TO FINE-TUNE',280,173,13,muted)
   indicator(model.active.enabled and 'MOD ACTIVE' or 'MOD INACTIVE',1180,143,model.active.enabled)
  end
  local function row(i,x,y,w,h,compact)
   local r=model.rows()[i];local enabled=model.tab_enabled();local chosen=i==model.selected
   rect(x,y,w,h,chosen and selected_fill or rowbg,944)
   border(x,y,w,h,chosen and red or soft_border)
   if chosen then rect(x,y,3,h,red,951)end
   local label=r.label or r[2];local value=model.value(i)
   local inputX=x+w-((r.kind=='production'or r.kind=='enum')and 330 or 200);local inputY=y+(h-30)/2
   text(label,x+12,compact and y+6 or y+(h-16)/2,15,enabled and white or dim)
   region('select:'..i,x+4,y+3,compact and w-218 or 363,compact and 22 or h-6)
   if r.kind=='toggle'then
    button('value:'..i,value and '[ON]  ENABLED' or '[OFF] DISABLED',inputX,inputY,188,30,value,enabled)
   elseif r.kind=='production'or r.kind=='enum'then
    button('minus:'..i,'-',inputX,inputY,32,30,false,enabled)
    button('value:'..i,(r.options and r.options[value]or aar_factory_production.choices[value][1]),inputX+38,inputY,240,30,false,enabled)
    button('plus:'..i,'+',inputX+284,inputY,34,30,false,enabled)
   else
    local lo,hi=model.slider_range(i)
    if lo then
     local trackX=compact and x+14 or x+388
     local trackY=compact and y+h-14 or y+h/2
     local trackW=compact and w-232 or w-614
     local ratio=math.max(0,math.min(1,(value-lo)/(hi-lo)))
     rect(trackX,trackY-3,trackW,6,soft_border)
     if ratio>0 then rect(trackX,trackY-3,trackW*ratio,6,enabled and red or dim,947)end
     rect(trackX+trackW*ratio-4,trackY-8,8,16,enabled and (s.drag and s.drag.row==i and white or red)or dim,949)
     if enabled then local v=region('slider:'..i,trackX-7,trackY-11,trackW+14,22);v.track_x=trackX;v.track_w=trackW end
    end
    button('minus:'..i,'-',inputX,inputY,32,30,false,enabled)
    local suffix=r.choices and ''or (model.page>=1 and model.page<=4) and '%'or r.key=='reinforce_cooldown_reduction'and '%'or r.key=='factory_strider_cap' and '' or r.key=='bug_titan_cap' and '' or r.key=='bug_titan_resume_below' and '' or 'x'
    local shown=s.edit and s.edit.row==i and(s.edit.text..' |')or(fmt(value)..suffix)
    button('value:'..i,shown,inputX+38,inputY,110,30,s.edit and s.edit.row==i,enabled)
    button('plus:'..i,'+',inputX+154,inputY,34,30,false,enabled)
   end
  end
  if model.page==4 then
    local y=206
    for _,item in ipairs(replacement_rules[model.faction] or {})do
     local size=item[1]=='h' and 15 or 14
     local color=item[1]=='h' and red or item[1]=='n' and muted or white
     local prefix=item[1]=='b' and '-  ' or ''
     local limit=item[1]=='b' and 116 or 120
     local line_,rows='',0
     for word in (prefix..item[2]):gmatch('%S+')do
      if #line_+#word+1>limit and line_~='' then text(line_,item[1]=='b' and 296 or 280,y,size,color);y=y+size+6;line_='  ';rows=rows+1 end
      line_=line_=='' and word or line_..' '..word
     end
     text(line_,item[1]=='b' and 296 or 280,y,size,color);y=y+size+(item[1]=='h' and 9 or 7)
     if y>722 then break end
    end
  elseif model.page==0 or model.page==5 then
     local step=math.min(61,math.floor(512/#model.rows()))
     for i=1,#model.rows()do row(i,280,204+(i-1)*step,1076,step-8,false)end
   else
    local first=s.unit_offset+1;local last=math.min(#model.rows(),s.unit_offset+16)
    for i=first,last do local j=i-first;local col=math.floor(j/8);row(i,280+col*548,230+j%8*54,528,49,true)end
    if #model.rows()>16 then
     button('units_prev','PREVIOUS UNITS',280,670,176,38,false,s.unit_offset>0)
     text(string.format('%d-%d OF %d UNITS',first,last,#model.rows()),603,680,14,muted)
     button('units_next','NEXT UNITS',1168,670,188,38,false,last<#model.rows())
    elseif model.page==3 or model.page==4 then
     text('Protected special and unknown Terminids keep native rows.',280,690,14,muted)
    end
   end
  rect(24,742,1352,47,footer_fill,942);rect(24,742,3,47,model.dirty and red or line)
  local footer_message=unavailable and ('CUSTOM WEIGHTS INACTIVE: '..unavailable:gsub('_',' '):upper()..' unavailable in this mission; game weights are in use.') or model.message
  wrap(footer_message,40,753,160,14,(unavailable or model.dirty) and white or muted)
   button('apply','SAVE THIS TAB',24,806,230,44,true,model.page~=4)
  button('discard','DISCARD DRAFT',266,806,230,44,false,model.page_dirty() or s.edit~=nil)
     text('Esc close  /  F6 custom ON-OFF',536,820,15,muted)
  text('Drag: adjust    Click value: type    Arrows: fine-tune    Shift: x10    PgUp/PgDn: tabs    Enter: save    Esc: cancel / close',24,873,14,muted)
  trim();s.regions=regions;s.region_page=model.page;s.region_faction=model.faction
  stats.paints=stats.paints+1
  if not s.first_paint_reported then
   local n=0;for _ in pairs(layers)do n=n+1 end
   trace('first_paint rects='..counts.rect..' texts='..counts.text..' layers='..n..' range=940-952')
   s.first_paint_reported=true
  end
 end
 function s.sync(bot_profile,terminid_profile,illuminate_profile)
   models.automaton.load(bot_profile,false);models.terminid.load(terminid_profile,false);models.illuminate.load(illuminate_profile,false)
  end
 -- Test38 load banner: a small non-interactive strip shown for 9 s when the mix result for a mission arrives.
 -- No input capture, no cursor; drawn once with retained primitives and destroyed with its GUI on expiry.
 local function toast_draw()
  local rt=rawget(_G,'PickYourBots');local msg=rt and rt.banner
  local now=tonumber(K.GetTickCount64())
  if msg and msg.id~=s.toast_id then
   s.toast_id=msg.id;s.toast_text=tostring(msg.text);s.toast_bad=msg.bad
   if s.toast_gui then destroy(E.Application.worlds()or{});s.toast_gui=nil end
   if s.toast_text=='' then s.toast_until=nil;return end
   s.toast_until=now+(tonumber(msg.duration_ms) or 9000)
  end
  if not s.toast_until then return end
  local worlds=E.Application.worlds()or{}
  if now>=s.toast_until or not focused()then
   if s.toast_gui then destroy(worlds);s.toast_gui=nil end
   if now>=s.toast_until then s.toast_until=nil end
   return
  end
  if s.toast_gui then
   local alive=false;for _,w in ipairs(worlds)do if w==s.world then alive=true end end
   if alive then return end
   destroy(worlds);s.toast_gui=nil
  end
  if now<(s.toast_retry_at or 0)then return end
  s.toast_retry_at=now+500
  local main=E.Application.main_world();local world
  for _,w in ipairs(worlds)do if w~=main then world=w;break end end
  if not world then return end
  s.world=world;s.gui=E.World.create_screen_gui(world,'scale',1,1);stats.gui_created=stats.gui_created+1
  if not s.gui then return end
  s.font,s.material,s.font_hashed=font_for(s.gui)
  local font,material
  if s.font then font,material=resources()end
  if not font then destroy(worlds);return end
  local W,H=E.Gui.resolution()
  if not W or not H or W<=0 or H<=0 then destroy(worlds);return end
  local sc=math.min(W*.94/1400,H*.88/900)
  local text_=s.toast_text;if #text_>110 then text_=text_:sub(1,107)..'...' end
  local w=math.floor(math.min(W*.9,(#text_*9.2+48)*sc));local h=math.floor(44*sc)
  local x=math.floor((W-w)/2);local y=math.floor(H*.10) -- screen GUI origin is bottom-left
  local G=E.Gui
  local edge=s.toast_bad and E.Color(255,230,170,40) or E.Color(255,90,200,110)
  G.rect(s.gui,E.Vector3(x,y,945),E.Vector2(w,h),E.Color(225,10,9,11))
  G.rect(s.gui,E.Vector3(x,y,946),E.Vector2(math.max(2,math.floor(4*sc)),h),edge)
  G.text(s.gui,text_,font,math.max(9,math.floor(16*sc)),material,E.Vector3(x+math.floor(18*sc),y+math.floor(15*sc),947),E.Color(255,241,234,235))
  s.toast_gui=true
 end
 toast_tick=function()
  if s.toast_disabled then return end
  local ok,why=pcall(toast_draw)
  if not ok then
   s.toast_disabled=true;s.toast_until=nil
   pcall(destroy,E.Application.worlds()or{});s.toast_gui=nil
   pcall(trace,'banner_disabled_after_error '..tostring(why))
  end
 end
 function s.pump()
  -- Sample native bindings before modal capture. Escape/X close the panel.
  binding.poll()
  local binding_hit=binding.pressed()
  local was_open=s.open
  if not s.open then
   local down=U.GetAsyncKeyState(0x74)<0
   local fallback_hit=down and not s.keys[0x74];s.keys[0x74]=down
   local hit=binding.registered and binding_hit or (not binding.registered and fallback_hit)
   if not hit or not focused()then toast_tick();return end
   if s.toast_gui then destroy(E.Application.worlds()or{});s.toast_gui=nil end
   s.open=true;s.fault=nil;s.paint_stamp=nil;s.first_paint_reported=false
   stats={gui_created=0,gui_destroyed=0,paints=0,primitive_writes=0};trace('opened renderer=stingray')
  end
  s.now=tonumber(K.GetTickCount64())
  local worlds=E.Application.worlds()or{}
  -- F7 belongs to the Mission Reroller on the galactic map. Close and
  -- release our cursor/input ownership without stealing that hotkey.
  if not binding.registered and (U.GetAsyncKeyState(0x76)<0 or (not s.edit and
      (U.GetAsyncKeyState(0x37)<0 or U.GetAsyncKeyState(0x67)<0))) then
   close(worlds);trace('yielded_reroller_hotkey_to_other_mod');return
  end
  local window=focused();local d,h=snapshot(window~=nil)
  if was_open and not binding.registered and h[0x74]then close(worlds);return end
  if not window then release_input(false);destroy(worlds);cursor(false);return end
  if not s.fault then keyboard(d,h,worlds)elseif h[27]then close(worlds)end
  if not s.open then return end
  local world;local main=E.Application.main_world()
  for _,w in ipairs(worlds)do if w==s.world and w~=main then world=w;break end end
  if not world then for _,w in ipairs(worlds)do if w~=main then world=w;break end end end
  if not world then release_input();destroy(worlds);cursor(false);return end
  if s.world~=world then destroy(worlds)end
  if not s.gui then
   assert(type(E.Gui.destroy_rect)=='function'and type(E.Gui.destroy_text)=='function','Retained GUI APIs unavailable')
   s.phase='create_gui';s.world=world;s.gui=E.World.create_screen_gui(world,'scale',1,1)
   stats.gui_created=stats.gui_created+1
   s.paint_stamp=nil
  end
  if not s.gui then release_input();cursor(false);return end
  s.width,s.height=E.Gui.resolution()
  if not s.width or not s.height or s.width<=0 or s.height<=0 then destroy(worlds);release_input();cursor(false);return end
  s.scale=math.min(s.width*.94/1400,s.height*.88/900)
  s.ox=(s.width-1400*s.scale)/2;s.oy=(s.height-900*s.scale)*position_ratio[s.position]
  -- IdString64 is frame-local temporary storage, not a persistent resource
  -- handle. Keep only hex/name strings in s; reconstruct IDs on this frame.
  -- Test6.14-17 cached the temporary IDs, causing a destroy/recreate cycle
  -- when can_get inspected reused temporary storage on the next update.
  if not s.font then
   s.phase='font_binding'
   s.font,s.material,s.font_hashed=font_for(s.gui)
  end
  if not s.font then
   release_input();cursor(false)
   if not s.font_wait then trace('waiting_for_loaded_gui_font');s.font_wait=true end
   return
  end
  local font,material
  if s.now>=(s.next_font_check or 0)then
   font,material=resources()
   if not font then destroy(worlds);s.font_wait=true;release_input();cursor(false);return end
   s.next_font_check=s.now+250
  end
  s.font_wait=false
  if s.fault then release_input()
  else
   s.phase='input_capture'
   if not input_guard then input_guard=new_panel_input(ffi,U,K,trace)end
   input_guard.hold(window,s.now,s.edit==nil)
  end
  cursor(true)
  local x,y=mouse(window);local hit
  if x and s.region_page==model.page and s.region_faction==model.faction then
   for _,v in ipairs(s.regions)do if x>=v.x and x<v.x+v.w and y>=v.y and y<v.y+v.h then hit=v;break end end
  end
  s.hover=hit and hit.id or nil
  if not d[1]then s.drag=nil;s.held_button=nil end
  if s.drag then
   if s.drag.page~=model.page or not model.tab_enabled()then s.drag=nil
   elseif x then model.slide(s.drag.row,(x-s.drag.x)/s.drag.w)end
  end
  local now=s.now
  if s.held_button and d[1]and not h[1]then
   if not hit or hit.id~=s.held_button.id then s.held_button=nil
   elseif now>=s.held_button.next then action(hit.id,worlds,d[16]);s.held_button.next=now+80 end
  end
  local state=s.paint_state;local edit=s.edit;local drag=s.drag
  local edit_row,edit_text=edit and edit.row,edit and edit.text
  local drag_row=drag and drag.row
  local changed=not state or not s.paint_stamp or s.invalidate
   or state.revision~=model.revision or state.page~=model.page or state.selected~=model.selected
   or state.dirty~=model.dirty or state.message~=model.message or state.width~=s.width or state.height~=s.height
   or state.position~=s.position or state.hover~=s.hover or state.edit_row~=edit_row
   or state.edit_text~=edit_text or state.drag_row~=drag_row or state.fault~=s.fault
  if changed then
   font,material=resources()
   if not font then destroy(worlds);s.font_wait=true;release_input();cursor(false);return end
   s.next_font_check=s.now+250
   s.phase='draw';draw(font,material);s.phase='ready';s.paint_stamp=true;s.invalidate=false
   state=state or {};s.paint_state=state
   state.revision,state.page,state.selected=model.revision,model.page,model.selected
   state.dirty,state.message=model.dirty,model.message
   state.width,state.height,state.position=s.width,s.height,s.position
   state.hover,state.edit_row,state.edit_text,state.drag_row,state.fault=s.hover,edit_row,edit_text,drag_row,s.fault
  end
  if h[1]and not s.fault and x then
   for _,v in ipairs(s.regions)do if x>=v.x and x<v.x+v.w and y>=v.y and y<v.y+v.h then
    local row=v.id:match('^slider:(%d+)$')
    if row then
     if finish(false)then
      row=tonumber(row);s.drag={row=row,page=model.page,x=v.track_x,w=v.track_w};model.selected=row
      model.slide(row,(x-v.track_x)/v.track_w)
     end
    else
     action(v.id,worlds,d[16])
     if v.id:match('^minus:')or v.id:match('^plus:')then s.held_button={id=v.id,next=now+350}end
    end
    break
   end end
  end
  -- A click can enter numeric editing after hold() sampled the previous state.
  if input_guard and s.edit then input_guard.set_digit_passthrough(false)end
 end
 local pump=s.pump
 local function stop_after_failure(why)
  -- Never try to render an error with the same renderer that just failed.
  -- Stop first, then independently release every resource; cleanup failures
  -- must not prevent input/cursor restoration or start another draw loop.
  s.open=false;s.fault=tostring(why);s.edit=nil;s.drag=nil;s.held_button=nil
  s.regions={};s.paint_stamp=nil
  local focus_ok,window=pcall(focused)
  pcall(release_input,focus_ok and window~=nil)
  local ok,worlds=pcall(E.Application.worlds)
  if ok then pcall(destroy,worlds or {})end
  pcall(cursor,false)
  -- This is one line per opening attempt, not one line per update.
  pcall(trace,'disabled_after_error phase='..tostring(s.phase)..' '..s.fault..' gui_destroyed='..tostring(s.gui==nil)..' retry=manual_open_only')
 end
 function s.pump()
  local started=s.open and tonumber(K.GetTickCount64())or nil
  local ok,why=pcall(pump)
  if not ok then stop_after_failure(why);return end
  if s.open and started then
   local elapsed=tonumber(K.GetTickCount64())-started
   -- Stop sustained expensive panel work. This measures CPU-side UI time,
   -- not overall game FPS/GPU cost, and does not claim to measure either.
   if elapsed>=16 then s.slow_frames=(s.slow_frames or 0)+1
   else s.slow_frames=0 end
   if s.slow_frames>=3 then stop_after_failure('panel_work_budget_exceeded last_ms='..elapsed)end
  else s.slow_frames=0 end
 end
 trace('ready hotkey=ModBindingsMenu_or_F5 renderer=stingray fail_closed=true manual_retry_only=true stable_retained_primitives=true bounded_layers=940-952 resource_ids=frame_local input_capture=true sliders=enabled tab_toggle=F6 callback_free=true')
 return s
end
-- Local only; no shared JIT changes or Lua-to-native window callbacks.
if jit then jit.off(start_aar_panel,true)end

local runtime = (function()
return function(make_reader, make_memory, make_engine, profile)
    if rawget(_G, 'PickYourBots') or rawget(_G, 'AllAutomatonReplace') then return end
    local state = {status = 'initializing', frame = 0}
    _G.PickYourBots = state
    _G.AllAutomatonReplace = state -- compatibility guard against loading both versions

    local loader = rawget(_G, 'CowboyBingusModLoader')
    local log_dir = (type(loader) == 'table' and type(loader.log_directory) == 'string'
                     and loader.log_directory ~= '' and loader.log_directory)
                    or ((os.getenv('LOCALAPPDATA') or '') .. '/CowboyBingus/Helldivers2/Logs')
    local STEM = 'PickYourBots'

    local function open_out(name)
        local ok, f = pcall(io.open, log_dir .. '/' .. name, 'wb')
        if ok and f then return f end
        if type(loader) == 'table' and type(loader.open_log) == 'function' then
            local ok2, f2 = pcall(loader.open_log, name)
            if ok2 and f2 then return f2 end
        end
        return nil
    end
    local function write_text(name, text)
        local f = open_out(name)
        if not f then return false end
        pcall(function() f:write(text) end)
        pcall(f.flush, f)
        pcall(f.close, f)
        return true
    end

    -- Test38 roster cache: one snapshot per distinct faction / difficulty / mission tags / roster. Appended, never
    -- rewritten; keys already in the file are skipped. Used for offline mix checks against real rosters.
    local cache_keys
    function state.cache_roster(key, text)
        if not cache_keys then
            cache_keys = {}
            local ok, f = pcall(io.open, log_dir .. '/' .. STEM .. '_roster_cache.txt', 'rb')
            if ok and f then
                for line in f:lines() do local k = line:match('^key=(.+)$'); if k then cache_keys[k] = true end end
                f:close()
            end
        end
        if cache_keys[key] then return false end
        local ok, f = pcall(io.open, log_dir .. '/' .. STEM .. '_roster_cache.txt', 'ab')
        if not ok or not f then return false end
        pcall(function() f:write('key=' .. key .. '\n' .. text .. '\n') end)
        pcall(f.close, f)
        cache_keys[key] = true
        return true
    end
    function state.publish_banner(text, bad, duration_ms)
        state.banner = {id = ((state.banner and state.banner.id) or 0) + 1,
            text = text, bad = bad == true, duration_ms = duration_ms}
    end
    -- Test38: keep the previous session's log (a crash or restart would otherwise overwrite the mission log).
    pcall(function()
        local f = io.open(log_dir .. '/' .. STEM .. '_log.txt', 'rb')
        if not f then return end
        local old = f:read('*a'); f:close()
        if old and #old > 0 then write_text(STEM .. '_log_previous.txt', old) end
    end)
    local logbuf, log_dirty, log_last = {}, false, 0
    local function emit(line)
        if #logbuf < 4000 then logbuf[#logbuf+1] = line; log_dirty = true end
    end
    local function flush_log(force)
        if not log_dirty and not force then return end
        log_dirty, log_last = false, os.clock()
        write_text(STEM .. '_log.txt', table.concat(logbuf, '\n') .. '\n')
    end
    local function flush_throttled()
        if log_dirty and os.clock() - log_last >= 2 then flush_log() end
    end

    local function conclusion_for(value)
        if value == 'active_terminids_replaced' then
            return 'OK - Terminid weighted tables active (live spawn results need validation)'
        end
        if value == 'active_automatons_replaced' then
            return profile.mix_enabled and 'OK - per-unit weighted tables installed (live spawn results need validation)' or 'OK - Automaton roster now spawns the target unit'
        end
        if value == 'patched_automatons_replaced' then
            return 'OK - target unit applied to the Automaton roster'
        end
        if value == 'disabled_in_menu' then return 'OK - switched off in the Master tab (the game data is back to normal)' end
        if value == 'scanning_for_roster' then return 'OK - locating the Automaton roster (content search)' end
        if value == 'scanning_for_header' then return 'OK - locating the roster header' end
        if value == 'scanning_for_director' then return 'OK - locating the director (candidate cache)' end
        if value == 'scanning_for_taskuser' then return 'OK - locating the TaskUser table (guard tasks)' end
        if value == 'roster_not_in_memory' then
            -- 飞船里本来就没有名录,进任务才有 —— 这不是失败,别吓用户
            return 'OK - waiting for the Automaton roster (it only exists inside an Automaton mission)'
        end
        if value == 'rescanning_for_roster_light' or value == 'rescanning_for_roster' then
            return 'OK - re-locating the Automaton roster (content search)'
        end
        if value == 'waiting_for_roster' then
            return 'OK - roster was in memory, waiting for it to come back'
        end
        if value:find('^mix_waiting:') then return 'PENDING - ' .. value end
        if value:find('^disabled') then return 'FAILED - ' .. value end
        if value:find('^stopped') then return 'FAILED - ' .. value end
        return 'OK - ' .. value
    end

    local CONFIG_KEYS = {'hulk_calls', 'rows', 'templates', 'candidates', 'variant_disable', 'source_rows',
                         'dump_rows', 'alpha_exempt', 'task_user', 'task_user_mask', 'guard_troopers', 'dump_variants'}
    local function read_config()
        local ov = {}
        local f = io.open(log_dir .. '/AllAutomatonReplace_config.txt', 'r')
        if not f then return ov end
        for line in f:lines() do
            local k, v = line:match('^%s*([%w_]+)%s*=%s*([%w_,%.%-]+)')
            if k and v then
                ov['raw_' .. k] = v:lower()      -- original token, for numeric settings (0 and 1 become booleans below)
                if v == 'true' or v == '1' then ov[k] = true
                elseif v == 'false' or v == '0' then ov[k] = false
                else ov[k] = v:lower() end
            end
        end
        f:close()
        return ov
    end
    -- ---------------------------------------------------------------- settings panel
    -- Settings saved by the panel use the existing config file and override
    -- the five settings below and are applied on the ship, like a config change.
    state.menu_overrides = state.menu_overrides or {}
    local function apply_master(profile,config)
        local menu=state.menu_overrides
        local function value(key,default)
            if menu[key]~=nil then return menu[key] end
            if config[key]~=nil then return config[key] end
            return default
        end
        local function number(key,default,min,max)
            local v=tonumber(menu[key]~=nil and menu[key] or config["raw_"..key] or value(key,default))
            if not v or v~=v or v<min or v>max then
                emit('master_invalid_setting '..key..' using_default='..default);return default
            end
            return v
        end
        local function multiplier(key,default,max,min)
            min=min or 1
            default=math.max(min,math.min(max,default))
            local old=number(key,default,0,1000)
            local bounded=math.max(min,math.min(max,old))
            if bounded~=old then emit('master_clamped_setting '..key..' from='..old..' to='..bounded)end
            return bounded
        end
        profile.disabled_by_menu=value('enabled',true)==false
        profile.hulk_calls=value('any_bot_calls',true)==true
        profile.disable_factory_production=value('disable_factory_production',false)==true
        do
            local choice=tonumber(value('factory_production_unit',1))
            if not choice or choice%1~=0 or not aar_factory_production.choices[choice]then
                emit('factory_production_unit_invalid using_native');choice=1
            end
            profile.factory_production_unit=choice
        end
        profile.factory_strider_calls=value('factory_strider_calls',true)==true
        profile.factory_strider_cap=math.floor(number('factory_strider_cap',15,1,30))
        profile.tanks_stay_tanks=value('tanks_stay_tanks',false)==true
        profile.reinforce_budget_multiplier=multiplier('reinforce_budget_multiplier',1.5,6,1)
        profile.reinforce_cooldown_reduction=number('reinforce_cooldown_reduction',20,0,90)
        -- Native curve multiplies the countdown RATE (Test25 observed 1.5625).
        profile.reinforce_cooldown_rate=1/(1-profile.reinforce_cooldown_reduction/100)
        profile.drop_cost_divisor=multiplier('drop_cost_divisor',1,20)
        profile.illuminate_calls=value('illuminate_calls',true)==true
        profile.illuminate_keep_native_watcher_patrols=value('illuminate_keep_native_watcher_patrols',true)==true
        profile.illuminate_drop_cost_divisor=multiplier('illuminate_drop_cost_divisor',1,20)
        profile.disable_leviathans=value('disable_leviathans',false)==true
        profile.bug_alpha_summon=value('bug_alpha_summon',true)==true
        do
            local saved=math.floor(number('bug_alpha_unit',10,1,12))
            -- Existing installs saved numeric indices for the old 11-unit list.
            -- Keep their selected identity where possible; removed choices
            -- move to the closest retained member of the same family.
            local legacy={1,2,2,3,5,6,7,6,8,9,10,10}
            profile.bug_alpha_unit=tonumber(value('bug_alpha_unit_schema',1))==2 and saved or legacy[saved]
        end
        profile.bug_breach_cost=multiplier('bug_breach_cost',1,1.5,0.25)
        profile.bug_breach_equalize_costs=value('bug_breach_equalize_costs',false)==true
        profile.bug_titan_replacement=math.floor(number('bug_titan_replacement',1,1,3))
        profile.bug_titan_cap=math.floor(number('bug_titan_cap',27,1,30))
        profile.bug_titan_resume_below=math.min(profile.bug_titan_cap,math.floor(number('bug_titan_resume_below',20,1,30)))
        for _,k in ipairs({'bug_charger_calls','bug_stalker_calls','bug_titan_calls','bug_shrieker_calls','bug_call_cloud'})do profile[k]=value(k,false)==true end
        profile.spawn_multiplier=number('spawn_multiplier',1.15,1,5)
        profile.patrol_extra_troopers=number('patrol_extra_troopers',0,0,4)
        if profile.patrol_extra_troopers~=0 and profile.patrol_extra_troopers~=2 and profile.patrol_extra_troopers~=3 and profile.patrol_extra_troopers~=4 then
            emit('patrol_extra_troopers_invalid using_default=0');profile.patrol_extra_troopers=0
        end
        -- Older configs migrate implicitly: each new control inherits the saved
        -- combined multiplier until explicitly saved independently.
        profile.patrol_count_multiplier=multiplier('patrol_count_multiplier',profile.spawn_multiplier,6)
        profile.patrol_size_multiplier=multiplier('patrol_size_multiplier',profile.spawn_multiplier,2)
        profile.patrol_cooldown_rate=multiplier('patrol_cooldown_rate',1,6)
        profile.fast_corpses=value('fast_corpses',false)==true
        profile.spawn_tuning=true -- Factory population governor needs the native curves even at 1x.
        profile.guard.retag_cost=nil;profile.drop_fill.fill=0;profile.patrol.counts={}
        profile.mix_enabled=true
        state.menu_line=string.format('enabled=%s any_bot_calls=%s budget=%.2f cooldown_reduction=%.0f%% spawn=%.2f',
            tostring(not profile.disabled_by_menu),tostring(profile.hulk_calls),profile.reinforce_budget_multiplier,
            profile.reinforce_cooldown_reduction,profile.spawn_multiplier)
        state.menu_line=state.menu_line..string.format(' patrol_count=%.2f patrol_size=%.2f patrol_cooldown_rate=%.2f fast_corpses=%s',
            profile.patrol_count_multiplier,profile.patrol_size_multiplier,profile.patrol_cooldown_rate,tostring(profile.fast_corpses))
        state.menu_line=state.menu_line..' drop_cost_divisor='..tostring(profile.drop_cost_divisor)..' disable_factory_production='..tostring(profile.disable_factory_production)..' factory_production_unit='..tostring(profile.factory_production_unit)..' factory_strider_calls='..tostring(profile.factory_strider_calls)
        state.menu_line=state.menu_line..' illuminate_calls='..tostring(profile.illuminate_calls)..' keep_native_watcher_patrols='..tostring(profile.illuminate_keep_native_watcher_patrols)..' illuminate_drop_cost_divisor='..tostring(profile.illuminate_drop_cost_divisor)..' disable_leviathans='..tostring(profile.disable_leviathans)
    end

    local function configure(profile)
    state.mask_overridden, state.target_overridden = nil, nil
    state.trooper_extra_line, state.keep_line = nil, nil
    local ov = read_config()
    profile.hulk_calls = ov.hulk_calls ~= false
    do
        local function le_of(name)
            if type(name) ~= 'string' then return nil end
            if name:match('^%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x%x$') then return name:lower() end
            return profile.names[name] or (profile.units and profile.units[name])
        end
        if type(ov['target']) == 'string' then
            if le_of(ov['target']) then
                profile.target_le = le_of(ov['target']); profile.target_name = ov['target']
                profile.targets = {}
            else
                emit('config_unknown_target=' .. ov['target'] .. ' (using ' .. profile.target_name .. ')')
            end
        end
        if type(ov['targets']) == 'string' then
            local list = {}
            for name in ov['targets']:gmatch('[^,]+') do
                if le_of(name) then list[#list + 1] = name else emit('config_unknown_targets_name=' .. name) end
            end
            if #list > 0 then
                profile.targets = list
                profile.target_le = le_of(list[1]); profile.target_name = list[1]
            end
        end
        local keep_names = profile.keep_names_default
        if type(ov['keep']) == 'string' then
            keep_names = {}
            if ov['keep'] ~= 'none' then
                for name in ov['keep']:gmatch('[^,]+') do keep_names[#keep_names + 1] = name end
            end
        end
        profile.keep_entities_le = {}
        for _, name in ipairs(keep_names) do
            if le_of(name) then profile.keep_entities_le[#profile.keep_entities_le + 1] = le_of(name)
            else emit('config_unknown_keep_name=' .. name) end
        end
        state.keep_line = table.concat(keep_names, ',')
        if type(ov['guard_retag']) == 'string' then
            if #ov['guard_retag'] == 8 and ov['guard_retag']:match('^[0-9a-f]+$') then
                profile.guard.retag = ov['guard_retag']
            else
                emit('config_bad_guard_retag=' .. ov['guard_retag'] .. ' (8 hex characters expected)')
            end
        end
        if type(ov['drop_units']) == 'string' then
            profile.guard.retag_units = {}
            for name in ov['drop_units']:gmatch('[^,]+') do
                if name == 'none' then
                elseif le_of(name) then profile.guard.retag_units[#profile.guard.retag_units + 1] = name
                else emit('config_unknown_drop_unit=' .. name) end
            end
        end
        if type(ov['raw_drop_cost']) == 'string' then
            local n = tonumber(ov['raw_drop_cost'])
            if n == 0 then profile.guard.retag_cost = nil
            elseif n and n > 0 and n < 10000 then profile.guard.retag_cost = n
            else emit('config_bad_drop_cost=' .. ov['raw_drop_cost']) end
        end
        if type(ov['raw_patrol_groups']) == 'string' then
            profile.patrol.groups = {}
            for token in ov['raw_patrol_groups']:gmatch('[^,]+') do
                local n = tonumber(token)
                if n then profile.patrol.groups[#profile.patrol.groups + 1] = math.floor(n) end
            end
        end
        if type(ov['raw_patrol_troopers']) == 'string' then
            profile.patrol.counts = {}
            for token in ov['raw_patrol_troopers']:gmatch('[^,]+') do
                local n = tonumber(token)
                if n == 0 then
                elseif n and n >= 1 and n <= 20 then profile.patrol.counts[#profile.patrol.counts + 1] = math.floor(n)
                else emit('config_bad_patrol_troopers=' .. token) end
            end
        end
        if type(ov['patrol_trooper_tag']) == 'string' then
            if #ov['patrol_trooper_tag'] == 8 and ov['patrol_trooper_tag']:match('^[0-9a-f]+$') then
                profile.patrol.tag = ov['patrol_trooper_tag']
            else
                emit('config_bad_patrol_trooper_tag=' .. ov['patrol_trooper_tag'])
            end
        end
        if type(ov['raw_poi_trooper_every']) == 'string' then
            local n = tonumber(ov['raw_poi_trooper_every'])
            if n == 0 then profile.poi.every = 0
            elseif n and n >= 2 and n <= 64 then profile.poi.every = math.floor(n)
            else emit('config_bad_poi_trooper_every=' .. ov['raw_poi_trooper_every'] .. ' (2 to 64, 0 or absent = off)') end
        end
        if type(ov['raw_poi_trooper_phase']) == 'string' then
            local n = tonumber(ov['raw_poi_trooper_phase'])
            if n and n >= 0 and n <= 63 then profile.poi.phase = math.floor(n) end
        end
        if type(ov['trooper_extra']) == 'string' then
            for name in ov['trooper_extra']:gmatch('[^,]+') do
                if name == 'none' then
                elseif le_of(name) then profile.trooper_names[#profile.trooper_names + 1] = name
                else emit('config_unknown_trooper_extra=' .. name) end
            end
            state.trooper_extra_line = ov['trooper_extra']
        end
        if type(ov['raw_drop_fill']) == 'string' then
            local n = tonumber(ov['raw_drop_fill'])
            if n == 0 then profile.drop_fill.fill = 0
            elseif n and n >= 2 and n <= 12 then profile.drop_fill.fill = math.floor(n)
            else emit('config_bad_drop_fill=' .. ov['raw_drop_fill'] .. ' (2 to 12, 0 = off)') end
        end
        if type(ov['raw_drop_fill_groups']) == 'string' then
            profile.drop_fill.groups = {}
            for token in ov['raw_drop_fill_groups']:gmatch('[^,]+') do
                local n = tonumber(token)
                if n then profile.drop_fill.groups[#profile.drop_fill.groups + 1] = math.floor(n) end
            end
        end
        if type(ov['guard_others']) == 'string' then
            profile.guard.others = (ov['guard_others'] == 'trooper') and 'trooper' or 'target'
        end
        if type(ov['guard_units']) == 'string' then
            profile.guard.units = {}
            for name in ov['guard_units']:gmatch('[^,]+') do
                if le_of(name) then profile.guard.units[#profile.guard.units + 1] = name
                else emit('config_unknown_guard_unit=' .. name) end
            end
        end
        if type(ov['raw_guard_groups']) == 'string' then
            profile.guard.groups = {}
            for token in ov['raw_guard_groups']:gmatch('[^,]+') do
                local n = tonumber(token)
                if n then profile.guard.groups[#profile.guard.groups + 1] = math.floor(n) end
            end
        end
    end
    profile.config = profile.config or {}
    for _, k in ipairs(CONFIG_KEYS) do
        if ov[k] ~= nil then profile.config[k] = ov[k] end
    end
    -- alpha_exempt=false → 阿尔法指挥官也一起替换(默认豁免)
    if profile.config['alpha_exempt'] == false then profile.keep_entities_le = nil end
    -- task_user=false → 不改任务组掩码;task_user_mask=0x… → 自定义掩码
    if profile.config['task_user'] == false then profile.task_user.mask = 0 end
    do
        local m = profile.config['task_user_mask']
        if type(m) == 'string' then
            local n = tonumber(m)
            if n and n >= 0 and n <= 4294967295 then
                profile.task_user.mask = math.floor(n)
                state.mask_overridden = true
            end
        end
    end
    if type(ov['target_le']) == 'string' and #ov['target_le'] == 16
        and ov['target_le']:match('^[0-9a-fA-F]+$') then
        profile.target_le = ov['target_le']:lower()
        state.target_overridden = true
    end
    do
        local parts = {}
        for _, k in ipairs(CONFIG_KEYS) do
            if k ~= 'dump_rows' then
                local v = profile.config[k]
                if type(v) == 'string' then parts[#parts+1] = k .. '=' .. v
                else parts[#parts+1] = k .. '=' .. (v == false and '0' or '1') end
            end
        end
        state.config_line = 'switch ' .. table.concat(parts, ' ')
            .. (state.target_overridden and ' target_overridden=1' or '')
    end
    apply_master(profile,ov)
    unit_mix.configure(profile, ov, state.menu_overrides, emit)
    end
    configure(profile)

local function build_bug_profile(bot)
 local p={}
 for k,v in pairs(bot)do p[k]=v end
 local names={}
 names['Scavenger MK2']='4e7e99f66ba8ee51'
 names['Scavenger MK3']='0c237b28ae3a8a9a'
 names['Bile Spitter']='3ddbd6ce493ea872'
 names['Pouncer']='d98f5e6f5938b4aa'
 names['Warrior MK2']='b96be4a113e339be'
 names['Warrior MK3']='dc9c7cecc41f5432'
 names['Hive Guard']='e4bd0fa4f27bf3a1'
 names['Hive Guard']='e4bd0fa4f27bf3a1'
 names['Bile Warrior']='f63e16f6ce1a0810'
 names['Hive Guard']='e4bd0fa4f27bf3a1'
 names['Hunter MK2']='cae174d5e2030e3d'
 names['Hunter MK3']='bac045744432a85c'
 names['Brood Commander']='a543d44847fd22d5'
 names['Charger']='b064c698ffcd7f1a'
 names['Charger Behemoth MK2']='4cacb367ecd15ba0'
 names['Bile Spewer']='4601e6e5cc99aa36'
 names['Bile Spewer MK2']='b791d5ac6452aecc'
 names['Bile Titan']='ddafccccf2172e9e'
 names['Stalker']='2e424a9d9dca40f5'
 names['Scavenger MK2 (Captive)']='dc48a977d9cbbadf'
 names['Warrior MK2 (Captive)']='4b7adc3b07fb974e'
 names['Nursing Spewer MK2']='9b0872d1fd2270cc'
 names['Warrior MK3']='dc9c7cecc41f5432'
 names['Hive Guard']='e4bd0fa4f27bf3a1'
 names['Charger Behemoth']='990b45d5d75fff3a'
 names['Shrieker']='dd35245088000964'
 names['Nursing Spewer']='883d333823e22160'
 names['Warrior MK2']='b96be4a113e339be'
 names['Impaler']='3beefb1242e7f8dc'
 names['Tentacle']='4aa33b7fa17d2f67'
 names['Alpha Commander']='df974365bbd89cf7'
 names['Warrior (Spawned)']='e6c784421efaa6b2'
 names['Spore Charger']='5e60abf49223206b'
 names['Predator Hunter']='f6a5982aaf013488'
 names['Predator Stalker']='525a2df2ba90e9d1'
 names['Hive Lord']='cb077af7c7d965d4'
 names['Dragonroach']='aafaa321a4480b96'
 names['Rupture Spewer']='94ebd3071ca181a3'
 names['Rupture Warrior']='060815f2c60752a3'
 names['Rupture Charger']='8c221c132bb9b70a'
 names['Spore Burst Bile Titan']='97a497d084cb04ef'
 names['Spore Burst Warrior']='bc0e441d35218472'
 names['Spore Burst Hunter']='e004009c72910a1f'
 names['Spore Burst Scavenger']='01f51cbe314696db'
 names['Shrieker']='dd35245088000964'
 p.names=names;p.units=names
 p.entities_le={'4e7e99f66ba8ee51','0c237b28ae3a8a9a','3ddbd6ce493ea872','d98f5e6f5938b4aa','b96be4a113e339be','dc9c7cecc41f5432','e4bd0fa4f27bf3a1','f63e16f6ce1a0810','cae174d5e2030e3d','bac045744432a85c','a543d44847fd22d5','b064c698ffcd7f1a','4cacb367ecd15ba0','4601e6e5cc99aa36','b791d5ac6452aecc','ddafccccf2172e9e','2e424a9d9dca40f5','dc48a977d9cbbadf','4b7adc3b07fb974e','9b0872d1fd2270cc','990b45d5d75fff3a','dd35245088000964','883d333823e22160','3beefb1242e7f8dc','4aa33b7fa17d2f67','df974365bbd89cf7','e6c784421efaa6b2','5e60abf49223206b','f6a5982aaf013488','525a2df2ba90e9d1','cb077af7c7d965d4','aafaa321a4480b96','94ebd3071ca181a3','060815f2c60752a3','8c221c132bb9b70a','97a497d084cb04ef','bc0e441d35218472','e004009c72910a1f','01f51cbe314696db','0378893c654752fd'}
 p.keep_entities_le={'dc48a977d9cbbadf','4b7adc3b07fb974e','dd35245088000964','4aa33b7fa17d2f67','e6c784421efaa6b2','cb077af7c7d965d4','aafaa321a4480b96','0378893c654752fd'}
 p.trooper_names={};p.trooper_le={};p.drop_cost_divisor=1;p.patrol_extra_troopers=0
 p.groups={{32,39},{64,27},{80,50},{112,8}}
 p.slot_offsets={0x660};p.patrol={groups={32},counts={},tag=''}
 p.guard={retag_cost=nil};p.drop_fill={groups={80},fill=0}
 p.version=bot.version
 bug_mix.configure(p,read_config(),state.menu_overrides or {},emit)
 p.alpha_summon_rows=bug_special_controls.roster
 return p
end

    local function build_illuminate_profile(bot)
        local p={};for k,v in pairs(bot)do p[k]=v end
        local names={
            ['Voteless Light']='472c01717549e178',
            ['Voteless Medium']='1d8ead73919fdc0a',
            ['Voteless Heavy']='fb02b0522c8a4544',
            ['Overseer']='f247747c34bb40da',
            ['Elevated Overseer']='20b85bc44e794a60',
            ['Crescent Overseer']='6de458a90a9af1e8',
            ['Watcher']='9d8c093584e760ac',
            ['Fleshmob']='332df0a4dc32dc67',
            ['Stingray']='4ad955ec468be119',
            ['Harvester']='4addac515aae5e96',
            ['Leviathan']='07f1be377b022df2',
            ['Veracitor']='65adae4d73c7b920',
            ['Gatekeeper']='0fb34e632ce23f45',
            ['Obtruder']='9e2e476533d2df34',
            ['Crusher']='458a8dc2a4095890',
            ['Wretch']='6c5c50800c8f18cc',
        }
        p.names=names;p.units=names
        p.entities_le={'472c01717549e178','1d8ead73919fdc0a','fb02b0522c8a4544',
            'f247747c34bb40da','20b85bc44e794a60','6de458a90a9af1e8','9d8c093584e760ac',
            '332df0a4dc32dc67','4ad955ec468be119','4addac515aae5e96','07f1be377b022df2',
            '65adae4d73c7b920','0fb34e632ce23f45','9e2e476533d2df34','458a8dc2a4095890',
            '6c5c50800c8f18cc','3b97ea83bbd7fda8'}
        p.keep_entities_le={'3b97ea83bbd7fda8'} -- unidentified, mission-gated row
        p.trooper_names={};p.trooper_le={};p.patrol_extra_troopers=0
        p.patrol={groups={},counts={},tag=''};p.drop_fill={groups={80},fill=0}
        p.tanks_stay_tanks=false;p.drop_cost_divisor=p.illuminate_drop_cost_divisor or 1
        p.groups={{32,256},{48,256},{64,256},{80,256},{96,256},{112,256},{128,256},{144,256}}
        p.slot_offsets={0x660} -- never touch Illuminate worker/civilian +0x668/+0x670
        illuminate_mix.configure(p,read_config(),state.menu_overrides or {},emit)
        if p.disable_leviathans then p.keep_entities_le[#p.keep_entities_le+1]='07f1be377b022df2' end
        return p
    end
    local bug_profile=build_bug_profile(profile)
    local illuminate_profile=build_illuminate_profile(profile)

    local api = type(loader) == 'table' and tonumber(loader.api) or nil
    local version = type(loader) == 'table' and tostring(loader.version) or '?'
    if not api then
        local ok, head = pcall(function()
            local f = io.open(log_dir .. '/BingusSharedLoader.log', 'rb')
            if not f then return nil end
            local s = f:read(512); f:close(); return s
        end)
        if ok and type(head) == 'string' then
            api = tonumber(head:match('API%s*(%d+)'))
            version = head:match('loader%-v(%d+)') or version
        end
    end
    if not api or api < 1 then
        state.status = 'disabled: loader_api_unsupported'
        write_text(STEM .. '_STATUS.txt', table.concat({
            'FAILED - Bingus Shared Loader v15+ / API 1 required (detected api=' .. tostring(api)
                .. ', loader=' .. tostring(version) .. ')',
            'mod=pick_your_bots name=Pick your bots version=' .. profile.version,
            'loader_api=' .. tostring(api) .. ' loader_version=' .. tostring(version) .. ' phase=aborted',
            'action=enable Bingus Shared Loader v15 or newer, then restart the game',
        }, '\n') .. '\n')
        return
    end

    local settings_panel
    local factory_production_instance
    local function status(value)
        -- 状态没变也要周期性重写:带上运行时长,用户才能看出"还活着、扫到哪了"
        local now = os.clock()
        if state.status == value and (state.last_status_write or 0) + 20 > now then return end
        local changed = state.status ~= value
        state.status = value
        state.last_status_write = now
        print('[' .. STEM .. '] ' .. value)
        emit('status=' .. value)
        flush_log(true)
        local copies, headers, cached = 0, 0, 0
        local low_conf, director_addr = 'no', 'n/a'
        local tu_blocks, tu_fixed, tu_mask = 0, 0, 0
        if state.patch then
            for _ in pairs(state.patch.rosters or {}) do copies = copies + 1 end
            for _ in pairs(state.patch.headers or {}) do headers = headers + 1 end
            cached = state.patch.cached_replacements or 0
            low_conf = state.patch.low_confidence and 'yes' or 'no'
            director_addr = state.patch.director_addr
                and string.format('0x%x', state.patch.director_addr) or 'not found'
            for _ in pairs(state.patch.behavior_blocks or {}) do tu_blocks = tu_blocks + 1 end
            tu_fixed = state.patch.taskuser_fixed or 0
            tu_mask = state.patch.taskuser_mask or profile.task_user.mask
        end
        write_text(STEM .. '_STATUS.txt', table.concat({
            conclusion_for(value),
            'mod=pick_your_bots name=Pick your bots version=' .. profile.version .. ' (AAR Overhaul Test6; acceptance-gated ground-bot caller)',
            'loader_api=' .. tostring(api) .. ' loader_version=' .. tostring(version),
            'target=' .. tostring(profile.target_name or 'custom') .. ' entity=' .. profile.target_le
                .. (#(profile.targets or {}) > 0 and (' targets=' .. table.concat(profile.targets, ',')) or '')
                .. ' keep=' .. tostring(state.keep_line or ''),
            'unit_percentage_mode=' .. (profile.mix_enabled and 'ON: see PickYourBots_mix.txt; tab enable switches and saved patrol extras are active; legacy preset is inactive' or 'OFF: legacy settings below apply'),
            'trooper_extra=' .. tostring(state.trooper_extra_line or ''),
            'tuning_status='..tostring(state.tuning_status or 'waiting')..' '..tostring(state.menu_line),
            'mission_faction='..tostring(state.mission_faction or 'unknown')..' shared_master_spawn_controls=all_factions weights=faction_specific bot_features=automatons_only',
            'corpse_cleanup_status='..tostring(state.cleanup_status or 'disabled'),
            'trooper_preservation=guards_and_outposts_original_trooper_rows; includes_MG_and_non_MG; percentages_apply_to_remaining_rows',
            'tank_variants='..tostring(state.patch and state.patch.tank_variants or 0)..' tanks_stay='..tostring(state.patch and state.patch.tanks_stay or false),
            'factory_production='..(factory_production_instance and factory_production_instance.core.summary or 'unavailable'),
            'factory_production_unit='..tostring(profile.factory_production_unit or 1)..' name='..aar_factory_production.choices[profile.factory_production_unit or 1][1],
            'strider_controls='..(factory_production_instance and factory_production_instance.striders.summary or 'unavailable'),
            string.format('memory_reads_per_second=%s (last %ds window; 1.3.2 batches reads)',state.reads_per_second and string.format('%.0f',state.reads_per_second)or 'measuring',10),
            'factory_population=alive:'..tostring(state.factory_alive or 'unknown')..' paused:'..tostring(profile.factory_cap_paused)..' reason:'..tostring(state.factory_population_reason or 'waiting')..' gate:'..tostring(profile.factory_strider_cap or 15)..' resume_at:'..tostring((profile.factory_strider_cap or 15)-1)..' patrol_factory_per_template:2',
            'titan_dragonroach_population=alive:'..tostring(state.bug_heavy_alive or 'unknown')..' titan_selection_blocked:'..tostring(profile.bug_cap_paused)..' selection_status:'..tostring(state.bug_cap_selection_status or 'waiting')..' reason:'..tostring(state.bug_population_reason or 'waiting')..' pause_at:'..tostring(profile.bug_titan_cap or 27)..' resume_below:'..tostring(profile.bug_titan_resume_below or 20),
            'any_bot_calls=' .. (profile.hulk_calls and 'enabled' or 'disabled') .. ' (host; director acceptance before flare; gunships deferred)',
            string.format('drop_fill=%d groups=%s raised=%d', profile.drop_fill.fill or 0,
                table.concat(profile.drop_fill.groups or {}, ','), state.patch and state.patch.filled or 0),
            string.format('poi_trooper_every=%d phase=%d rows_converted=%d', profile.poi.every or 0, profile.poi.phase or 1,
                state.patch and state.patch.poi_rows or 0),
            string.format('patrol_troopers=%s groups=%s tag=%s added=%d',
                table.concat(profile.patrol.counts or {}, ','), table.concat(profile.patrol.groups or {}, ','),
                tostring(profile.patrol.tag), state.patch and state.patch.patrol_added or 0),
            string.format('drop_tag=%s drop_units=%s drop_cost=%s', tostring(profile.guard.retag),
                table.concat(profile.guard.retag_units or {}, ','), tostring(profile.guard.retag_cost)),
            string.format('guard=%s others=%s groups=%s trooper_rows_kept=%d guard_rows_converted=%d retagged=%d',
                profile.config['guard_troopers'] == false and 'off' or 'on', tostring(profile.guard.others),
                table.concat(profile.guard.groups, ','),
                state.patch and state.patch.guard_rows_kept or 0, state.patch and state.patch.guard_rows_converted or 0,
                state.patch and state.patch.retagged or 0),
            state.config_line,
            string.format('config_reloads=%d', state.reloads or 0),
            'panel=' .. (settings_panel and 'ready; Mod Bindings Menu / F5 fallback' or 'unavailable; use config file') .. ' ' .. tostring(state.menu_line or '')
                .. (state.menu_pending and ' PENDING: applies when you are on the ship' or '')
                .. ' game_mode=' .. tostring(state.game_mode),
            string.format('phase=%s rosters=%d headers=%d writes=%s low_conf=%s best_partial_run=%s',
                value, copies, headers, tostring(state.patch and state.patch.patched or 0), low_conf,
                tostring(state.patch and state.patch.best_run or 0)),
            string.format('director=%s director_rva=%s cached_replaced=%d scans=%d absent_rounds=%d uptime=%.0fs%s',
                director_addr, tostring(state.patch and state.patch.director_rva or 'n/a'),
                cached, state.patch and state.patch.scan_attempts or 0,
                state.patch and state.patch.absent_rounds or 0, now,
                changed and '' or ' (periodic refresh)'),
            string.format('taskuser_blocks=%d taskuser_fixed=%d mask=0x%X',
                tu_blocks, tu_fixed, tu_mask),
            'action=if the first line is not OK, send the whole Logs directory',
            'log=' .. log_dir .. '/' .. STEM .. '_log.txt',
        }, '\n') .. '\n')
    end
    if type(update) ~= 'function' then status('update_unavailable'); return end

    local shared_mem
    local ok, patch, reason = pcall(function()
        shared_mem = make_memory(make_reader)
        if profile.disabled_by_menu then
            return {poll=function()return 'disabled_in_menu'end,restore_all=function()return 0,0,'disabled'end,in_mission=function()return false end}
        end
        return make_engine(shared_mem, profile, emit, write_text)
    end)
    if not ok or not patch then
        status('disabled: ' .. tostring(reason or patch))
        flush_log(true)
        return
    end
        state.patch = patch
    local bug_patch=profile.disabled_by_menu and nil or mix_engine(shared_mem,bug_profile,emit,write_text,bug_mix,'terminid')
    local illuminate_patch=profile.disabled_by_menu and nil or mix_engine(shared_mem,illuminate_profile,emit,write_text,illuminate_mix,'illuminate')

    -- Live reload: while you are not in a mission, a changed config file puts back what this engine wrote in the
    -- game's data and starts a new engine with the new settings, so no game restart is needed.
    local function read_config_text()
        local f = io.open(log_dir .. '/AllAutomatonReplace_config.txt', 'rb')
        if not f then return '' end
        local text = f:read('*a') or ''
        f:close()
        return text
    end
    -- Ship or mission: the game state object at game.dll+0x3326340 has a mode at +0xAC21C (3 = ship, 4 =
    -- mission; Steam build 25480438, the same flag Better Lobby Management reads). Any other value means a
    -- transition (loading), which counts as "not on the ship". When the flag cannot be read (another game
    -- build), the old director test is the fallback.
    local MODE_PTR_RVA, MODE_OFFSET = 0x3326340, 0xAC21C
    local function le32(s, i)
        local a, b, c, d = s:byte(i, i + 3)
        if not d then return nil end
        return a + b * 256 + c * 65536 + d * 16777216
    end
    local function game_mode()
        local game = shared_mem.module('game.dll')
        if not game then return nil end
        local g = shared_mem.read(game + MODE_PTR_RVA, 8)
        if not g then return nil end
        local lo, hi = le32(g, 1), le32(g, 5)
        if not lo or not hi or hi == 0 or hi >= 0x8000 or lo % 8 ~= 0 then return nil end
        local m = shared_mem.read(hi * 4294967296 + lo + MODE_OFFSET, 4)
        local mode = m and le32(m, 1)
        if mode == nil or mode > 15 then return nil end
        return mode
    end
    local function in_mission_now()
        local mode = game_mode()
        if mode ~= nil then
            state.game_mode = mode
            return mode ~= 3
        end
        state.game_mode = nil
        return patch.in_mission()
    end
    local stub_engine = {
        poll = function() return 'disabled_in_menu' end,
        restore_all = function() return 0, 0, 'stub' end,
        in_mission = function() return false end,
    }
    local tuning
    local last_config_text = read_config_text()
    local last_config_check, reload_waiting_reported = 0, false
    local function check_config_reload()
        local now = os.clock()
        if now - last_config_check < 3 then return end
        last_config_check = now
        local text = read_config_text()
        if text == last_config_text and not state.menu_dirty then reload_waiting_reported = false; return end
        if in_mission_now() then
            if not reload_waiting_reported then
                reload_waiting_reported = true
                emit(string.format('config_changed: waiting for the ship (game mode %s)', tostring(state.game_mode)))
            end
            return
        end
        if tuning then tuning.stop() end
                local restored, skipped, why = patch.restore_all()
        if skipped>0 and why=='native_data_restore' then
            status('mix_waiting:native_restore_conflict_restart_game');return
        end
        if bug_patch then bug_patch.restore_all() end
        if illuminate_patch then illuminate_patch.restore_all() end
        local new_profile = build_profile()
                configure(new_profile)
        local new_bug_profile=build_bug_profile(new_profile)
        local new_illuminate_profile=build_illuminate_profile(new_profile)
        local ok2, new_patch
        if new_profile.disabled_by_menu then ok2, new_patch = true, stub_engine
        else ok2, new_patch = pcall(make_engine, shared_mem, new_profile, emit, write_text) end
        state.menu_dirty = false
        state.menu_pending = false
        if ok2 and new_patch then
                        patch, state.patch, profile = new_patch, new_patch, new_profile
            bug_profile=new_bug_profile
            illuminate_profile=new_illuminate_profile
            bug_patch=profile.disabled_by_menu and nil or mix_engine(shared_mem,bug_profile,emit,write_text,bug_mix,'terminid')
            illuminate_patch=profile.disabled_by_menu and nil or mix_engine(shared_mem,illuminate_profile,emit,write_text,illuminate_mix,'illuminate')
            if settings_panel then settings_panel.sync(new_profile,new_bug_profile,new_illuminate_profile)end
            last_config_text = text
            state.reloads = (state.reloads or 0) + 1
            emit(string.format('config_reloaded restored=%d skipped=%d (%s)', restored, skipped, tostring(why)))
        else
            last_config_text = text
            emit('config_reload_failed: ' .. tostring(new_patch))
        end
        flush_log(true)
    end

    -- Settings persistence is separate from live game mutation. A mission keeps its
    -- active profile; the existing ship reload applies the saved profile later.
    local function save_panel_settings(draft,page,selected_mix,faction)
        selected_mix=selected_mix or unit_mix
        local values={}
        if page==0 then
            for _,row in ipairs(aar_panel_model.master)do values[row.key]=draft[row.key]end
        elseif page==5 then
            for _,row in ipairs(aar_panel_model.faction_rows(faction))do values[row.key]=draft[row.key]end
            if faction=='terminid'then values.bug_alpha_unit_schema=2 end
        else
            local source=selected_mix.sources[page]
            if not source then return false,'Unknown settings tab.'end
            if not selected_mix.normalize(draft.mixes[source.key])then return false,'Percentages must total 100%.'end
            values[selected_mix.vanilla_key(source.key)]=draft.vanilla[source.key]==true
            values[(faction=='terminid' and 'bug_mix_' or faction=='illuminate' and 'illuminate_mix_' or 'mix_')..source.key..'_initialized']=draft.initialized[source.key]==true
            for _,u in ipairs(selected_mix.units)do values[selected_mix.key(source.key,u[1])]=selected_mix.allowed(source.key,u[1]) and (draft.mixes[source.key][u[1]]or 0) or 0 end
            -- Clear the removed choice only when saving its own tab.
            if faction=='automaton' then values[selected_mix.key(source.key,'walker_rider')]=0 end
            for _,key in ipairs(selected_mix.removed_units)do values[selected_mix.key(source.key,key)]=0 end

        end
        local path=log_dir..'/AllAutomatonReplace_config.txt'
        local oldfile=io.open(path,'rb');local existed=oldfile~=nil;local old=''
        if oldfile then old=oldfile:read('*a');oldfile:close();if not old then return false,'Could not read existing settings.'end end
        local lines={'# Pick your bots settings. Saved by settings panel.'}
        for line in (old..'\n'):gmatch('(.-)\n')do
            local key=line:match('^%s*([%w_]+)%s*=')
            if not values[key]and values[key]~=false and values[key]~=0 then
                if line~='' and not line:match('^# Pick your bots settings%.')then lines[#lines+1]=line end
            end
        end
        local keys={};for key in pairs(values)do keys[#keys+1]=key end;table.sort(keys)
        for _,key in ipairs(keys)do lines[#lines+1]=key..'='..tostring(values[key])end
        local temp=path..'.tmp';local backup=path..'.bak'
        local f=io.open(temp,'wb');if not f then return false,'Could not open settings file for saving.'end
        local ok,why=pcall(function()
            assert(f:write(table.concat(lines,'\n')..'\n'));assert(f:flush());assert(f:close())
        end)
        if not ok then pcall(f.close,f);os.remove(temp);return false,'Settings write failed: '..tostring(why)end
        if existed then
            os.remove(backup)
            local moved,err=os.rename(path,backup)
            if not moved then os.remove(temp);return false,'Could not back up settings: '..tostring(err)end
        end
        local moved,err=os.rename(temp,path)
        if not moved then
            local restored=true
            if existed then restored=os.rename(backup,path)end
            os.remove(temp)
            return false,'Could not save settings: '..tostring(err)..(not restored and '; previous settings remain in .bak' or '')
        end
        state.menu_overrides={};state.menu_dirty=true;state.menu_pending=true;reload_waiting_reported=false
        emit('PICK_YOUR_BOTS_PANEL settings_saved tab='..tostring(page)..' apply_on_ship')
        return true,'Saved. Settings apply on the ship; the current mission keeps its active settings.'
    end
    local function panel_emit(line) emit(line) end
    -- A/B diagnostic: skip GUI creation, input filter and panel polling while
    -- keeping the same spawn/caller implementation and saved mix settings.
    if read_config().disable_gui_for_testing==true then
        emit('PICK_YOUR_BOTS_PANEL disabled_by_config no_gui_or_input_filter')
    else
        local ok,result=pcall(function()
                        local models={automaton=aar_panel_model.new(unit_mix,profile,save_panel_settings,'automaton'),
             terminid=aar_panel_model.new(bug_mix,bug_profile,save_panel_settings,'terminid'),
             illuminate=aar_panel_model.new(illuminate_mix,illuminate_profile,save_panel_settings,'illuminate')}
            return start_aar_panel(models,{automaton=unit_mix,terminid=bug_mix,illuminate=illuminate_mix},panel_emit,shared_mem)
        end)
        if ok then settings_panel=result else emit('PICK_YOUR_BOTS_PANEL bootstrap_error '..tostring(result))end
    end

    tuning=make_spawn_tuning(shared_mem,emit,nil)
    local faction_probe=make_faction_probe(shared_mem)
    local population,bug_population
    do local base=shared_mem.module('game.dll')
        if base then
            population=aar_factory_population.new(shared_mem.read,base,emit,shared_mem.gather)
            bug_population=aar_factory_population.new(shared_mem.read,base,emit,shared_mem.gather,
                {'ddafccccf2172e9e','97a497d084cb04ef','aafaa321a4480b96'},
                'TITAN_DRAGONROACH_POPULATION',27)
        end
    end
    local ffi=require('ffi');ffi.cdef[[uint64_t GetTickCount64(void);]]
    local tuning_clock=ffi.load('kernel32')
    do local ok,result=pcall(start_factory_production,shared_mem,emit)
        if ok then factory_production_instance=result else emit('FACTORY_PRODUCTION bootstrap_error '..tostring(result))end
    end
    local special=bug_special_controls.new(shared_mem,shared_mem.module('game.dll'),bug_mix.binary,emit)
    local caller = hulk_996(shared_mem, emit, nil)
    local previous, stopped = update, false
    local previous_faction=nil
    local call_options={}
    local function pack(...)return {n=select('#',...),...}end
    local function poll()
        if stopped then return end
        -- Native panel replaces the old AAR menu.
        local okr, errr = pcall(check_config_reload)
        if not okr then emit('config_reload_error: ' .. tostring(errr)) end
        state.game_mode=game_mode()
        local frame_now=tonumber(tuning_clock.GetTickCount64())/1000
        local faction=faction_probe(state.game_mode,frame_now)
                local bot_mission=faction=='automaton'
        local bug_mission=faction=='terminid'
        local illuminate_mission=faction=='illuminate'
        state.mission_faction=faction
        if faction~=previous_faction then
            emit('MISSION_FACTION '..tostring(faction or 'unknown'))
                        if previous_faction=='terminid' and not bug_mission then if caller then caller.reset()end;special.stop();if bug_patch then bug_patch.restore_all()end end
            if previous_faction=='automaton' and not bot_mission then
                if population then population.poll(frame_now,false)end
                if caller then caller.reset()end
                if patch.restore_native_bot_data then patch.restore_native_bot_data()end
            end
            if previous_faction=='terminid' and not bug_mission and bug_population then
                bug_population.poll(frame_now,false)
            end
            if previous_faction=='illuminate' and not illuminate_mission and illuminate_patch then
                illuminate_patch.restore_all()
            end
            previous_faction=faction
        end
        if bot_mission then
            local success,result=pcall(patch.poll)
            if success then status(result)
            else stopped=true;tuning.stop();status('stopped: '..tostring(result))end
                elseif bug_mission and bug_patch then
            local success,result=pcall(bug_patch.poll)
            if success then status(result)
            else stopped=true;tuning.stop();status('terminid_stopped: '..tostring(result))end
        elseif illuminate_mission and illuminate_patch then
            local success,result=pcall(illuminate_patch.poll)
            if success then status(result)
            else stopped=true;tuning.stop();status('illuminate_stopped: '..tostring(result))end
        else
            status(faction and 'idle_non_automaton:'..faction or 'idle_faction_unknown')
        end
        special.tick(frame_now,bug_mission and not profile.disabled_by_menu and not stopped,bug_profile)
        local population_ok,population_paused=true,false
        if bot_mission and not stopped then
            population_ok,population_paused=pcall(function()
                if not population then return true end
                return population.poll(frame_now,true,profile.factory_strider_cap)
            end)
            if not population_ok and frame_now-(state.population_error_at or -100)>=10 then
                state.population_error_at=frame_now;emit('FACTORY_POPULATION sample_error '..tostring(population_paused))
            end
        end
        profile.factory_cap_paused=bot_mission and (not population_ok or population_paused) or false
        state.factory_alive=bot_mission and population and population.count or nil
        state.factory_population_reason=bot_mission and
            (population_ok and population and population.reason or 'sample_error') or 'non_automaton'
        local bug_population_ok,bug_population_paused=true,false
        if bug_mission and not stopped then
            bug_population_ok,bug_population_paused=pcall(function()
                if not bug_population then return true end
                return bug_population.poll(frame_now,true,profile.bug_titan_cap,profile.bug_titan_resume_below)
            end)
            if not bug_population_ok and frame_now-(state.bug_population_error_at or -100)>=10 then
                state.bug_population_error_at=frame_now
                emit('TITAN_DRAGONROACH_POPULATION sample_error '..tostring(bug_population_paused))
            end
        end
        profile.bug_cap_paused=bug_mission and (not bug_population_ok or bug_population_paused) or false
        state.bug_heavy_alive=bug_mission and bug_population and bug_population.count or nil
        state.bug_population_reason=bug_mission and
            (bug_population_ok and bug_population and bug_population.reason or 'sample_error') or 'non_terminid'
        if bug_mission and bug_patch and not stopped and state.status=='active_terminids_replaced' then
            local ok,applied,why=pcall(bug_patch.set_heavy_suppressed,profile.bug_cap_paused)
            local selection_status=ok and (applied and 'active' or tostring(why)) or tostring(applied)
            if selection_status~=state.bug_cap_selection_status then
                state.bug_cap_selection_status=selection_status
                if selection_status~='active' then emit('TITAN_CLASS_SELECTION error '..selection_status)end
            end
        end
        if not stopped then
            local tune_ok,tune_err=pcall(tuning.poll,state.game_mode,
                faction~=nil and not profile.disabled_by_menu,
                profile,frame_now,faction)
            if not tune_ok then emit('SPAWN_TUNING_ERROR '..tostring(tune_err));tuning.stop();tuning.halted=true end
            state.tuning_status=tuning.status;state.cleanup_status=tuning.cleanup_status
        end
        if bot_mission and factory_production_instance and not stopped then
            factory_production_instance.core.original=state.patch and state.patch.factory_original
            local ok,why=pcall(factory_production_instance.tick,
                not profile.disabled_by_menu and state.patch~=stub_engine and state.patch.factory_original~=nil
                    and (state.status=='active_automatons_replaced' or state.status=='patched_automatons_replaced'),state.game_mode==4,
                profile.disable_factory_production and not profile.disabled_by_menu,
                profile.factory_production_unit)
            if not ok then emit('FACTORY_PRODUCTION runtime_error '..tostring(why));stopped=true;tuning.stop()end
        end
        if shared_mem.calls then
            local w=state.perf_window
            if not w then w={t=frame_now,c=shared_mem.calls,log=frame_now};state.perf_window=w end
            if frame_now-w.t>=10 then
                state.reads_per_second=(shared_mem.calls-w.c)/(frame_now-w.t)
                w.t,w.c=frame_now,shared_mem.calls
                if frame_now-w.log>=60 then
                    w.log=frame_now
                    emit(string.format('PERF memory_reads_per_second=%.0f game_mode=%s',state.reads_per_second,tostring(state.game_mode)))
                end
            end
        end
        if (bot_mission or bug_mission or illuminate_mission) and caller and not stopped then
            call_options.faction=faction;call_options.bug_cloud_ready=special.cloud_ready==true
            for _,k in ipairs({'bug_charger_calls','bug_stalker_calls','bug_titan_calls','bug_shrieker_calls','bug_call_cloud'})do call_options[k]=bug_profile[k]end
            if profile.bug_cap_paused then call_options.bug_titan_calls=false end
            call_options.any_bot_calls=profile.hulk_calls;call_options.factory_strider_calls=profile.factory_strider_calls
            call_options.illuminate_calls=illuminate_mission and illuminate_profile.illuminate_calls
            local call_ok, call_err = pcall(caller.tick, game_mode,
                not profile.disabled_by_menu and ((bug_mission and (bug_profile.bug_charger_calls or bug_profile.bug_stalker_calls or bug_profile.bug_shrieker_calls or (bug_profile.bug_titan_calls and not profile.bug_cap_paused)) and state.status=='active_terminids_replaced') or (bot_mission and (profile.hulk_calls or profile.factory_strider_calls) and not profile.factory_cap_paused and state.patch~=stub_engine and (state.status=='active_automatons_replaced' or state.status=='patched_automatons_replaced')) or (illuminate_mission and illuminate_profile.illuminate_calls and state.status=='active_illuminate_replaced')),
                call_options, population ~= nil and population.last == frame_now)
            if not call_ok then
                emit('hulk996_tick_error ' .. tostring(call_err))
                caller = nil
            end
        end
        flush_throttled()
    end
    update = function(...)
        poll()
        local values=pack(previous(...))
        if settings_panel then settings_panel.pump()end
        return (unpack or table.unpack)(values,1,values.n)
    end
    for _ = 1, 3 do poll() end
end

end)()

runtime(reader, memory, engine, profile)
