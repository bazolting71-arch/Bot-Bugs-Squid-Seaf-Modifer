Pick Your Bots + SEAF (F5 menu)  -  personal combination build

WHAT THIS IS
1. Pick your bots/bugs/squids 1.8.1 (No Preview Hotfix), unchanged except the settings
   panel fallback hotkey is F5 instead of F9. All enemy spawn multipliers (patrol count,
   patrol size, patrol cooldown rate, reinforcement budget/cooldown), unit mixes, caps, etc.
   are the original mod's and are changed in that panel (config: AllAutomatonReplace_config.txt).
2. The SEAF options from Gameplay Systems 1.4.2, copied byte-for-byte and untouched:
   Heavy Presence (Heavy SEAF on supported normal missions), Pelican Cooldown (-20/-50%),
   Active Wave Cooldown (-20/-50%). No Gameplay Systems enemy-spawn options are included.

IMPORTANT LIMITS
- The SEAF options are chosen in your mod manager, NOT in the F5 panel. They are fixed
  patches applied at game start; changing them needs a full restart.
- SEAF options need Bingus Shared Loader v18+ (Gameplay Systems requirement).
- If you use Bingus Mod Bindings Menu v2+, the panel key is set there ("Open settings",
  unassigned by default); F5 is only the fallback when that mod is absent.
- Do not run this alongside the original Pick your bots mod (same resource names).
- Not tested in game by the packager. Host required for the spawn multipliers.

CREDITS
Pick your bots/bugs/squids: feroz (see Assets/ATTRIBUTION.txt for emblem licensing).
Gameplay Systems: its respective author. Ask both authors before redistributing.
